export { default as IconBase } from './icon-base';
export type * from './icon-base.types';
