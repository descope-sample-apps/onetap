import type { FC } from 'react';

import type { IconBaseProps } from './icon-base.types';

const IconBase: FC<IconBaseProps> = ({ title, children, ...props }) => {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			version="1.1"
			fill="currentColor"
			strokeWidth="1.25"
			strokeLinecap="round"
			strokeLinejoin="round"
			{...props}
		>
			{title && <title>{title}</title>}
			{children}
		</svg>
	);
};

export default IconBase;
