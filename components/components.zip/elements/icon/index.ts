export { default as Icon } from './icon';
export type * from './icon.types';

export * from './icon-base';
export * from './icon-block';
