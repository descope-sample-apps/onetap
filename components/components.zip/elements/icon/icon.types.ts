import type { IconBaseProps, IconVariant } from './icon-base';

export interface IconProps extends IconBaseProps {
	name: IconVariant;
}
