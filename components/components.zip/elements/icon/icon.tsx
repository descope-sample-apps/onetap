import type { FC } from 'react';

import { iconsRegistry } from '@/components/icons';

import type { IconProps } from './icon.types';

const Icon: FC<IconProps> = ({ name, title, ...props }: IconProps) => {
	const { component: IconComponent, title: defaultTitle } =
		iconsRegistry[name] ?? {};

	if (!IconComponent) {
		return null;
	}

	return (
		<IconComponent
			title={title ?? defaultTitle}
			role="presentation"
			{...props}
		/>
	);
};

export default Icon;
