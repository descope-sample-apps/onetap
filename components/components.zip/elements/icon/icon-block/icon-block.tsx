import type { FC } from 'react';

import Icon from '../icon';

import type { IconBlockProps } from './icon-block.types';

const IconBlock: FC<IconBlockProps> = ({ iconName }) => {
	if (!iconName) return null;

	return <Icon name={iconName} />;
};

export default IconBlock;
