import type { IconVariant } from '../icon-base';

export interface IconBlockProps {
	id: string;
	iconName?: IconVariant;
}
