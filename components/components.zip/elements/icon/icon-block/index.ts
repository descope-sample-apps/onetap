export { default as IconBlock } from './icon-block';
export * from './icon-block.types';
