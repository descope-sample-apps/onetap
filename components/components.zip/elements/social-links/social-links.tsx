import type { SocialMediaIcon } from '@/types/social-media-icon';
import { Link } from '@/components/elements/link';

import { LabelS } from '../typography';
import { Icon } from '../icon';

import styles from './social-links.module.scss';

type SocialLink = Omit<SocialMediaIcon, 'component'>;

const icons: SocialLink[] = [
	{
		alt: 'X',
		iconName: 'X',
		href: 'https://twitter.com/descopeinc'
	},
	{
		alt: 'Instagram',
		iconName: 'Instagram',
		href: 'https://www.instagram.com/descope.inc/'
	},
	{
		alt: 'LinkedIn',
		iconName: 'LinkedIn',
		href: 'https://www.linkedin.com/company/descope/'
	},
	{
		alt: 'Bluesky',
		iconName: 'Bluesky',
		href: 'https://bsky.app/profile/descope.com'
	}
];

const renderIcon = ({ alt, iconName, href }: SocialLink) => (
	<Link key={href} className={styles.icon} href={href} ariaLabel={alt}>
		<Icon name={iconName} className={styles.svg} />
	</Link>
);

const SocialLinks = () => {
	return (
		<div className={styles.container}>
			<LabelS className={styles.title}>Follow Us</LabelS>
			<div className={styles.icons}>{icons?.map(renderIcon)}</div>
		</div>
	);
};

export default SocialLinks;
