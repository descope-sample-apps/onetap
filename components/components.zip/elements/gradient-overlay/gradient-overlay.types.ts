export interface GradientOverlayProps {
	gradientSrc?: any;
	className?: string;
	isDark?: boolean;
	priority?: boolean;
}
