import GradientOverlay from './gradient-overlay';

export default GradientOverlay;
