import clsx from 'clsx';

import type { EmbedVideoProps } from './embed-video.types';
import styles from './embed-video.module.scss';

export const EmbedVideo = ({ url, wrapperClassname }: EmbedVideoProps) => {
	return (
		<div className={clsx(styles.wrapper, wrapperClassname)}>
			<iframe
				className={styles.iframe}
				src={url}
				title={`Embed Video ${url}`}
			/>
		</div>
	);
};
