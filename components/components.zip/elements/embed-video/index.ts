import { EmbedVideo } from './embed-video';

export default EmbedVideo;
