export type EmbedVideoProps = {
	url: string;
	name?: string;
	wrapperClassname?: string;
};
