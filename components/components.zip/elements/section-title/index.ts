import SectionTitle from './section-title';

export default SectionTitle;
export type * from './section-title.types.ts';
