import type { ElementType } from 'react';
import type { ThreeElements } from '@react-three/fiber';

import type { TypographyProps } from '../typography';

export type SectionTitleProps<
	T extends Exclude<ElementType, keyof ThreeElements>
> = TypographyProps<T> & {
	texts?: string[];
};
