import { Fragment, type ElementType } from 'react';
import type { ThreeElements } from '@react-three/fiber';

import getNodeInnerText from '@/lib/helper/get-node-inner-text';

import { HeadingL, TextHighlight } from '../typography';
import TypeAnimation from '../type-animation';
import Cursor from '../type-animation/components/cursor';

import type { SectionTitleProps } from './section-title.types';

/**
 * Function to extract all of the parts between '*', '**', or '{}' characters
 * in a string.
 *
 * Example:
 *
 * input: Hello *World*! **This** is a test. {}!
 * output: ['Hello ', '*World*', '! ', '**This**', ' is a test. ', '{}', '!']
 *
 * @param title
 *
 * @returns string[]
 */
const getParts = (title: string): string[] => {
	// Regular expression to match text between asterisks (*), double asterisks (**), or curly braces ({})
	const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|\{\}|[^*{}]+)/g;

	// Use match() to find all occurrences and return the result
	// If no matches are found, return an array with the original string
	return title.match(regex) || [title];
};

/**
 * Use this component for the title of all the sections in the website.
 * This component accepts the title as a string, and automatically renders
 * highlighting or typing animation to the title when appropriate.
 * Highlighted text should be between '*' character
 * Typing animation should be between '**' characters
 * Typing animation loop through `texts` texts should be put instead of the '{}' characters
 *
 * Usage:
 *
 * ```
 * <SectionTitle
 *      as={HeadingXL}
 *      texts={['How are you?', 'How is it going?', 'Hows life?']}
 * >
 * Hello, *World*! {}!
 * </SectionTitle>
 * ```
 */
const SectionTitle = <T extends Exclude<ElementType, keyof ThreeElements>>({
	children,
	as,
	texts,
	...props
}: SectionTitleProps<T>) => {
	const Component = as || HeadingL;
	const title = getNodeInnerText(children);

	if (!title) return null;

	const isHighlighted = title.includes('*') || title.includes('{}');

	if (!isHighlighted) {
		return <Component {...props}>{children}</Component>;
	}

	const parts = getParts(title);

	return (
		<div
			className={props.className}
			style={{
				position: 'relative',
				width: '100%'
			}}
		>
			<Component
				{...props}
				style={{
					opacity: 0,
					visibility: 'hidden',
					pointerEvents: 'none'
				}}
			>
				{parts.map((part, index) => {
					if (part.startsWith('**') && part.endsWith('**')) {
						return (
							<Fragment key={index}>
								<TextHighlight injectHTML>{part.slice(2, -2)}</TextHighlight>
								<Cursor />
							</Fragment>
						);
					}
					if (part.startsWith('*') && part.endsWith('*')) {
						return (
							<Fragment key={index}>
								<TextHighlight injectHTML key={index}>
									{part.slice(1, -1)}
								</TextHighlight>
							</Fragment>
						);
					}

					if (part === '{}' && texts && texts.length > 0) {
						return (
							<Fragment key={index}>
								<br />
								<TextHighlight injectHTML key={index}>
									{texts[0]}
								</TextHighlight>
								<Cursor />
								<br />
							</Fragment>
						);
					}

					return <Fragment key={index}>{part}</Fragment>;
				})}
			</Component>
			<Component
				{...props}
				as="div"
				style={{
					position: 'absolute',
					top: 0,
					left: 0,
					width: '100%',
					height: '100%',
					maxWidth: '100%'
				}}
			>
				{parts.map((part, index) => {
					if (part.startsWith('**') && part.endsWith('**')) {
						return (
							<Fragment key={index}>
								<TypeAnimation
									key={index}
									text={part.slice(2, -2)}
									isHighlighted
								/>
							</Fragment>
						);
					}
					if (part.startsWith('*') && part.endsWith('*')) {
						return (
							<Fragment key={index}>
								<TextHighlight injectHTML key={index}>
									{part.slice(1, -1)}
								</TextHighlight>
							</Fragment>
						);
					}

					if (part === '{}' && texts && texts.length > 0) {
						return (
							<Fragment key={index}>
								<br />
								<TypeAnimation key={index} text={texts} isHighlighted />
								<br />
							</Fragment>
						);
					}

					return <Fragment key={index}>{part}</Fragment>;
				})}
			</Component>
		</div>
	);
};

export default SectionTitle;
