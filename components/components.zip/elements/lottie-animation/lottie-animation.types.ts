import type { Props as LottiePlayerProps } from '@dotlottie/react-player';

import type { lottiesRegistry } from '@/assets/lotties';

export type LottieName = keyof typeof lottiesRegistry;

export type BaseLottieProps = Omit<LottiePlayerProps, 'src'> & {
	width?: number | `${number}`;
	height?: number | `${number}`;
};

export interface InternalLottieProps extends BaseLottieProps {
	name: LottieName;
	src?: never;
}

export interface ExternalLottieProps extends BaseLottieProps {
	src: string;
	name?: never;
	width: NonNullable<BaseLottieProps['width']>;
	height: NonNullable<BaseLottieProps['height']>;
}

export type LottieAnimationProps = InternalLottieProps | ExternalLottieProps;
