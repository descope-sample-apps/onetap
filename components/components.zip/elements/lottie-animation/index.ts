import LottieAnimation from './lottie-animation';

export type * from './lottie-animation.types';
// this will be loaded in ssr, used for eager loading in hero sections
export { default as LottieAnimationEager } from './lottie-animation';
// this is lazy loaded
export default LottieAnimation;
