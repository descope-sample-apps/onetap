'use client';

import {
	type FC,
	useRef,
	useState,
	useEffect,
	lazy,
	Suspense,
	startTransition
} from 'react';
import clsx from 'clsx';
import { useInView } from 'react-intersection-observer';

import { lottiesRegistry } from '@/assets/lotties';

import type { LottieAnimationProps } from './lottie-animation.types';
import styles from './lottie-animation.module.scss';

const DotLottiePlayer = lazy(() =>
	import('@dotlottie/react-player').then((module) => ({
		default: module.DotLottiePlayer
	}))
);

const LottieAnimation: FC<LottieAnimationProps> = ({ name, ...props }) => {
	const lottieRef = useRef<any>(null);
	const [loaded, setLoaded] = useState(false);
	const [shouldRender, setShouldRender] = useState(false);

	const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

	useEffect(() => {
		if (inView) {
			setShouldRender(true);
		}
	}, [inView]);

	const internalLottie = name && lottiesRegistry[name];

	const handleComplete = () => {
		if (
			!internalLottie ||
			internalLottie.loopKeyframe === undefined ||
			internalLottie.loop
		) {
			return;
		}

		if (internalLottie) {
			lottieRef.current?.goToAndPlay(internalLottie.loopKeyframe, true);
		}
	};

	const handleLoaded = () => {
		startTransition(() => {
			setLoaded(true);
			setTimeout(() => lottieRef.current?.play(), 100);
		});
	};

	const width = internalLottie?.width ?? props.width ?? 0;
	const height = internalLottie?.height ?? props.height ?? 0;

	if (!internalLottie && !props.src) {
		return `Invalid Lottie Name '${name}'`;
	}

	return (
		<div
			className={styles.wrapper}
			ref={ref}
			style={{
				aspectRatio: `${width} / ${height}`
			}}
		>
			{shouldRender && (
				<Suspense>
					<DotLottiePlayer
						ref={lottieRef}
						autoplay={false}
						worker
						loop={internalLottie?.loop ?? props.loop ?? true}
						src={internalLottie?.animationData ?? props.src ?? ''}
						className={clsx(styles.lottie, loaded && styles.loaded)}
						rendererSettings={{ progressiveLoad: true }}
						onEvent={(name) => {
							if (name === 'ready' || name === 'data_ready') {
								handleLoaded();
							} else if (name === 'complete' || name === 'loopComplete') {
								handleComplete();
							}
						}}
						{...props}
					/>
				</Suspense>
			)}
			<svg className={styles.svgPlaceholder} />
		</div>
	);
};

export default LottieAnimation;
