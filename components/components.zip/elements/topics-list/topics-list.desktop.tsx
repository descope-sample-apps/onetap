'use client';

import type React from 'react';

import type { BlogTopic } from '@/types/blog/topic';

import {
	MenuList,
	MenuListItem,
	MenuListText,
	MenuListTitle,
	MenuListContainer
} from '../menu-list';

import type { TopicsListProps } from './topics-list.types';
import styles from './topics-list.module.scss';

const TopicsListDesktop: React.FC<TopicsListProps> = ({
	items,
	title,
	active,
	onClick
}) => {
	const renderItem = (item: BlogTopic) => {
		const isActive = active && active.slug === item.slug;
		const handleClick = () => onClick(item);

		return (
			<MenuListItem key={item.id} isActive={isActive} onClick={handleClick}>
				<MenuListText className={styles.topicDesktop} as="button">
					{item.name}
				</MenuListText>
			</MenuListItem>
		);
	};

	return (
		<MenuListContainer className={styles.hideOnTablet}>
			<MenuListTitle>{title}</MenuListTitle>
			<MenuList>{items.map(renderItem)}</MenuList>
		</MenuListContainer>
	);
};

export default TopicsListDesktop;
