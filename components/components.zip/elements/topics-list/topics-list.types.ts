import type { BlogTopic } from '@/types/blog/topic';

export interface TopicsListProps {
	title: string;
	active: BlogTopic;
	items: BlogTopic[];
	onClick: (item: BlogTopic) => void;
}
