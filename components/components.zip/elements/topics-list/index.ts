import TopicsListMobile from './topics-list.mobile';
import TopicsListDesktop from './topics-list.desktop';

export { TopicsListMobile, TopicsListDesktop };
