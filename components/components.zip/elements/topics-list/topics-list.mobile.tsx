'use client';

import clsx from 'clsx';
import { useId, type FC } from 'react';
import { useModal } from '@faceless-ui/modal';

import type { BlogTopic } from '@/types/blog/topic';

import { TextL } from '../typography';
import Container from '../container';
import Button from '../button/button';
import Popup from '../popup';

import styles from './topics-list.module.scss';
import type { TopicsListProps } from './topics-list.types';

const TopicsListMobile: FC<TopicsListProps> = ({
	items,
	title,
	active,
	onClick
}) => {
	const id = useId();
	const uniqueSlug = `modal-${id}`;
	const { toggleModal, closeModal } = useModal();

	const toggle = () => {
		toggleModal(uniqueSlug);
	};

	const close = () => {
		closeModal(uniqueSlug);
	};

	const renderItem = (item: BlogTopic) => {
		const isActive = active && active.slug === item.slug;
		const handleClick = () => {
			close();
			onClick(item);
		};

		return (
			<li key={item.id} className={styles.item}>
				<TextL
					isMedium
					as="button"
					onClick={handleClick}
					className={clsx(isActive && styles.active)}
				>
					{item.name}
				</TextL>
			</li>
		);
	};

	return (
		<div className={styles.container}>
			<Button
				className={styles.toggleButton}
				onClick={toggle}
				newVariant="secondary"
				size="large"
			>
				{active && active.slug !== 'all' ? active.name : title}
			</Button>
			<Popup uniqueSlug={uniqueSlug} wrapperClass={styles.popup}>
				<Container as="ul" className={styles.items}>
					{items.map(renderItem)}
				</Container>
				<Button
					className={styles.closeButton}
					onClick={toggle}
					newVariant="secondary"
					size="small"
				>
					Close
				</Button>
			</Popup>
		</div>
	);
};

export default TopicsListMobile;
