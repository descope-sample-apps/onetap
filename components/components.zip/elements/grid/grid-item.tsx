'use client';

import clsx from 'clsx';

import styles from './grid.module.scss';
import type { GridItemProps } from './grid.types';

const GridItem = ({
	span,
	children,
	className,
	onClick,
	as: Component = 'div'
}: GridItemProps) => {
	let gridItemSpan: Record<string, number | undefined>;

	if (typeof span === 'number') {
		gridItemSpan = {
			[styles[`col-span-${span}`]]: span
		};
	} else {
		const { xxl, lg, xl, sm, md, base } = span;
		gridItemSpan = {
			[styles[`col-span-${base}`]]: base,
			[styles[`col-span-sm-${sm}`]]: sm,
			[styles[`col-span-md-${md}`]]: md,
			[styles[`col-span-lg-${lg}`]]: lg,
			[styles[`col-span-xl-${xl}`]]: xl,
			[styles[`col-span-xxl-${xxl}`]]: xxl
		};
	}

	const gridItemClasses: string = clsx(
		className,
		gridItemSpan,
		styles.gridItem
	);

	return (
		<Component className={gridItemClasses} onClick={onClick}>
			{children}
		</Component>
	);
};

export default GridItem;
