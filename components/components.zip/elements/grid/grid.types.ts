import type { ThreeElements } from '@react-three/fiber';
import type { CSSProperties, ElementType, ReactNode } from 'react';

type AlignOptions = 'start' | 'center' | 'end' | 'spaced';

type BreakpointOptions<T> =
	| T
	| Partial<Record<'base' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl', T>>;

export type ColumnNumbers = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;

export interface GridProps {
	className?: string;
	style?: CSSProperties;
	as?: Exclude<ElementType, keyof ThreeElements>;
	reverse?: BreakpointOptions<true>;
	align?: BreakpointOptions<AlignOptions>;
	children: ReactNode | ReactNode[];
	withGrid?: boolean;
}
export interface GridItemProps {
	className?: string;
	as?: Exclude<ElementType, keyof ThreeElements>;
	span: BreakpointOptions<ColumnNumbers>;
	children: ReactNode | ReactNode[];
	onClick?: () => void;
}
