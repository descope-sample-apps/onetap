import clsx from 'clsx';

import styles from './grid.module.scss';
import type { GridProps } from './grid.types';

const Grid = ({
	align,
	reverse,
	children,
	className,
	style,
	as: Component = 'div',
	withGrid
}: GridProps) => {
	let gridAlign: Record<string, string | undefined>;
	let gridReverse: Record<string, true | undefined>;

	if (typeof align === 'string') {
		gridAlign = {
			[styles[`grid-align-${align}`]]: align
		};
	} else if (typeof align === 'object') {
		const { xxl, lg, xl, sm, md, base } = align;
		gridAlign = {
			[styles[`grid-align-${base}`]]: base,
			[styles[`grid-align-sm-${sm}`]]: sm,
			[styles[`grid-align-md-${md}`]]: md,
			[styles[`grid-align-lg-${lg}`]]: lg,
			[styles[`grid-align-xl-${xl}`]]: xl,
			[styles[`grid-align-xxl-${xxl}`]]: xxl
		};
	} else {
		gridAlign = {};
	}

	if (typeof reverse === 'boolean') {
		gridReverse = {
			[styles[`grid-reverse`]]: reverse
		};
	} else if (typeof reverse === 'object') {
		const { xxl, lg, xl, sm, md, base } = reverse;
		gridReverse = {
			[styles['grid-reverse']]: base,
			[styles['grid-reverse-sm']]: sm,
			[styles['grid-reverse-md']]: md,
			[styles['grid-reverse-lg']]: lg,
			[styles['grid-reverse-xl']]: xl,
			[styles['grid-reverse-xxl']]: xxl
		};
	} else {
		gridReverse = {};
	}

	const gridClasses: string = clsx(
		className,
		gridAlign,
		gridReverse,
		styles.grid,
		withGrid && styles.withGrid
	);

	return (
		<Component style={style} className={gridClasses}>
			{children}
		</Component>
	);
};

export default Grid;
