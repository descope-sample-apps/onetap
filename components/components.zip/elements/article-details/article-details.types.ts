export interface ArticleDetailsProps {
	date: string;
}
