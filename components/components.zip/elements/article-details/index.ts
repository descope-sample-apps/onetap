import ArticleDetails from './article-details';

export default ArticleDetails;
