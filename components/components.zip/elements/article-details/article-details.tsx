'use client';
import type React from 'react';

import useMobileOnly from '@/hooks/use-mobile-only';

import DateFormat from '../date-format/date-format';
import { TextM } from '../typography';
import PostShare from '../post-share';

import styles from './article-details.module.scss';
import type { ArticleDetailsProps } from './article-details.types';

const ArticleDetails: React.FC<ArticleDetailsProps> = ({ date }) => {
	const isMobile = useMobileOnly();

	return (
		<div className={styles.details}>
			<TextM className={styles.date} variant={isMobile ? 'regular' : undefined}>
				<DateFormat date={date} />
			</TextM>
			<div className={styles.divider} />
			<PostShare />
		</div>
	);
};

export default ArticleDetails;
