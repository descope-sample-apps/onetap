'use client';
import { useModal } from '@faceless-ui/modal';
import { useEffect, useId, useState } from 'react';

import Popup from '../popup';

import styles from './video-popup.module.scss';
import type { VideoEmbedPopupProps } from './video-popup.types';

const VideoEmbedPopup = (props: VideoEmbedPopupProps) => {
	const id = useId();
	const modal = useModal();
	const { uniqueSlug, videoEmbedLink } = props;
	const [embedLink, setEmbedLink] = useState('');

	const { oneModalIsOpen } = modal;
	const uniqueId = `video-popup-iframe-${id}`;

	useEffect(() => {
		if (oneModalIsOpen) setEmbedLink(videoEmbedLink || '');
		else setEmbedLink('');
	}, [oneModalIsOpen, uniqueId, videoEmbedLink]);

	return (
		<Popup
			uniqueSlug={uniqueSlug}
			wrapperClass={styles.popup}
			closeIconClass={styles.closeIconWrapper}
		>
			<div className={styles.popupContainer}>
				{'video' in props && props.video ? (
					// eslint-disable-next-line jsx-a11y/media-has-caption
					<video
						controls
						src={props.video?.src}
						className={styles.embed}
					></video>
				) : (
					<iframe
						id={uniqueId}
						loading="lazy"
						allowFullScreen
						className={styles.embed}
						src={embedLink}
						title="YouTube video player"
						allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
					></iframe>
				)}
			</div>
		</Popup>
	);
};

export default VideoEmbedPopup;
