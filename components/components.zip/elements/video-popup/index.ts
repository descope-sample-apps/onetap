import VideoEmbedPopup from './video-popup';

export default VideoEmbedPopup;
