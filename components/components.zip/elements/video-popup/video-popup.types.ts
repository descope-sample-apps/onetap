import type { Link } from '@/types/link';

export type VideoEmbedPopupProps = {
	videoEmbedLink?: Link['videoEmbedLink'];
	video?: Link['video'];
	uniqueSlug: string;
};
