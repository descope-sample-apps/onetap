import type { Image } from '@/types/image';
import type { SectionTheme } from '@/types/page-block';

export interface LogoLinkCardItem {
	id: string;
	logo: Image | null;
	theme?: SectionTheme;
	blockType: string;
	link: {
		isExternal: boolean;
		newTab: boolean;
		href: string;
		text: string;
	};
}
