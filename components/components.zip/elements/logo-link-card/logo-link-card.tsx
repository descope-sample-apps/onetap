import type React from 'react';
import Image from 'next/image';

import { Icon } from '../icon';
import { TextL } from '../typography';
import Link from '../link/link';

import styles from './logo-link-card.module.scss';
import type { LogoLinkCardItem } from './logo-link-card.types';

const LogoLinkCard: React.FC<LogoLinkCardItem> = ({ logo, theme, link }) => {
	return (
		<Link
			href={link.href}
			newTab={link.newTab || link.isExternal}
			ariaLabel={link.text}
			className={styles.card}
			data-theme={theme}
		>
			{logo && (
				<div className={styles.imageWrapper}>
					<Image
						src={logo.src}
						alt=""
						className={styles.image}
						fill
						sizes="100vw"
						style={{
							objectFit: 'contain',
							maxWidth: '100%'
						}}
					/>
				</div>
			)}

			<TextL className={styles.link}>
				{link.text}
				<Icon name="ArrowRight" />
			</TextL>
		</Link>
	);
};

export default LogoLinkCard;
