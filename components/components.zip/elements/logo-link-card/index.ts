import LogoLinkCard from './logo-link-card';

export default LogoLinkCard;
