import CaseStudyCard from './case-study-card';

export default CaseStudyCard;
