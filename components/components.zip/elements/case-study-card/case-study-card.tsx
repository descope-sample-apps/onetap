import type React from 'react';
import Image from 'next/image';

import { Link } from '@/components/elements/link';

import { Icon } from '../icon';
import { HeadingS, TextL } from '../typography';

import styles from './case-study-card.module.scss';
import type { CaseStudyCardItem } from './case-study-card.types';

const CaseStudyCard: React.FC<CaseStudyCardItem> = ({
	logo,
	title,
	link,
	theme
}) => {
	return (
		<Link
			href={link.href}
			newTab={link.newTab || link.isExternal}
			className={styles.card}
			data-theme={theme}
		>
			{logo && (
				<div className={styles.imageWrapper}>
					<Image
						src={logo.src}
						alt={logo.alt || ''}
						className={styles.image}
						fill
						sizes="100vw"
						style={{
							objectFit: 'contain',
							maxWidth: '100%'
						}}
					/>
				</div>
			)}

			<HeadingS as="h3" className={styles.title}>
				{title}
			</HeadingS>

			<TextL className={styles.link}>
				{link.text}
				<Icon name="ArrowRight" />
			</TextL>
		</Link>
	);
};

export default CaseStudyCard;
