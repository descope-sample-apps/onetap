import type { Image } from '@/types/image';

interface FrameworkLink {
	id: string;
	text: string;
	href?: string;
	logo?: Image;
}

export interface FrameworkCardProps {
	id: string;
	heading: string;
	links?: FrameworkLink[];
	className?: string;
}
