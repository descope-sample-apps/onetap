import Image from 'next/image';
import clsx from 'clsx';

import { TextL, TextS } from '../typography';
import { Link } from '../link';

import type { FrameworkCardProps } from './framework-card.types';
import styles from './framework-card.module.scss';

const FrameworkCard = ({
	heading,
	links = [],
	className
}: FrameworkCardProps) => {
	const isColumnLayout = links.length === 4;
	return (
		<div className={clsx(styles.card, className)}>
			<TextL className={styles.title}>{heading}</TextL>
			{links.length > 0 && (
				<ul
					className={clsx(styles.linksList, isColumnLayout && styles.linkGrid)}
				>
					{links.map((link) => (
						<li key={link.id}>
							<Link href={link.href!}>
								<div className={styles.imageContainer}>
									{link.logo && (
										<Image
											src={link.logo.src}
											alt={link.logo.alt || `${link.text} logo`}
											fill
										/>
									)}
								</div>
								<TextS isMedium className={styles.frameworkLabel} as="span">
									{link.text}
								</TextS>
							</Link>
						</li>
					))}
				</ul>
			)}
		</div>
	);
};

export default FrameworkCard;
