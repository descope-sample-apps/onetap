import FrameworkCard from './framework-card';
import type { FrameworkCardProps } from './framework-card.types';

export default FrameworkCard;
export type { FrameworkCardProps };
