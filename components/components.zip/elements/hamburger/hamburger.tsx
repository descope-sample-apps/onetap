'use client';

import clsx from 'clsx';

import { Icon } from '../icon';

import styles from './hamburger.module.scss';
import type { HamburgerProps } from './hamburger.types';

const Hamburger = ({ className, onClick, open }: HamburgerProps) => (
	<button
		type="button"
		onClick={onClick}
		className={clsx(styles.hamburger, className)}
		aria-label={open ? 'Close menu' : 'Open menu'}
	>
		{open ? <Icon name="Close" /> : <Icon name="Menu" />}
	</button>
);

export default Hamburger;
