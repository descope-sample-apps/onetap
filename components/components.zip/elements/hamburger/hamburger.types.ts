export interface HamburgerProps {
	open: boolean;
	className?: string;
	onClick: () => void;
}
