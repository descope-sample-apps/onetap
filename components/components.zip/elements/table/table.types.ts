import type { ReactNode } from 'react';

export type TableElementProps = {
	className?: string;
	children?: ReactNode;
};
