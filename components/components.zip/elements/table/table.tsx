import clsx from 'clsx';
import type { FC } from 'react';

import { TextS } from '../typography';

import styles from './table.module.scss';
import type { TableElementProps } from './table.types';

export const Table: FC<TableElementProps> = ({ children, className }) => (
	<div className={styles.tableContainer}>
		{/* eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex */}
		<table tabIndex={0} className={clsx(styles.table, className)}>
			{children}
		</table>
	</div>
);

export const TableRow: FC<TableElementProps> = ({ children, className }) => (
	<TextS as="tr" className={clsx(styles.tableRow, className)}>
		{children}
	</TextS>
);

export const TableHeader: FC<TableElementProps> = ({ children, className }) => (
	<TextS isMedium as="th" className={clsx(styles.th, className)}>
		{children}
	</TextS>
);

export const TableData: FC<TableElementProps> = ({ children, className }) => (
	<TextS as="td" className={clsx(styles.td, className)}>
		{children}
	</TextS>
);
