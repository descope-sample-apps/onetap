/* eslint-disable */
'use client';

import { useEffect, useId, useMemo } from 'react';
import clsx from 'clsx';
import * as Primitive from '@radix-ui/react-select';

import { Icon } from '@/components/elements/icon';
import { LabelS, TextM } from '@/components/elements/typography';

import type { SelectItemProps, SelectProps } from '../input.types';
import styles from '../input.module.scss';
import { iconsRegistry } from '@/components/icons';
import { ALL_TAB } from '../../tabs/tabs';
import { TabItem } from '../../tabs';

const Select = ({
	value,
	label,
	disabled,
	icon,
	id,
	error,
	required,
	onChange,
	hideOptionalLabel,
	placeholder,
	options,
	text,
	ariaLabel,
	className = {
		root: '',
		inputContainer: '',
		input: '',
		label: '',
		error: '',
		selectTrigger: '',
		icon: ''
	}
}: SelectProps) => {
	const fallbackInputId = useId();
	const labelId = useId();
	const errorMessageId = useId();

	const isError = Boolean(error);

	const valueToOption = (newValue: string | null): TabItem => {
		if (!newValue) return ALL_TAB;

		const selectedOption = options.find((option) => option.value === newValue);

		if (!selectedOption) return ALL_TAB;

		return selectedOption;
	};

	const currentOption = useMemo(() => valueToOption(value ?? null), [value]);

	const handleChange = (newValue: string | null) => {
		if (!onChange) return;

		onChange(valueToOption(newValue));
	};

	return (
		<Primitive.Root value={value ?? undefined} onValueChange={handleChange}>
			<div
				className={clsx(
					styles.root,
					disabled && styles.disabled,
					isError && styles.error,
					className.root
				)}
			>
				{label && (
					<LabelS
						className={clsx(styles.label, className.label)}
						id={labelId}
						htmlFor={id ?? fallbackInputId}
					>
						{label}{' '}
						<span className={clsx(styles.suffix, required && styles.required)}>
							{required ? '*' : hideOptionalLabel ? '' : '(optional)'}
						</span>
					</LabelS>
				)}
				<div className={clsx(styles.inputContainer, className.inputContainer)}>
					<Primitive.Trigger
						className={clsx(
							styles.selectTrigger,
							icon && Boolean(iconsRegistry[icon]) && styles.withIcon,
							className.selectTrigger
						)}
						disabled={disabled}
						id={id ?? fallbackInputId}
						aria-required={required}
						aria-invalid={isError}
						aria-labelledby={`${labelId} ${errorMessageId}`}
						{...(ariaLabel ? { 'aria-label': ariaLabel } : {})}
					>
						<span
							className={clsx(
								styles.pointerEventsNone,
								!value && styles.placeholder
							)}
						>
							{value ? text || currentOption.label : placeholder || 'Select...'}
						</span>
						{icon && <Icon name={icon} className={styles.icon} />}
						<Primitive.Icon>
							<Icon
								name="ChevronDown"
								className={clsx(
									styles.selectIcon,
									styles.iconAlignRight,
									className.icon
								)}
							/>
						</Primitive.Icon>
					</Primitive.Trigger>
					<Primitive.Portal>
						<Primitive.Content
							className={styles.dropdownContent}
							position="popper"
							sideOffset={5}
						>
							<Primitive.ScrollUpButton className={styles.dropdownScrollButton}>
								<Icon
									name="ChevronUp"
									className={styles.dropdownScrollButtonIcon}
								/>
							</Primitive.ScrollUpButton>
							<Primitive.Viewport className={styles.dropdownViewport}>
								{options.map((option) => (
									<SelectItem
										key={option.value}
										value={option.value}
										isActive={option.value === value}
									>
										{option.label}
									</SelectItem>
								))}
							</Primitive.Viewport>
							<Primitive.ScrollDownButton
								className={styles.dropdownScrollButton}
							>
								<Icon
									name="ChevronDown"
									className={styles.dropdownScrollButtonIcon}
								/>
							</Primitive.ScrollDownButton>
						</Primitive.Content>
					</Primitive.Portal>
				</div>
				<div
					className={clsx(styles.errorContainer, className.error)}
					aria-live="assertive"
				>
					{isError && (
						<TextM aria-relevant="additions removals" id={errorMessageId}>
							{error}
						</TextM>
					)}
				</div>
			</div>
		</Primitive.Root>
	);
};

const SelectItem = ({
	children,
	className,
	isActive,
	value,
	ref
}: SelectItemProps) => {
	return (
		<Primitive.Item
			className={clsx(
				styles.dropdownItem,
				isActive && styles.active,
				className
			)}
			value={value}
			ref={ref}
		>
			<Primitive.ItemText>
				<TextM isMedium as="span">
					{children}
				</TextM>
			</Primitive.ItemText>
		</Primitive.Item>
	);
};

export default Select;
