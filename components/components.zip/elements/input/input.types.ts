import type { ComponentProps, ReactNode, Ref } from 'react';

import type { IconVariant } from '../icon';
import type { TabItem } from '../tabs';

export interface InputProps extends Omit<ComponentProps<'input'>, 'className'> {
	label?: string | ReactNode;
	icon?: IconVariant;
	error?: string | null;
	hideOptionalLabel?: boolean;
	ref?: Ref<HTMLInputElement>;
	className?: {
		root?: string;
		inputContainer?: string;
		input?: string;
		label?: string;
		error?: string;
	};
}

export interface SelectProps {
	value?: string | null;
	label?: string | ReactNode;
	icon?: IconVariant;
	error?: string | null;
	hideOptionalLabel?: boolean;
	options: { label: string; value: string }[];
	disabled?: boolean;
	id?: string;
	required?: boolean;
	onChange?: (value: TabItem) => void;
	placeholder?: string;
	text?: string;
	ariaLabel?: string;
	className?: {
		root?: string;
		inputContainer?: string;
		input?: string;
		label?: string;
		error?: string;
		selectTrigger?: string;
		icon?: string;
	};
}

export interface SelectItemProps {
	children: ReactNode;
	value: string;
	className?: string;
	isActive?: boolean;
	ref?: Ref<HTMLDivElement>;
}
