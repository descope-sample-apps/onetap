'use client';

import { useId } from 'react';
import clsx from 'clsx';

import { Icon } from '@/components/elements/icon';
import { iconsRegistry } from '@/components/icons';

import { LabelS, TextM } from '../typography';

import type { InputProps } from './input.types';
import styles from './input.module.scss';

const Input = ({
	label,
	disabled,
	icon,
	id,
	error,
	required,
	onChange,
	hideOptionalLabel,
	className = {
		root: '',
		inputContainer: '',
		input: '',
		label: '',
		error: ''
	},
	ref,
	...props
}: InputProps) => {
	const fallbackInputId = useId();
	const labelId = useId();
	const errorMessageId = useId();

	const isError = Boolean(error);

	return (
		<div
			className={clsx(
				styles.root,
				disabled && styles.disabled,
				isError && styles.error,
				className.root
			)}
		>
			{label && (
				<LabelS
					className={clsx(styles.label, className.label)}
					id={labelId}
					htmlFor={id ?? fallbackInputId}
				>
					{label}{' '}
					<span className={clsx(styles.suffix, required && styles.required)}>
						{required ? '*' : hideOptionalLabel ? '' : '(optional)'}
					</span>
				</LabelS>
			)}
			<div className={clsx(styles.inputContainer, className.inputContainer)}>
				<input
					{...props}
					ref={ref}
					id={id ?? fallbackInputId}
					className={clsx(
						icon && Boolean(iconsRegistry[icon]) && styles.withIcon,
						className.input
					)}
					disabled={disabled}
					required={required}
					aria-required={required}
					aria-invalid={isError}
					aria-labelledby={`${labelId} ${errorMessageId}`}
					onChange={onChange}
				/>
				{icon && <Icon name={icon} className={styles.icon} />}
				{isError && (
					<Icon
						name="AlertTriangle"
						className={clsx(styles.errorIcon, styles.iconAlignRight)}
					/>
				)}
			</div>
			<div
				className={clsx(styles.errorContainer, className.error)}
				aria-live="assertive"
			>
				{isError && (
					<TextM aria-relevant="additions removals" id={errorMessageId}>
						{error}
					</TextM>
				)}
			</div>
		</div>
	);
};

Input.displayName = 'Input';

export default Input;
