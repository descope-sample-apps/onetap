import type { Document } from '@contentful/rich-text-types';

import type { Image } from '@/types/image';

export interface InfoBoxProps {
	heading: string;
	isActive?: boolean;
	image: Image | null;
	subHeading: Document | null;
	listItems: InfoBoxListItem[];
}

export interface InfoBoxListItem {
	title: string;
	text: Document | null;
}
