import InfoBox from './info-box';
import type { InfoBoxProps } from './info-box.types';

export { InfoBoxProps };
export default InfoBox;
