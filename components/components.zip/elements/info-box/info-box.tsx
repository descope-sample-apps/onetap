import clsx from 'clsx';
import type React from 'react';

import { HeadingM, HeadingS } from '@/components/elements/typography';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import LightboxImage from '@/components/elements/lightbox-image';

import styles from './info-box.module.scss';
import type { InfoBoxListItem, InfoBoxProps } from './info-box.types';

const renderListItem = ({ text, title }: InfoBoxListItem) => {
	return (
		<li key={title} className={styles.listItem}>
			<HeadingS className={styles.listTitle}>{title}</HeadingS>
			{text && RichTextRenderer(styles)(text)}
		</li>
	);
};

const InfoBox: React.FC<InfoBoxProps> = ({
	image,
	heading,
	isActive,
	listItems,
	subHeading
}) => {
	return (
		<div className={clsx(styles.container, isActive && styles.active)}>
			{heading && <HeadingM className={styles.heading}>{heading}</HeadingM>}
			{subHeading && (
				<div className={styles.subHeading}>
					{RichTextRenderer(styles)(subHeading)}
				</div>
			)}
			<div
				className={clsx(styles.body, !heading && !subHeading && styles.noTitle)}
			>
				<ul className={styles.items}>{listItems.map(renderListItem)}</ul>
				<div className={styles.image}>
					{/* @ts-ignore */}
					{image && <LightboxImage width="531" imageProps={image} />}
				</div>
			</div>
		</div>
	);
};

export default InfoBox;
