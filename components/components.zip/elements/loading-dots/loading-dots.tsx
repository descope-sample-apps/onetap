import clsx from 'clsx';

import styles from './loading-dots.module.scss';

export const LoadingDots = ({ className }: { className: string }) => {
	return (
		<div className={clsx(styles.loadingDots, className)}>
			<span className="sr-only">Loading...</span>
		</div>
	);
};
