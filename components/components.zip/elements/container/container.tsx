import clsx from 'clsx';

import styles from './container.module.scss';
import type { ContainerProps } from './container.types';

const Container = ({
	as: Component = 'div',
	className,
	children,
	ref,
	...rest
}: ContainerProps) => {
	return (
		<Component
			ref={ref}
			className={clsx(styles.container, className)}
			{...rest}
		>
			{children}
		</Component>
	);
};

export default Container;
