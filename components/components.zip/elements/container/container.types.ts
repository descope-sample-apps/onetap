import type { ThreeElements } from '@react-three/fiber';
import type { ElementType, HTMLAttributes, ReactNode, Ref } from 'react';

export interface ContainerProps extends HTMLAttributes<HTMLDivElement> {
	as?: Exclude<ElementType, keyof ThreeElements>;
	children: ReactNode | ReactNode[];
	className?: string;
	ref?: Ref<HTMLElement>;
}
