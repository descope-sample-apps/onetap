import type { Image } from '@/types/image';
import type { Link } from '@/types/link';

export interface BookADemoProps {
	id: string;
	title: string;
	subTitle?: string;
	image?: Image;
	links?: Link[];
}
