import clsx from 'clsx';
import Image from 'next/image';

import { HeadingS, TextS } from '../typography';
import { Link } from '../link';

import styles from './book-a-demo.module.scss';
import type { BookADemoProps } from './book-a-demo.types';

const BookADemo = ({
	title,
	subTitle,
	image,
	id,
	links,
	wrapperClass
}: BookADemoProps & { wrapperClass?: string; imageClass?: string }) => {
	const link = links?.[0];

	return (
		<div id={id} className={clsx(styles.wrapper, wrapperClass)}>
			<div className={styles.content}>
				<HeadingS>{title}</HeadingS>
				<TextS className={styles.subTitle}>{subTitle}</TextS>
				{link?.id && (
					<Link
						href={link.href}
						newTab={link.newTab}
						downloadFile={link.downloadFile}
						video={link.video}
						videoEmbedLink={link.videoEmbedLink}
						style={link.style}
						newVariant={link.newVariant}
						size={link.size}
						iconName={link.iconName}
						iconAlignment={link.iconAlignment}
						className={styles.buttonCta}
					>
						{link.text}
					</Link>
				)}
			</div>
			{image && (
				<div className={styles.imageContainer}>
					<Image
						src={image.src}
						alt=""
						className={styles.image}
						width={312}
						height={300}
						sizes="100vw"
						style={{
							maxWidth: '110%'
						}}
					/>
				</div>
			)}
		</div>
	);
};

export default BookADemo;
