import WiresSVGs from './wires-svg';

export default WiresSVGs;
