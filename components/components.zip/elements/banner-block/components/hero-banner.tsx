import type { BlockItem } from '@/types/block';
import Container from '@/components/elements/container';
import { TextL, TextS } from '@/components/elements/typography';
import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';

import styles from '../banner-block.module.scss';
import SectionWrapper from '../../section-wrapper/section-wrapper';

const HeroBanner = (props: BlockItem & { siteWide?: boolean }) => {
	const { description, rawText } = props;

	return (
		<SectionWrapper
			className={styles.heroBannerWrapper}
			as="div"
			theme="dark"
			order={0}
		>
			<Container className={styles.heroBannerContainer}>
				<div className={styles.bannerContent}>
					<TextL className={styles.descriptionWrapper} as="div">
						{description && RichTextRenderer(styles)(description)}
						{rawText && <TextS className={styles.description}>{rawText}</TextS>}
					</TextL>
				</div>
			</Container>
		</SectionWrapper>
	);
};

export default HeroBanner;
