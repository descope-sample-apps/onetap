import type { BlockItem } from '@/types/block';
import { TextS } from '@/components/elements/typography';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';
import routes from '@/lib/routes';
import Button from '@/components/elements/button';

import styles from '../banner-block.module.scss';

import WideBannerWrapper from './wide-banner-wrapper';

const WideBanner = ({ description, rawText }: BlockItem) => {
	return (
		<WideBannerWrapper>
			<Container className={styles.siteWideContainer}>
				<TextS isMedium as="div" className={styles.descriptionWrapper}>
					{description &&
						RichTextRenderer(styles, { paragraphAs: TextS })(description)}
					{rawText && <TextS className={styles.description}>{rawText}</TextS>}
				</TextS>
				<Button
					href={routes.DESCOPE_APP_LINK}
					newVariant="tertiary"
					iconName="UserCircle"
					iconAlignment="right"
					className={styles.loginButton}
				>
					Log In
				</Button>
			</Container>
		</WideBannerWrapper>
	);
};

export default WideBanner;
