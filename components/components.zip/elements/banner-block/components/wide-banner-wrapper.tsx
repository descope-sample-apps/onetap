'use client';

import type React from 'react';
import clsx from 'clsx';
import { usePathname } from 'next/navigation';

import routes from '@/lib/routes';

import styles from '../banner-block.module.scss';

const WideBannerWrapper = ({ children }: { children: React.ReactNode }) => {
	const pathname = usePathname();

	return (
		<div
			id="top-wide-banner"
			className={clsx(
				styles.bannerWrapper,
				pathname === routes.HOME_ROUTE && styles.transparent,
				'dark'
			)}
		>
			{children}
		</div>
	);
};

export default WideBannerWrapper;
