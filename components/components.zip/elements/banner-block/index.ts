import BannerBlock from './banner-block';

export default BannerBlock;
