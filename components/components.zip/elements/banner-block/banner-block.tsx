import type { BlockItem } from '@/types/block';

import WideBanner from './components/wide-banner';
import HeroBanner from './components/hero-banner';

const BannerBlock = ({
	siteWide,
	...props
}: BlockItem & { siteWide?: boolean }) => {
	if (siteWide) return <WideBanner {...props} />;

	return <HeroBanner {...props} />;
};

export default BannerBlock;
