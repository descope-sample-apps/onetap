import type { Image } from '@/types/image';
import type { SectionTheme } from '@/types/page-block';

export interface VideoBlockCardItem {
	id: string;
	className?: string;
	title: string;
	blockType?: string;
	image: Image | null;
	theme?: SectionTheme;
	link: {
		isExternal: boolean;
		newTab: boolean;
		href: string;
		text: string;
	};
}
