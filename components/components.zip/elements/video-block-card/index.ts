import VideoBlockCard from './video-block-card';

export default VideoBlockCard;
