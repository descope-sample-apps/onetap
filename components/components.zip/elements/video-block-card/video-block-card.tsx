import type React from 'react';
import Image from 'next/image';
import clsx from 'clsx';

import { Link } from '@/components/elements/link';

import { HeadingS } from '../typography';

import styles from './video-block-card.module.scss';
import type { VideoBlockCardItem } from './video-block-card.types';

const VideoBlockCard: React.FC<VideoBlockCardItem> = ({
	image,
	title,
	link,
	theme,
	className
}) => {
	return (
		<Link
			href={link.href}
			newTab={link.newTab || link.isExternal}
			className={clsx(styles.card, className)}
			data-theme={theme}
		>
			{image && (
				<div className={styles.cardImage}>
					{image && (
						<Image
							src={image.src}
							alt=""
							fill
							sizes="100vw"
							style={{
								objectFit: 'cover',
								maxWidth: '100%'
							}}
						/>
					)}
				</div>
			)}

			<div className={styles.cardDetails}>
				<HeadingS as="h3" className={styles.title}>
					{title}
				</HeadingS>
			</div>
		</Link>
	);
};

export default VideoBlockCard;
