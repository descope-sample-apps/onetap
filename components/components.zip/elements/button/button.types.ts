import type { ElementType, ReactNode, Ref, SyntheticEvent } from 'react';
import type { ThreeElements } from '@react-three/fiber';

import type { IconVariant } from '../icon';

interface BaseButtonProps
	extends Partial<Pick<HTMLButtonElement, 'ariaHidden' | 'tabIndex'>> {
	as?: 'button' | 'a' | Exclude<ElementType, keyof ThreeElements>;
	children?: ReactNode;
	disabled?: boolean;
	className?: string;
	type?: 'button' | 'submit' | 'reset';

	// new fields, website refresh
	newVariant?: ButtonNewVariant;
	size?: 'small' | 'large';
	iconName?: IconVariant;
	iconAlignment?: 'left' | 'right';

	// deprecated
	variant?: ButtonVariant;

	ref?: Ref<HTMLElement>;
}

interface ButtonWithHref extends BaseButtonProps {
	href: string;
	type?: never;
	onClick?: never;
}

interface ButtonWithClick extends BaseButtonProps {
	href?: never;
	onClick: (e: SyntheticEvent) => void;
}

interface ButtonWithSubmit extends BaseButtonProps {
	href?: never;
	onClick?: never;
	type: 'submit';
}

// deprecated
export type ButtonVariant =
	| 'default'
	| 'extraSmall'
	| 'small'
	| 'standard'
	| 'large'
	| 'extraLarge';

export type ButtonNewVariant = 'primary' | 'secondary' | 'tertiary' | 'icon';

export type ButtonProps = ButtonWithClick | ButtonWithHref | ButtonWithSubmit;
