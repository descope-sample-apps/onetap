'use client';

import clsx from 'clsx';
import type { SyntheticEvent } from 'react';
import { isValidElement } from 'react';

import isExternalPage from '@/lib/helper/is-external-page';

import { TextL, TextS } from '../typography';
import { Icon } from '../icon';
import { Link } from '../link';

import styles from './button.module.scss';
import type { ButtonProps } from './button.types';

const isDevelopment = process.env.NODE_ENV === 'development';

const Button = ({
	children,
	href,
	onClick,
	disabled,
	className,
	type = 'button',
	as,
	size = 'small',
	newVariant = 'primary',
	iconName,
	iconAlignment,
	ref,
	...rest
}: ButtonProps) => {
	const analytics = (typeof window !== 'undefined' && window.analytics) || null;

	const Text = size === 'small' ? TextS : TextL;

	const Component = as || (href ? Link : 'button');
	const newTab = isExternalPage(href || '');

	const handleClick = (e: SyntheticEvent) => {
		if (!isDevelopment) {
			analytics?.track('CTA Clicked', {
				buttonText: children,
				currentUrl: window.location.href,
				destinationUrl: href || 'Not navigation button'
			});
		}

		onClick?.(e);
	};

	return (
		<Component
			ref={ref}
			href={href}
			type={type}
			onClick={handleClick}
			disabled={disabled}
			className={clsx(
				// new styles
				newVariant && styles.button,
				newVariant && styles[`button-${newVariant}`],
				newVariant && size && styles[`button-${size}`],
				iconName && iconAlignment === 'left' && styles['button-icon-left'],
				className
			)}
			{...(!as && href ? { newTab } : {})}
			{...rest}
		>
			{children &&
				(isValidElement(children) ? (
					<>{children}</>
				) : (
					<Text as="span">{children}</Text>
				))}
			{iconName && (
				<Icon
					role="presentation"
					name={iconName}
					className={styles['button-icon-svg']}
				/>
			)}
		</Component>
	);
};

export default Button;
