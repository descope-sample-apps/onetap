import styles from './bkg-animated-illustration.module.scss';

const BkgAnimatedIllustration = () => (
	<div className={styles.backgroundVideo}>
		<video
			loop
			autoPlay
			muted
			className={styles.videoPlayback}
			playsInline={true}
		>
			<source src="/videos/bkg-animation.mp4" type="video/mp4" />
		</video>
	</div>
);

export default BkgAnimatedIllustration;
