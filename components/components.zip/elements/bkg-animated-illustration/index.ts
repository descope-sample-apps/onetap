import BkgAnimatedIllustration from './bkg-animated-illustration';

export default BkgAnimatedIllustration;
