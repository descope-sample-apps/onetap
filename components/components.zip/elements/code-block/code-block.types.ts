import type { CodeBlock } from '@/types/code-block';

export type CodeBlockProps = CodeBlock & {
	codeBlockClassName?: string;
	preClassName?: string;
	codeClassName?: string;
};
