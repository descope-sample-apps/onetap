'use client';

import clsx from 'clsx';
import Prism from 'prismjs';
import { type FC, useEffect, useRef } from 'react';
import dynamic from 'next/dynamic';

import 'prismjs/themes/prism-coy.css';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-go';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-powershell';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-swift';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-java';
import 'prismjs/components/prism-csharp';
import 'prismjs/components/prism-cshtml';

import useOnMount from '@/hooks/use-on-mount';
import useToggle from '@/hooks/use-toggle';
import Copied from '@/public/icons/copied';
import Copy from '@/public/icons/copy';

import styles from './code-block.module.scss';
import type { CodeBlockProps } from './code-block.types';

const PLAINTEXT_KEY = 'plaintext';

const CodeBlock: FC<CodeBlockProps> = ({
	code,
	language,
	preClassName,
	codeClassName,
	codeBlockClassName
}) => {
	const { isOn, setOff, setOn } = useToggle('off');
	const time = useRef<NodeJS.Timeout | null>(null);
	const isPlainText = language === PLAINTEXT_KEY;

	useEffect(() => {
		Prism.highlightAll();
	}, []);

	const copyCode = () => {
		if (isOn) return;
		setOn();
		navigator.clipboard.writeText(code);
		time.current = setTimeout(() => {
			time.current && clearTimeout(time.current);
			setOff();
		}, 2500);
	};

	useOnMount(() => {
		return () => {
			time.current && clearTimeout(time.current);
		};
	});

	return (
		<div className={clsx(styles.codeBlock, codeBlockClassName)}>
			<button type="button" onClick={copyCode} className={styles.button}>
				<span className="visually-hidden">
					{isOn ? 'Close menu' : 'Open menu'}
				</span>
				{isOn ? (
					<Copied className={styles.icon} />
				) : (
					<Copy className={styles.icon} />
				)}
			</button>
			<pre className={clsx(styles.pre, preClassName)}>
				<code
					// data-prismjs-copy={Copy}
					className={clsx(
						styles.code,
						codeClassName,
						`language-${isPlainText ? 'none' : language}`
					)}
				>
					{code}
				</code>
			</pre>
		</div>
	);
};
CodeBlock.displayName = 'CodeBlock';

export default dynamic(() => Promise.resolve(CodeBlock), { ssr: false });
