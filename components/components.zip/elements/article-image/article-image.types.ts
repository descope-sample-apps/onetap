import type { Image } from '@/types/image';

export interface ArticleImageProps extends Omit<Image, 'width' | 'height'> {}
