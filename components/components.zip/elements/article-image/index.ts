import ArticleImage from './article-image';

export default ArticleImage;
