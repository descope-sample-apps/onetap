import type React from 'react';
import Image from 'next/image';

import styles from './article-image.module.scss';
import type { ArticleImageProps } from './article-image.types';

const ArticleImage: React.FC<ArticleImageProps> = ({ src, alt }) => (
	<div className={styles.imageContainer}>
		<Image
			src={src}
			alt={alt || ''}
			className={styles.image}
			fill
			sizes="100vw"
			style={{
				objectFit: 'cover',
				maxWidth: '100%'
			}}
		/>
	</div>
);

export default ArticleImage;
