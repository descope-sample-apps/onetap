import type { Block } from '@/types/block';
import type { RelatedContent } from '@/types/learning-center/post';
import type { Link } from '@/types/link';
import type { NewsletterSignupProps } from '@/components/sections/newsletter-signup';

import type {
	AdvancedImageProps,
	ContentImageAlignment
} from '../advanced-image/advanced-image.types';
import type { SearchProps } from '../search/search.types';
import type { BookADemoProps } from '../book-a-demo/book-a-demo.types';
import type { FAQProps } from '../faq';

export const isSearchEntry = (block: Block): block is SearchProps => {
	return 'suggestionTitle' in block;
};

export const isNewsletterEntry = (
	block: Block
): block is NewsletterSignupProps => {
	return 'buttonText' in block;
};

export const isAdvancedImageEntry = (
	content: RelatedContent
): content is AdvancedImageProps & { alignment?: ContentImageAlignment } => {
	return 'advancedImage' in content;
};

export const isLinkEntry = (block: Block): block is Link => {
	return 'style' in block;
};

export const isBookADemoEntry = (block: Block): block is BookADemoProps => {
	// @ts-expect-error
	return block.type === 'Book a demo Block';
};

export const isFaqEntry = (block: Block): block is FAQProps => {
	// @ts-expect-error
	return block.type === 'FAQ List Block';
};
