import type { Block } from '@/types/block';

export interface BlockProps {
	blocks: Block | Block[] | null;
	isInlineBlock?: boolean;
	wrapperClass?: string;
	linkClass?: string;
	formClass?: string;
	inputClass?: string;
}
