import clsx from 'clsx';
import dynamic from 'next/dynamic';

import type { Block } from '@/types/block';
import { Link } from '@/components/elements/link';

import styles from './blocks.module.scss';
import type { BlockProps } from './blocks.types';
import { isLinkEntry, isNewsletterEntry, isSearchEntry } from './utils';

const FrameworksCards = dynamic(
	() => import('@/components/sections/frameworks-cards'),
	{ ssr: true }
);
const Search = dynamic(() => import('../search/search'), { ssr: true });
const NewsletterForm = dynamic(
	() => import('../newsletter-form').then((mod) => mod.NewsletterForm),
	{ ssr: true }
);

const renderBlock = (
	block: Block,
	linkClass?: string,
	formClass?: string,
	inputClass?: string
) => {
	if ('cards' in block) return <FrameworksCards key={block.id} {...block} />;

	if (isLinkEntry(block)) {
		const rest = {
			style: block.style,
			newVariant: block.newVariant,
			downloadFile: block.downloadFile,
			size: block.size,
			iconName: block.iconName,
			iconAlignment: block.iconAlignment
		};

		if (
			!block.href &&
			!block.video &&
			!block.downloadFile &&
			!block.videoEmbedLink
		)
			return null;

		return (
			<Link
				className={clsx(styles.block, linkClass)}
				href={block.href}
				key={block.href}
				video={block.video}
				newTab={block.newTab}
				videoEmbedLink={block.videoEmbedLink}
				{...rest}
			>
				{block.text}
			</Link>
		);
	}

	if (isNewsletterEntry(block))
		return (
			<NewsletterForm
				key={block.id}
				className={formClass}
				inputClass={inputClass}
				newsletterText={block.heading}
				placeholder={block.inputPlaceholder}
				buttonText={block.buttonText}
			/>
		);

	if (isSearchEntry(block)) {
		return (
			<Search
				key={block.id}
				allowSearchFor={block.allowSearchFor}
				placeholder={block.placeholder}
				id={block.id}
				suggestionTitle={block.suggestionTitle}
				className={block.className}
			/>
		);
	}

	return <></>;
};

const RenderBlocks = ({
	blocks,
	isInlineBlock,
	wrapperClass,
	linkClass,
	formClass,
	inputClass
}: BlockProps) => {
	if (!blocks) return null;

	const El = isInlineBlock ? 'span' : 'div';

	return (
		<El
			className={clsx(
				styles.blocks,
				wrapperClass,
				isInlineBlock && styles.inline
			)}
		>
			{Array.isArray(blocks)
				? blocks.map((block) =>
						renderBlock(block, linkClass, formClass, inputClass)
					)
				: renderBlock(blocks, linkClass, formClass, inputClass)}
		</El>
	);
};

export default RenderBlocks;
