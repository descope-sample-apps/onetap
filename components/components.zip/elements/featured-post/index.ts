import FeaturedPost from './featured-post';

export default FeaturedPost;
