import type { BlogPost } from '@/types/blog/post';

export type FeaturedBlogPost = Pick<
	BlogPost,
	| 'title'
	| 'topic'
	| 'excerpt'
	| 'image'
	| 'slug'
	| 'publishedDate'
	| 'lastModified'
	| 'type'
>;
