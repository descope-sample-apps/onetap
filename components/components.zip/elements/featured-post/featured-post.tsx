'use client';
import type React from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';

import routes from '@/lib/routes';
import useCurrentPageDataContext from '@/hooks/use-current-page-data-context';

import { HeadingM, LabelS } from '../typography';
import DateFormat from '../date-format/date-format';
import Button from '../button/button';

import styles from './featured-post.module.scss';

const FeaturedPost = () => {
	const router = useRouter();
	const { featuredBlogPost: post } = useCurrentPageDataContext<'Blog'>();
	const { title, topic, image, lastModified, publishedDate, slug } = post || {};
	const dateToShow = lastModified ? lastModified : publishedDate;
	const href = slug ? routes.BLOG_POST(slug) : null;

	const goToPost = () => {
		if (!href) return;

		router.push(href);
	};

	const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
		if (e.key === 'Enter') goToPost();
	};

	if (!post) return null;

	return (
		<div
			role="button"
			tabIndex={0}
			onClick={goToPost}
			onKeyUp={handleKeyDown}
			className={styles.container}
		>
			<div className={styles.imageContainer}>
				{image && (
					<Image
						src={image.src}
						alt=""
						fill
						priority
						sizes="100vw"
						style={{
							objectFit: 'cover',
							maxWidth: '100%'
						}}
					/>
				)}
			</div>
			<div className={styles.details}>
				<LabelS className={styles.category}>{topic?.name}</LabelS>{' '}
				{topic && dateToShow && '|'}{' '}
				{dateToShow && (
					<LabelS className={styles.date}>
						<DateFormat date={dateToShow} />
					</LabelS>
				)}
			</div>
			<HeadingM as="h3" className={styles.title}>
				{title}
			</HeadingM>
			<Button
				className={styles.link}
				// @ts-expect-error
				href={href}
				newVariant="tertiary"
				iconName="ArrowRight"
				size="large"
			>
				Read More
			</Button>
		</div>
	);
};

export default FeaturedPost;
