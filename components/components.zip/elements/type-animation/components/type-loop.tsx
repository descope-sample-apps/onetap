'use client';

import AnimatedText from './animated-text';

const TypeLoop = ({ text }: { text: string[] }) => {
	return (
		<>
			<span className="sr-only">{text[0]}</span>
			<AnimatedText text={text} />
		</>
	);
};

export default TypeLoop;
