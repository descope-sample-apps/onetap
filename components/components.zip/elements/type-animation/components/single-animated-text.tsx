'use client';

import React, { useState, useEffect, useRef } from 'react';

const SingleAnimatedText = ({
	text,
	isInView
}: {
	text: string;
	isInView: boolean;
}) => {
	const [displayText, setDisplayText] = useState('');
	const timeoutRef = useRef<NodeJS.Timeout | null>(null);

	useEffect(() => {
		if (!isInView) return;

		let currentIndex = 0;

		const animateText = () => {
			if (currentIndex <= text.length) {
				setDisplayText(text.slice(0, currentIndex));
				currentIndex++;
				timeoutRef.current = setTimeout(animateText, 50); // Adjust timing as needed
			}
		};

		React.startTransition(() => {
			animateText();
		});

		return () => {
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
			}
		};
	}, [text, isInView]);

	return <span aria-hidden>{displayText}</span>;
};

export default SingleAnimatedText;
