'use client';

import { useState, useEffect, useRef } from 'react';

import SingleAnimatedText from './single-animated-text';

// const SingleAnimatedText = dynamic(() => import('./single-animated-text'), {
// ssr: false
// });

const SingleType = ({ text }: { text: string }) => {
	const [isInView, setIsInView] = useState(false);
	const componentRef = useRef<HTMLSpanElement>(null);

	useEffect(() => {
		const observer = new IntersectionObserver(
			([entry]) => {
				setIsInView(entry.isIntersecting);
			},
			{ threshold: 0.1 } // Adjust this value as needed
		);

		if (componentRef.current) {
			observer.observe(componentRef.current);
		}

		return () => {
			if (componentRef.current) {
				// eslint-disable-next-line react-hooks/exhaustive-deps
				observer.unobserve(componentRef.current);
			}
		};
	}, []);

	return (
		<>
			<span ref={componentRef}>
				{/* for accessibility purposes */}
				<span className="sr-only">{text}</span>
				<SingleAnimatedText text={text} isInView={isInView} />
			</span>
		</>
	);
};

export default SingleType;
