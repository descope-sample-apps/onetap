'use client';

import { useState, useEffect, useRef, startTransition } from 'react';

const AnimatedText = ({ text }: { text: string[] }) => {
	const [displayText, setDisplayText] = useState('');
	const currentIndexRef = useRef(0);
	const charIndexRef = useRef(0);
	const timeoutRef = useRef<NodeJS.Timeout | null>(null);

	useEffect(() => {
		const animateText = () => {
			const currentText = text[currentIndexRef.current];
			const typingSpeed = 120; // Adjust this value to change typing speed (lower is faster)
			const erasingSpeed = 60; // Adjust this value to change erasing speed (lower is faster)
			const pauseDuration = 1000; // Adjust this value to change pause duration (in milliseconds)

			if (charIndexRef.current <= currentText.length) {
				// Typing
				startTransition(() => {
					setDisplayText(currentText.slice(0, charIndexRef.current));
				});
				charIndexRef.current++;
				timeoutRef.current = setTimeout(animateText, typingSpeed);
			} else if (charIndexRef.current === currentText.length + 1) {
				// Pause at the end
				charIndexRef.current++;
				timeoutRef.current = setTimeout(animateText, pauseDuration);
			} else if (charIndexRef.current <= currentText.length * 2 + 1) {
				// Erasing
				startTransition(() => {
					setDisplayText(
						currentText.slice(
							0,
							currentText.length * 2 + 1 - charIndexRef.current
						)
					);
				});
				charIndexRef.current++;
				timeoutRef.current = setTimeout(animateText, erasingSpeed);
			} else {
				// Move to next text
				currentIndexRef.current = (currentIndexRef.current + 1) % text.length;
				charIndexRef.current = 0;
				timeoutRef.current = setTimeout(animateText, typingSpeed);
			}
		};

		animateText();

		return () => {
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
			}
		};
	}, [text]);

	return (
		<span className="inline" aria-hidden>
			{displayText}
		</span>
	);
};

export default AnimatedText;
