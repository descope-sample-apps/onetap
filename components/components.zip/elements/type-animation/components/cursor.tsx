import styles from '../type-animation.module.scss';

const Cursor = () => {
	return (
		<span data-cursor className={styles.cursor} aria-hidden="true">
			|
		</span>
	);
};

export default Cursor;
