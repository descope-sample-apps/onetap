import { TextHighlight } from '../typography';

import type { TypeAnimationProps } from './type-animation.types';
import SingleType from './components/single-type';
import TypeLoop from './components/type-loop';
import styles from './type-animation.module.scss';
import Cursor from './components/cursor';

const TypeAnimation = ({ text, isHighlighted }: TypeAnimationProps) => {
	const Wrapper = isHighlighted ? TextHighlight : 'span';

	return (
		<div className={styles.wrapper}>
			<Wrapper>
				{Array.isArray(text) ? (
					<TypeLoop text={text} />
				) : (
					<SingleType text={text} />
				)}
			</Wrapper>
			<Cursor />
		</div>
	);
};

export default TypeAnimation;
