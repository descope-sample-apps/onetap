import TypeAnimation from './type-animation';

export default TypeAnimation;
