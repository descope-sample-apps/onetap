export interface TypeAnimationProps {
	text: string | string[];
	isHighlighted?: boolean;
}
