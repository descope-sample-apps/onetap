'use client';

import LiteYouTubeEmbed from 'react-lite-youtube-embed';
import clsx from 'clsx';

import styles from './video-block.module.scss';
import type { VideoBlockProps } from './video-block.types';

const YoutubeLinkRegex =
	// eslint-disable-next-line no-useless-escape
	/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=|\/v\/|\/e\/|\/u\/\w\/|\/embed\?|\/v=)([^#\&\?]*).*/;

const getVideoId = (url: string) => {
	if (!url) return '';
	const match = url.match(YoutubeLinkRegex);

	if (!match) return '';
	const videoId = match[2];

	if (videoId.length === 11) return videoId;
	return '';
};

export const VideoBlock = (props: VideoBlockProps) => {
	if ('video' in props && props.video)
		return (
			// eslint-disable-next-line jsx-a11y/media-has-caption
			<video
				controls
				src={props.video?.src}
				className={clsx(styles.video, props.className)}
			></video>
		);
	else if ('videoEmbedLink' in props && props.videoEmbedLink)
		return (
			<LiteYouTubeEmbed
				webp
				poster="maxresdefault"
				title="YouTube video player"
				id={getVideoId(props.videoEmbedLink)}
				wrapperClass={clsx(styles.video, props.className, 'yt-lite')}
			/>
		);
};
