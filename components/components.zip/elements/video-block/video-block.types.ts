import type { Image } from '@/types/image';

interface VideoBlockBase {
	className?: string;
}

interface VideoBlockWithEmbedLink extends VideoBlockBase {
	videoEmbedLink: string;
}

interface VideoBlockWithVideo extends VideoBlockBase {
	video: Image | null;
}

export type VideoBlockProps = VideoBlockWithEmbedLink | VideoBlockWithVideo;
