import { VideoBlock } from './video-block';

export default VideoBlock;
