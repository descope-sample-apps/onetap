import axios from 'axios';

const PORTAL_ID = process.env.NEXT_PUBLIC_HUBSPOT_PORTAL_ID;

type HubspotSubscribeFormResponse = { success: boolean; message: string };

const hubspotSubscribeForm = async ({
	email,
	hubspotFormId
}: {
	email: string;
	hubspotFormId?: string;
}): Promise<HubspotSubscribeFormResponse> => {
	const fields = [
		{
			objectTypeId: '0-1',
			name: 'email',
			value: email
		}
	];

	const result: HubspotSubscribeFormResponse = await axios
		.post(
			`https://api.hsforms.com/submissions/v3/integration/submit/${PORTAL_ID}/${hubspotFormId}`,
			{ fields: fields }
		)
		.then((res) => ({ success: true, message: res.data.inlineMessage }))
		.catch(() => ({ success: false, message: 'Oops, something went wrong' }));

	return result;
};

export default hubspotSubscribeForm;
