'use client';

import clsx from 'clsx';
import { type ChangeEvent, type FormEvent, useState } from 'react';

import useCurrentPageDataContext from '@/hooks/use-current-page-data-context';
import useToggle from '@/hooks/use-toggle';

import Button from '../button/button';
import Input from '../input';
import { TextL, TextM, TextS } from '../typography';
import { Icon } from '../icon';

import hubspotSubscribeForm from './hubspot-subscribe';
import styles from './newsletter-form.module.scss';

const NewsletterForm = ({
	inputClass,
	newsletterText,
	buttonText,
	placeholder,
	className,
	textClassName
}: {
	className?: string;
	inputClass?: string;
	newsletterText?: string;
	buttonText?: string;
	placeholder?: string;
	textClassName?: string;
}) => {
	const { hubspotFormId } = useCurrentPageDataContext();

	const [email, setEmail] = useState('');
	const [statusMessage, setStatusMessage] = useState('');
	const { isOn: success, setOn: setSuccess } = useToggle('off');

	const handleInputChange = (evt: ChangeEvent<HTMLInputElement>) => {
		const { value } = evt.target;
		setEmail(value);
	};

	const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		const result = await hubspotSubscribeForm({ email, hubspotFormId });
		if (result.success) setSuccess();
		setStatusMessage(result.message);
	};

	return (
		<div className={clsx(styles.container, className)}>
			{newsletterText && (
				<div className={styles.heading}>
					<div className={styles.imageContainer}>
						<Icon name="MagicLinks" className={styles.icon} />
					</div>

					<div className={clsx(styles.newsletterText, textClassName)}>
						<TextS isMedium>{`${newsletterText.split('.')[0]}.`}</TextS>
						<br />
						<TextS className={clsx(styles.newsletterSubText, textClassName)}>
							{newsletterText.split('.').slice(1).join('.')}
						</TextS>
					</div>
				</div>
			)}
			{success ? (
				<TextM dangerouslySetInnerHTML={{ __html: statusMessage }} />
			) : (
				<>
					<form onSubmit={onSubmit} className={styles.form}>
						<Input
							required
							type="email"
							name="login"
							value={email}
							placeholder={placeholder || 'Your-email'}
							className={{ input: clsx(styles.input, inputClass) }}
							onChange={handleInputChange}
						/>
						<Button
							type="submit"
							newVariant="secondary"
							variant="small"
							className={styles.button}
						>
							{buttonText || 'Subscribe'}
						</Button>
					</form>
					{statusMessage && (
						<TextL className={styles.error}>{statusMessage}</TextL>
					)}
				</>
			)}
		</div>
	);
};

export default NewsletterForm;
