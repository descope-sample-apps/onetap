import type { Document } from '@contentful/rich-text-types';

export interface FAQItem {
	id: string;
	title: string;
	description: Document | null;
}

export interface FAQProps {
	faqItems: FAQItem[];
	isInRichText?: boolean;
}
