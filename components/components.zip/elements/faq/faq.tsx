'use client';

import {
	Collapsible,
	CollapsibleToggler,
	CollapsibleContent,
	CollapsibleGroup
} from '@faceless-ui/collapsibles';
import clsx from 'clsx';
import { useState } from 'react';

import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';
import { HeadingS, TextM, TextS } from '@/components/elements/typography';
import { Icon } from '@/components/elements/icon';

import styles from './faq.module.scss';
import type { FAQProps, FAQItem as FAQItemType } from './faq.types';

const FAQItem = ({
	isInRichText,
	...faq
}: FAQItemType & { isInRichText?: boolean }) => {
	const [isFaqOpen, setIsFaqOpen] = useState<boolean>(false);

	const Text = isInRichText ? TextS : TextM;

	const handleFaqToggle = () => setIsFaqOpen((current) => !current);

	return (
		<Collapsible onToggle={handleFaqToggle}>
			<div className={clsx(styles.faqItem, isFaqOpen && styles.isOpen)}>
				<CollapsibleToggler
					className={styles.faqTitleWrapper}
					aria-label={`${isFaqOpen ? 'Close' : 'Open'} question: ${faq.title}`}
				>
					<HeadingS as={isInRichText ? 'h4' : 'h3'}>{faq.title}</HeadingS>
					<Icon name="ChevronDown" />
				</CollapsibleToggler>
				<CollapsibleContent className={styles.faqContent}>
					<Text as={isInRichText ? 'p' : 'span'}>
						{faq.description && RichTextRenderer(styles)(faq.description)}
					</Text>
				</CollapsibleContent>
			</div>
		</Collapsible>
	);
};

const FAQ = ({ faqItems, isInRichText }: FAQProps) => {
	return (
		<div className={clsx(styles.faq, isInRichText && styles.isInRichText)}>
			<CollapsibleGroup
				transTime={500}
				transCurve="cubic-bezier(0.59, 0, 0.06, 1)"
				allowMultiple={true}
			>
				{faqItems?.map((faqItem) => (
					<FAQItem key={faqItem.id} {...faqItem} isInRichText={isInRichText} />
				))}
			</CollapsibleGroup>
		</div>
	);
};

export default FAQ;
