import FAQ from './faq';

export * from './faq.types';
export { FAQ };
