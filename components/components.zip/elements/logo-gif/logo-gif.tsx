import Image from 'next/image';
import type { JSX } from 'react';
import clsx from 'clsx';

import Logo from '@/assets/logo/logo.gif';
import { Link } from '@/components/elements/link';
import routes from '@/lib/routes';

import styles from './logo-gif.module.scss';
import type { LogoGIFProps } from './logo-gif.types';

const LogoGIF = ({ className, large }: LogoGIFProps): JSX.Element => (
	<Link
		href={routes.HOME_ROUTE}
		className={className}
		aria-label="Go to Homepage"
	>
		<div className={clsx(styles.logo, large && styles.large)}>
			<Image
				alt="Descope Logo"
				src={Logo}
				fill
				sizes="118"
				priority
				unoptimized
			/>
		</div>
	</Link>
);

export default LogoGIF;
