import LogoGIF from './logo-gif';

export default LogoGIF;
