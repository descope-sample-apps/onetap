export interface LogoGIFProps {
	large?: boolean;
	className?: string;
}
