'use client';

import { useId } from 'react';
import { Tooltip as ReactTooltip } from 'react-tooltip';
import clsx from 'clsx';

import { TextS } from '../typography';

import type { TooltipProps } from './tooltip.types';
import styles from './tooltip.module.scss';

const Tooltip = ({
	label,
	children,
	place = 'top',
	className
}: TooltipProps) => {
	const tooltipId = useId();

	return (
		<>
			<button
				data-tooltip-id={tooltipId}
				aria-describedby={tooltipId}
				// data-tooltip-content={label}
				aria-hidden
				tabIndex={-1}
			>
				{children}
			</button>
			<ReactTooltip
				globalCloseEvents={{ escape: true }}
				noArrow
				place={place}
				id={tooltipId}
				className={clsx(styles.tooltip, className)}
				aria-hidden="true"
			>
				<TextS isMedium aria-hidden="true">
					{label}
				</TextS>
			</ReactTooltip>
		</>
	);
};

export default Tooltip;
