import Tooltip from './tooltip';

export default Tooltip;
