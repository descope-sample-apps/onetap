import { type ReactNode } from 'react';
import type { PlacesType } from 'react-tooltip';

export interface TooltipProps {
	label: ReactNode;
	children: ReactNode;
	className?: string;
	place?: PlacesType;
}
