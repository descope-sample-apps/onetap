import { getInstatusMessage } from '@/lib/services/instatus';

import Link from '../link/link';
import { TextM } from '../typography';

import styles from './systems-status-badge.module.scss';
import type { SystemStatusBadgeProps } from './systems-status-badge.types';

const renderStatusCode: Record<string, string> = {
	'All systems operational': 'operational',
	'Has Issues': 'issues',
	'Under Maintenance': 'maintenance'
};

const SystemStatusBadge = async ({
	statusPlatformUrl
}: SystemStatusBadgeProps) => {
	const status = await getInstatusMessage();
	const statusUrl = new URL(statusPlatformUrl);
	const statusCode = renderStatusCode[status];

	// fallback to iframe if API fails
	if (status === 'Unknown status') {
		return (
			<iframe
				width="230"
				height="50"
				src={statusPlatformUrl?.replace('dark-md', 'light-sm')}
				scrolling="no"
				loading="lazy"
				frameBorder="0"
				title="Descope Site Status"
			/>
		);
	}

	return (
		<Link
			className={styles.badgeLink}
			href={`${statusUrl.protocol}//${statusUrl.host}`}
		>
			<div data-status={statusCode} className={styles.badge}>
				<span className={styles.circleStatus} />
				<TextM isMedium>{status}</TextM>
			</div>
		</Link>
	);
};

export default SystemStatusBadge;
