export type SystemStatusBadgeProps = {
	className?: string;
	statusPlatformUrl: string;
};
