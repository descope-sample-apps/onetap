import RichTextContent from './rich-text-content';

export default RichTextContent;
