import type { Document } from '@contentful/rich-text-types';

import RichTextRenderer from '../rich-text-renderer';

import styles from './rich-text-content.module.scss';

const RichTextContent = ({ content }: { content: Document }) => {
	return (
		<div className={styles.article}>{RichTextRenderer(styles)(content)}</div>
	);
};

export default RichTextContent;
