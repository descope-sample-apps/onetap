import SectionDivider from './section-divider';

export default SectionDivider;
