export interface SearchProps {
	id: string;
	suggestionTitle: string;
	placeholder: string;
	allowSearchFor?: 'blog' | 'learn';
	className?: string;
}
