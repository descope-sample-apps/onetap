'use client';

import clsx from 'clsx';

import isExternalPage from '@/lib/helper/is-external-page';
import { Link } from '@/components/elements/link';
import type { LCPostMin } from '@/types/learning-center/post';

import { LabelS, TextM } from '../typography';
import { Icon } from '../icon';

import styles from './search.module.scss';

export const PostItem = (post: LCPostMin) => {
	const postDate = post.excerpt?.split('<b>...</b>')[0] || '';
	const isInvalidDate = new Date(postDate)?.toString() === 'Invalid Date';
	const excerpt = !isInvalidDate
		? post.excerpt?.replace(postDate, '')
		: post.excerpt;

	return (
		<Link
			className={styles.searchResult}
			href={post.slug}
			newTab={isExternalPage(post.slug)}
		>
			<div>
				{!isInvalidDate && (
					<LabelS
						dangerouslySetInnerHTML={{ __html: postDate }}
						className={styles.resultDate}
					/>
				)}
				<TextM
					isMedium
					className={clsx(styles.text, styles.resultTitle)}
					dangerouslySetInnerHTML={{ __html: post.title }}
				/>
				{excerpt && (
					<TextM
						className={styles.text}
						dangerouslySetInnerHTML={{
							__html: !isInvalidDate ? excerpt : post.excerpt
						}}
					/>
				)}
			</div>
			<div className={styles.arrowIcon}>
				<Icon name="ArrowRight" />
			</div>
		</Link>
	);
};
