'use client';

import clsx from 'clsx';
import type { ChangeEvent, FormEvent } from 'react';
import { useState } from 'react';
import ClickAwayListener from 'react-click-away-listener';

import useToggle from '@/hooks/use-toggle';
import type { LCPostMin } from '@/types/learning-center/post';
import type { VertexAISearchResponse } from '@/lib/services/vertex-search/types';

import Input from '../input';
import { LabelS, TextM } from '../typography';
import { Icon } from '../icon';

import { PostItem } from './search-item';
import styles from './search.module.scss';
import type { SearchProps } from './search.types';

const SITE_URL =
	process.env.URL || process.env.VERCEL_URL || 'https://www.descope.com';

const renderPostsList = (post: LCPostMin) => (
	<li className={styles.searchPostLink} key={post.id || post.slug}>
		<PostItem {...post} />
	</li>
);

const getPosts = async (
	searchTerm: string,
	searchFor?: SearchProps['allowSearchFor']
): Promise<LCPostMin[]> => {
	const data = (await fetch(
		`/api/search?searchTerm=${searchTerm}&searchFor=${searchFor ?? ''}`
	).then((data) => data.json())) as VertexAISearchResponse;

	const newPosts =
		data.results?.map(({ id, document }) => {
			const postData = document.derivedStructData;
			const itemLink = new URL(postData?.link);
			return {
				id,
				title: postData.htmlTitle,
				excerpt: postData.snippets?.[0]?.htmlSnippet,
				slug: itemLink.origin === SITE_URL ? itemLink.pathname : postData?.link,
				type: 'LCPost'
			} satisfies LCPostMin;
		}) ?? [];

	return newPosts;
};

export const Search = ({
	placeholder,
	suggestionTitle,
	allowSearchFor,
	className
}: SearchProps) => {
	const {
		isOn: showPosts,
		setOn: setShowPostsOn,
		setOff: setShowPostsOff
	} = useToggle();
	const {
		isOn: isFetching,
		setOn: setIsFetchingOn,
		setOff: setIsFetchingOff
	} = useToggle();
	const [searchTerm, setSearchTerm] = useState('');
	const [posts, setPosts] = useState<LCPostMin[]>([]);

	const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
		setSearchTerm(e.target.value);
	};

	const handleSearch = async (e: FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		setShowPostsOn();
		if (!searchTerm) return setPosts([]);
		setIsFetchingOn();
		const newPosts = await getPosts(searchTerm, allowSearchFor);
		setPosts(newPosts);
		setIsFetchingOff();
	};

	const clearSearchTerm = () => {
		setSearchTerm('');
		setShowPostsOff();
	};

	return (
		<ClickAwayListener onClickAway={setShowPostsOff}>
			<div className={className}>
				<form onSubmit={handleSearch} className={styles.searchWrapper}>
					<Input
						name="search posts"
						aria-label="Search for a post"
						className={{ input: styles.searchInput }}
						type="search"
						placeholder={placeholder}
						value={searchTerm}
						onChange={handleSearchChange}
						icon="Search"
					/>
				</form>

				{searchTerm && (
					<button
						aria-label="Clear search"
						onClick={clearSearchTerm}
						className={styles.clearButton}
					>
						<Icon name="RemoveCircle" role="presentation" />
					</button>
				)}

				{showPosts && (
					<div className={clsx(styles.searchPosts)}>
						{(isFetching || posts.length > 0) && (
							<LabelS className={styles.searchPostsTitle}>
								{suggestionTitle}
							</LabelS>
						)}
						{isFetching ? (
							<TextM isMedium className={styles.noResults}>
								Fetching results
							</TextM>
						) : posts.length ? (
							<ul className={styles.searchPostsList}>
								{posts.map(renderPostsList)}
							</ul>
						) : (
							<TextM isMedium className={styles.noResults}>
								No results
							</TextM>
						)}
					</div>
				)}
			</div>
		</ClickAwayListener>
	);
};

export default Search;
