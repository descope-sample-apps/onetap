import type { SVGProps } from 'react';

export interface LogoProps extends SVGProps<SVGSVGElement> {
	large?: boolean;
}
