import type { ElementType } from 'react';
import clsx from 'clsx';
import type { ThreeElements } from '@react-three/fiber';

import type { TypographyProps } from '../typography.types';

import styles from './labels.module.scss';

export const LabelM = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'label';

	return (
		<Component {...props} className={clsx(styles.LabelM, className)}>
			{children}
		</Component>
	);
};

export const LabelS = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'label';

	return (
		<Component {...props} className={clsx(styles.LabelS, className)}>
			{children}
		</Component>
	);
};
