import clsx from 'clsx';
import type { ElementType } from 'react';
import type { ThreeElements } from '@react-three/fiber';

import type { TypographyProps } from '../typography.types';

import styles from './headings.module.scss';

export const HeadingXXL = <
	T extends Exclude<ElementType, keyof ThreeElements>
>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h1';

	return (
		<Component {...props} className={clsx(styles.HeadingXXL, className)}>
			{children}
		</Component>
	);
};

export const HeadingXL = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h2';

	return (
		<Component {...props} className={clsx(styles.HeadingXL, className)}>
			{children}
		</Component>
	);
};

export const HeadingL = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h3';

	return (
		<Component {...props} className={clsx(styles.HeadingL, className)}>
			{children}
		</Component>
	);
};

export const HeadingM = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h4';

	return (
		<Component {...props} className={clsx(styles.HeadingM, className)}>
			{children}
		</Component>
	);
};
export const HeadingS = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h5';

	return (
		<Component {...props} className={clsx(styles.HeadingS, className)}>
			{children}
		</Component>
	);
};
export const HeadingXS = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'h6';

	return (
		<Component {...props} className={clsx(styles.HeadingXS, className)}>
			{children}
		</Component>
	);
};
