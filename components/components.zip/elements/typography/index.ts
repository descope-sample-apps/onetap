// new components
export * from './headings/headings';
export * from './texts/texts';
export * from './labels/labels';
export * from './text-highlight';
export type * from './typography.types';
