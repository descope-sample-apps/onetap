import clsx from 'clsx';
import { type ElementType } from 'react';
import type { ThreeElements } from '@react-three/fiber';

import type { TypographyProps } from '../typography.types';

import styles from './texts.module.scss';

export const TextXXL = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	isMedium,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'p';

	return (
		<Component
			{...props}
			className={clsx(styles.TextXXL, isMedium && styles.medium, className)}
		>
			{children}
		</Component>
	);
};

export const TextXL = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	isMedium,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'p';

	return (
		<Component
			{...props}
			className={clsx(styles.TextXL, isMedium && styles.medium, className)}
		>
			{children}
		</Component>
	);
};

export const TextL = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	isMedium,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'p';

	return (
		<Component
			{...props}
			className={clsx(styles.TextL, isMedium && styles.medium, className)}
		>
			{children}
		</Component>
	);
};

export const TextM = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	isMedium,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'p';

	return (
		<Component
			{...props}
			className={clsx(styles.TextM, isMedium && styles.bold, className)}
		>
			{children}
		</Component>
	);
};

export const TextS = <T extends Exclude<ElementType, keyof ThreeElements>>({
	as,
	children,
	className,
	isMedium,
	...props
}: TypographyProps<T>) => {
	const Component = as || 'p';

	return (
		<Component
			{...props}
			className={clsx(styles.TextS, isMedium && styles.bold, className)}
		>
			{children}
		</Component>
	);
};
