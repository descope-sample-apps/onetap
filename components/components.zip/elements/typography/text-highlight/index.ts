export { default as TextHighlight } from './text-highlight';
export type * from './text-highlight.types';
