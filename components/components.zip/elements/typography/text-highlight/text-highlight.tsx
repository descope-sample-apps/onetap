import type { FC } from 'react';
import clsx from 'clsx';

import type { TextHighlightProps } from './text-highlight.types';
import styles from './text-highlight.module.scss';

const TextHighlight: FC<TextHighlightProps> = ({
	children,
	injectHTML,
	...props
}) => {
	if (typeof children === 'string' && injectHTML) {
		return (
			<span
				dangerouslySetInnerHTML={{ __html: children }}
				{...props}
				className={clsx(styles.highlight, props.className)}
			/>
		);
	}

	return (
		<span {...props} className={clsx(styles.highlight, props.className)}>
			{children}
		</span>
	);
};

export default TextHighlight;
