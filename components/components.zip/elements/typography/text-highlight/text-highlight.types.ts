import type { HTMLAttributes, ReactNode } from 'react';

export interface TextHighlightProps extends HTMLAttributes<HTMLSpanElement> {
	children?: ReactNode;
	injectHTML?: boolean;
}
