import type { ComponentPropsWithoutRef, ElementType, ReactNode } from 'react';

export type TypographyProps<T extends ElementType> = Omit<
	ComponentPropsWithoutRef<T>,
	'as' | 'children' | 'className'
> & {
	as?: T;
	className?: string;
	children?: ReactNode;
	isMedium?: boolean;
	id?: string;
};
