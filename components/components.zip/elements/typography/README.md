# Typography Components

## General Props

All typography elements (headings and texts) accept the following props:

- `as`: to change element type from default (default depends on the component, ex. HeadingXXL renders an `h1` element type).
  options: `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `p`, `span` or `code`.

```HTML
<HeadingXXL as="p">This is now a `p` element</HeadingXXL>
```

- `className`: to add a class to the element for styling

```HTML
<HeadingXXL className="align-left">This element now has an “align-left” class</HeadingXXL>
```

## Heading Components

### Heading XXL

```HTML
<HeadingXXL>Heading XXL</HeadingXXL>
```

### Heading XL

```HTML
<HeadingXL>Heading XL</HeadingXL>
```

### Heading L

```HTML
<HeadingL>Heading L</HeadingL>
```

### Heading M

```HTML
<HeadingM>Heading M</HeadingM>
```

### Heading S

```HTML
<HeadingS>Heading S</HeadingS>
```

### Heading XS

```HTML
<HeadingXS>Heading XS</HeadingXS>
```

## Texts

### Text XXL

```HTML
<TextXXL>Text XXL</TextXXL>
```

### Text XL

```HTML
<TextXL>Text XL</TextXL>
```

### Text L

```HTML
<TextL>Text L</TextL>
```

### Text M

```HTML
<TextM>Text M</TextM>
```

### Text S

```HTML
<TextS>Text S</TextS>
```

## Labels

### Label

This is referenced as Label/M in the design

```HTML
<Label>Label</Label>
```
