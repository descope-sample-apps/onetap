'use client';

import clsx from 'clsx';
import { useRouter } from 'next/navigation';

import Button from '@/components/elements/button';
import routes from '@/lib/routes';

import styles from './back-to-blog.module.scss';

const BackToBlogButton = ({ className }: { className?: string }) => {
	const router = useRouter();

	const handleClick = () => {
		const lastPage = window.sessionStorage.getItem('lastPage');

		router.push(lastPage ?? routes.BLOG_ROUTE);
	};

	return (
		<Button
			newVariant="tertiary"
			iconName="ArrowLeft"
			iconAlignment="left"
			size="large"
			className={clsx(styles.btn, className)}
			onClick={handleClick}
		>
			Back to blog
		</Button>
	);
};

export default BackToBlogButton;
