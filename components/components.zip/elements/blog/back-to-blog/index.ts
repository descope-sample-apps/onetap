import BackToBlogButton from './back-to-blog';

export default BackToBlogButton;
