import { SocialLinks } from '@/components/elements/social-links';
import { NewsletterForm } from '@/components/elements/newsletter-form';

import styles from './sidebar-elements.module.scss';

const SidebarElements = ({
	newsletterText,
	newsletterClassName
}: {
	newsletterText?: string;
	newsletterClassName?: string;
}) => {
	return (
		<div className={styles.container}>
			<NewsletterForm
				newsletterText={newsletterText}
				className={newsletterClassName}
			/>
			<SocialLinks />
		</div>
	);
};

export default SidebarElements;
