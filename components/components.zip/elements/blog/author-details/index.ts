import BackToBlogButton from './author-details';

export default BackToBlogButton;
