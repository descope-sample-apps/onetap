import type { Image } from '@/types/image';

export interface AuthorDetailsProps {
	id: string;
	name: string;
	slug: string;
	image: Image;
	title?: string;
	className?: string;
}
