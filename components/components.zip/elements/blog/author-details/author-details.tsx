import Image from 'next/image';
import clsx from 'clsx';

import { Link } from '@/components/elements/link';
import { TextL } from '@/components/elements/typography';

import styles from './author-details.module.scss';
import type { AuthorDetailsProps } from './author-details.types';

const AuthorDetails = (props: AuthorDetailsProps) => {
	const { image, name, title, slug, className } = props;

	const authorHref = `/blog/author/${slug}`;
	return (
		<div className={clsx(styles.author, className)}>
			<div className={styles.authorImageContainer}>
				{image && (
					<Image src={image?.src} alt={image?.alt || ''} fill sizes="5vw" />
				)}
			</div>
			<div className={styles.authorDetails}>
				<Link href={authorHref} rel="author" className={styles.authorLink}>
					<TextL isMedium className={styles.authorName}>
						{name}
					</TextL>
				</Link>

				<TextL isMedium className={styles.authorTitle}>
					{title}
				</TextL>
			</div>
		</div>
	);
};

export default AuthorDetails;
