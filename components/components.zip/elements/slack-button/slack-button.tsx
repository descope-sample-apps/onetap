'use client';

import clsx from 'clsx';

import { useSlackChatButtonContext } from '@/components/providers/slack-chat-button';

import { TextS } from '../typography';

import styles from './slack-button.module.scss';
import { SlackIcon } from './slack-icon';

interface ChatButtonProps {
	variant?: 'light' | 'dark';
	isBig?: boolean;
	slackChatId?: string;
}

const DEFAULT_SLACK_CHAT_ID = 'V5mA8i';

export const SlackButton = ({
	variant = 'light',
	isBig = false,
	slackChatId = DEFAULT_SLACK_CHAT_ID
}: ChatButtonProps) => {
	const { isSlackButtonActive } = useSlackChatButtonContext();

	if (!isSlackButtonActive) {
		return null;
	}

	return (
		<div className={styles.slackButtonWrapper}>
			<a
				href={`https://start-chat.com/slack/descope/${slackChatId}`}
				aria-label="Chat with Sales via Slack"
				target="_blank"
				rel="noopener noreferrer"
				className={clsx([
					styles.button,
					variant === 'dark' ? styles.dark : styles.light,
					isBig && styles.isBig
				])}
			>
				<div className={styles.content}>
					<SlackIcon />
					<span>Chat with Sales</span>
				</div>
			</a>
			<div className={styles.subtitle}>
				<TextS>Anonymously - no Slack account required</TextS>
			</div>
		</div>
	);
};
