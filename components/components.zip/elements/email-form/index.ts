import EmailForm from './email-form';

export default EmailForm;
