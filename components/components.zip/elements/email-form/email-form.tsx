/* eslint-disable no-console */
import clsx from 'clsx';
import type { FC } from 'react';

import type { NewsletterSignupProps } from '../../sections/newsletter-signup/newsletter-signup.types';
import Button from '../button/button';
import Input from '../input';
import { TextS } from '../typography';

import styles from './email-form.module.scss';

const EmailForm: FC<
	NewsletterSignupProps & { inputClass?: string; formClass?: string }
> = ({ heading, buttonText, inputClass, formClass, inputPlaceholder }) => (
	<>
		<form className={clsx(styles.emailForm, formClass)}>
			<Input
				name="email"
				className={{ input: clsx(styles.emailInput, inputClass) }}
				type="email"
				placeholder={inputPlaceholder}
				value=""
				onChange={console.debug}
			/>
			<Button
				variant="small"
				className={styles.detailsButton}
				onClick={console.debug}
			>
				{buttonText}
			</Button>
		</form>
		{heading && <TextS className={styles.emailTag}>{heading}</TextS>}
	</>
);

export default EmailForm;
