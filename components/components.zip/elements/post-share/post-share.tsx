'use client';

import { LinkedinShareButton, TwitterShareButton } from 'react-share';
import clsx from 'clsx';
import { usePathname } from 'next/navigation';
import dynamic from 'next/dynamic';

import { TextL } from '../typography';
import { Icon } from '../icon';

import styles from './post-share.module.scss';

const getShareUrl = (pathname: string) => {
	if (typeof window === 'undefined') {
		return '';
	}
	return pathname ? `${window.location.origin}${pathname}` : '';
};

const PostShare = ({ className }: { className?: string }) => {
	const pathname = usePathname();

	return pathname ? (
		<div className={clsx(styles.share, className)}>
			<TextL isMedium className={styles.shareText}>
				Share on:
			</TextL>
			<div className={styles.links}>
				<LinkedinShareButton
					url={getShareUrl(pathname)}
					className={styles.link}
				>
					<p className="visually-hidden">Share on LinkedIn</p>
					<Icon role="presentation" name="LinkedIn" />
				</LinkedinShareButton>
				<TwitterShareButton url={getShareUrl(pathname)} className={styles.link}>
					<p className="visually-hidden">Share on X</p>
					<Icon role="presentation" name="X" />
				</TwitterShareButton>
				<a
					href={`https://bsky.app/intent/compose?text=${getShareUrl(pathname)}`}
					target="_blank"
					rel="noreferrer"
				>
					<p className="visually-hidden">Share on Blusky</p>
					<Icon role="presentation" name="Bluesky" />
				</a>
			</div>
		</div>
	) : null;
};

export default dynamic(() => Promise.resolve(PostShare), {
	ssr: false,
	loading: () => <PostShare />
});
