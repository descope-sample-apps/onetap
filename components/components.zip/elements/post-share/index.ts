import PostShare from './post-share';

export default PostShare;
