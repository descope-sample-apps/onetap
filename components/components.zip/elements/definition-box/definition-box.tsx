import clsx from 'clsx';
import type React from 'react';
import { type HTMLProps } from 'react';

import { Link } from '@/components/elements/link';
import Container from '@/components/elements/container';
import { Icon } from '@/components/elements/icon';
import RenderBlock from '@/components/elements/blocks/blocks';
import LightboxImage from '@/components/elements/lightbox-image';
import { HeadingXL, TextL, TextM } from '@/components/elements/typography';
import richTextRenderer from '@/components/elements/rich-text-renderer';

import styles from './definition-box.module.scss';
import type {
	DefinitionBoxItem,
	DefinitionBoxProps
} from './definition-box.types';

const renderDefinitionBlockItem = ({
	id,
	href,
	text,
	iconName
}: DefinitionBoxItem) => {
	const Component = href ? Link : 'div';

	return (
		<Component
			// @ts-expect-error
			href={href || null}
			className={styles.blockItem}
			key={id}
			id={id}
		>
			{iconName && (
				<div className={styles.blockIcon}>
					<Icon name={iconName} />
				</div>
			)}
			{text && (
				<TextL as="span" isMedium className={styles.itemName}>
					{text}
				</TextL>
			)}
		</Component>
	);
};

const renderDefinitionImageItem = ({
	iconName,
	text,
	href,
	id
}: DefinitionBoxItem) => {
	return href ? (
		<div key={id} className={styles.imageLink}>
			<Link href={href} className={styles.item}>
				{iconName && (
					<div className={styles.blockIcon}>
						<Icon name={iconName} />
					</div>
				)}
				{text && (
					<TextL as="span" className={styles.itemName}>
						{text}
					</TextL>
				)}
			</Link>
		</div>
	) : null;
};

const renderDefinitionBoxItem = (item: DefinitionBoxItem) => {
	if (item.text) return renderDefinitionBlockItem(item);
	return renderDefinitionImageItem(item);
};

const DefinitionBox: React.FC<
	DefinitionBoxProps & HTMLProps<HTMLDivElement> & { order: 'odd' | 'even' }
> = ({
	image,
	items,
	title,
	content,
	subtitle,
	className,
	blocks,
	order,
	...rest
}) => {
	const isImageLinkItems = items.every((item) => !item.text);

	return (
		<div className={clsx(styles.box, className)} {...rest} data-order={order}>
			<Container className={styles.content}>
				<div className={styles.body}>
					<HeadingXL as="h3" className={styles.title}>
						{title}
					</HeadingXL>
					{content && richTextRenderer(styles)(content)}
				</div>
				<div className={styles.image}>
					<div className={styles.imageWrapper}>
						{image && (
							<LightboxImage
								imageProps={{
									src: image.src,
									alt: image.alt || '',
									fill: true,
									sizes: '771',
									objectFit: 'cover'
								}}
							/>
						)}
					</div>
				</div>
				{(subtitle || Boolean(items.length)) && (
					<div className={styles.gridItems}>
						{subtitle && <TextM className={styles.subtitle}>{subtitle}</TextM>}
						<div
							className={clsx(
								styles.gridItemsGrid,
								isImageLinkItems && styles.imageItems
							)}
						>
							{items.map(renderDefinitionBoxItem)}
						</div>
					</div>
				)}
				{blocks && (
					<div className={styles.subblocks}>
						<RenderBlock
							blocks={blocks}
							formClass={styles.emailForm}
							inputClass={styles.emailInput}
						/>
					</div>
				)}
			</Container>
		</div>
	);
};

export default DefinitionBox;
