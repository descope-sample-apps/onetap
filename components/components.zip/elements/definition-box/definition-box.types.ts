import type { Document } from '@contentful/rich-text-types';

import type { Image } from '@/types/image';
import type { IconVariant } from '@/components/elements/icon';
import type { Block } from '@/types/block';

export type DefinitionBoxItem = {
	id: string;
	href?: string;
	image?: Image;
	text?: string;
	iconName?: IconVariant;
};

export interface DefinitionBoxProps {
	image?: Image;
	title: string;
	subtitle: string;
	content: Document | null;
	items: DefinitionBoxItem[];
	blocks?: Block[] | null;
}
