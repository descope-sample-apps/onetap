import clsx from 'clsx';
import type { ReactNode } from 'react';

import { Link } from '@/components/elements/link';
import BlogTag from '@/components/sections/blog/blog-tag';
import isExternalPage from '@/lib/helper/is-external-page';

import { HeadingS, HeadingXS, TextL, TextM } from '../typography';
import Button from '../button/button';
import type { IconVariant } from '../icon';
import { Icon } from '../icon';

import type { CardProps } from './card.types';
import styles from './card.module.scss';

const getHeading = (variant: string) => {
	switch (variant) {
		case 'horizontal-icon-top':
		case 'fluid':
			return HeadingS;
		case 'no-background':
		case 'no-background-centered':
			return TextL;
		default:
			return HeadingXS;
	}
};
interface WrapperProps {
	href?: string;
	linkText?: string;
	className?: string;
	children: ReactNode;
}
/* Render correctly Wrapper tag, this way avoid having href attr on divs */
const WrapperComponent = ({
	href,
	linkText,
	children,
	...props
}: WrapperProps) => {
	const Wrapper = href && !linkText ? Link : 'div';
	const isExternal = isExternalPage(href ?? '');

	return (
		<>
			{Wrapper === 'div' ? (
				<Wrapper {...props}>{children}</Wrapper>
			) : (
				<Wrapper href={href ?? ''} newTab={isExternal} {...props}>
					{children}
				</Wrapper>
			)}
		</>
	);
};

const Card = ({
	title,
	description,
	iconName,
	href,
	linkText,
	variant = 'horizontal-icon-top',
	tags = [],
	isStep = false,
	isActive = false,
	className
}: CardProps) => {
	const Heading = getHeading(variant);

	return (
		<WrapperComponent
			href={href}
			linkText={linkText}
			data-is-step={isStep}
			data-variant={variant}
			className={clsx(styles.card, isActive && styles.active, className)}
		>
			{iconName && (
				<div className={styles.imageContainer}>
					<Icon name={iconName as IconVariant} className={styles.icon} />
				</div>
			)}

			{tags.length > 0 && (
				<div className={styles.tags}>
					{tags.map((tag) => (
						<BlogTag key={tag} text={tag} />
					))}
				</div>
			)}

			<div className={styles.info}>
				{title && (
					<Heading
						as="h3"
						{...(variant === 'no-background' ||
						variant === 'no-background-centered'
							? { isMedium: true }
							: {})}
						className={styles.title}
					>
						{title}
					</Heading>
				)}
				{description && (
					<TextM className={styles.description}>{description}</TextM>
				)}
				{href && linkText && (
					<Button
						size="large"
						newVariant="tertiary"
						iconName="ArrowRight"
						href={href}
						className={styles.cardButton}
					>
						{linkText || ''}
					</Button>
				)}
			</div>
		</WrapperComponent>
	);
};

export default Card;
