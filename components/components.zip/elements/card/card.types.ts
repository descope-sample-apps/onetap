import type { IconVariant } from '../icon';

export type CardVariant =
	| 'vertical'
	| 'horizontal-icon-top'
	| 'horizontal-icon-left'
	| 'fluid'
	| 'no-background'
	| 'no-background-centered';

export interface CardProps {
	id: string;
	title?: string;
	description?: string;
	iconName?: IconVariant;
	blockType?: string;
	href?: string;
	linkText?: string;
	variant?: CardVariant;
	isStep?: boolean;
	isActive?: boolean;
	className?: string;
	tags?: string[];
}
