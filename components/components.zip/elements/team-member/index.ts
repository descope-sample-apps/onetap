import TeamMember from './team-member';

export default TeamMember;
