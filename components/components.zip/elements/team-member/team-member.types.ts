import type { Image } from '@/types/image';

import type { IconVariant } from '../icon';

export interface TeamMemberProps {
	name?: string;
	subheading?: string;
	photo?: Image;
	additionalText?: string;
	links?: Array<{
		id: string;
		icon?: IconVariant;
		image?: Image;
		href?: string;
	}>;
	variant?: 'default' | 'large';
	className?: string;
}
