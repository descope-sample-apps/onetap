import Image from 'next/image';
import Link from 'next/link';
import clsx from 'clsx';

import { HeadingXS, TextM } from '../typography';
import { Icon } from '../icon';

import type { TeamMemberProps } from './team-member.types';
import styles from './team-member.module.scss';

const TeamMember = ({
	name,
	subheading,
	additionalText,
	photo,
	links,
	variant = 'default',
	className
}: TeamMemberProps) => {
	return (
		<div data-variant={variant} className={clsx(styles.card, className)}>
			<figure className={styles.imageContainer}>
				{photo && (
					<Image
						src={photo?.src}
						alt={photo?.alt || ''}
						fill
						sizes="(max-width: 148px) 100vw, 148px"
					/>
				)}
			</figure>
			{name && (
				<HeadingXS as="p" className={styles.name}>
					{name}
				</HeadingXS>
			)}
			{subheading && <TextM className={styles.subheading}>{subheading}</TextM>}
			{additionalText && (
				<TextM className={styles.additional}>{additionalText}</TextM>
			)}
			{links && links.length > 0 && (
				<div className={styles.links}>
					{links.map(({ id, icon, image, href }) =>
						href ? (
							<Link key={id} href={href} className={styles.link}>
								{icon && <Icon name={icon} />}
								{!icon && image && (
									<Image src={image.src} alt={image.alt || ''} fill />
								)}
							</Link>
						) : null
					)}
				</div>
			)}
		</div>
	);
};

export default TeamMember;
