# Popup Modal Using Faceless UI

In order to use the popup, a unique slug should be generated to identify the modal, example using React useId & pass as Popup prop
e.g modal-jj3er

To access the popup, create a button that toggles the popup using the useModal hook from modal context.

## Props

- uniqueSlug (`string`) - generate unique slug
- children (`ReactNode`) - contents of the Popup i.e header, body or button
- wrapperClass(`string`) - modal className (optional)
