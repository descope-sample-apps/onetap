'use client';

import { Modal, ModalToggler, useModal } from '@faceless-ui/modal';
import clsx from 'clsx';

import Button from '../button/button';

import styles from './popup.module.scss';
import type { PopupProps } from './popup.types';

const Popup = ({
	children,
	wrapperClass,
	closeIconClass,
	uniqueSlug,
	theme = 'dark'
}: PopupProps) => {
	const modal = useModal();
	const { oneModalIsOpen } = modal;

	return (
		<Modal
			slug={uniqueSlug}
			className={clsx(styles.modal, wrapperClass, theme, {
				[styles.modalFadeIn]: oneModalIsOpen,
				[styles.modalFadeOut]: !oneModalIsOpen
			})}
		>
			<ModalToggler
				aria-label="Close popup"
				slug={uniqueSlug}
				className={clsx(styles.closeIcon, closeIconClass)}
			>
				{/* @ts-ignore */}
				<Button as="span" newVariant="icon" iconName="Close" />
			</ModalToggler>
			<div>{children}</div>
		</Modal>
	);
};

export default Popup;
