import type { ReactNode } from 'react';

import type { SectionTheme } from '@/types/page-block';

export interface PopupProps {
	children: ReactNode | ReactNode[];
	uniqueSlug: string;
	wrapperClass?: string;
	closeIconClass?: string;
	theme?: SectionTheme;
}
