import dynamic from 'next/dynamic';

const Popup = dynamic(() => import('./popup'), { ssr: false });

export default Popup;
