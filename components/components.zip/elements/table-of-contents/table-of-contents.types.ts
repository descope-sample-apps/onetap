import type { Content } from '@/types/content';

export interface TableOfContentsProps {
	contents: Content[];
	className?: string;
}
