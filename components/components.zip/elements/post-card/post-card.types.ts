import type { BlogPostMin } from '@/types/blog/post';
import type { LCPostMin } from '@/types/learning-center/post';

export type PostCardProps = (
	| Omit<LCPostMin, 'type'>
	| Omit<BlogPostMin, 'type'>
) & {
	tabIndex?: number;
	className?: string;
	type: 'LCPost' | 'BlogPost' | 'Resource';
	ctaText?: string;
};
