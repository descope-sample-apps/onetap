'use client';
import Image from 'next/image';
import { useEffect, useRef } from 'react';
import { clsx } from 'clsx';
import Link from 'next/link';

import routes from '@/lib/routes';

import DateFormat from '../date-format/date-format';
import { HeadingS, LabelS, TextM } from '../typography';
import Button from '../button';

import styles from './post-card.module.scss';
import type { PostCardProps } from './post-card.types';

// currently we're hiding the excerpt for all post cards
// this is a request from the Abhi, until the posts excerpts
// are updated to be more relevant
const HIDE_EXCERPT = true;

const renderSlug = (type: PostCardProps['type'], slug: string) => {
	switch (type) {
		case 'BlogPost':
			return routes.BLOG_POST(slug);

		case 'LCPost':
			return routes.POST(slug);

		case 'Resource':
			return slug;

		default:
			return '';
	}
};

const PostCard = ({
	tileImage: image,
	slug,
	title,
	topic,
	publishedDate,
	lastModified,
	tabIndex,
	excerpt,
	className,
	type,
	ctaText = 'Read more'
}: PostCardProps) => {
	const postRef = useRef<HTMLAnchorElement>(null);
	const href = renderSlug(type, slug);

	useEffect(() => {
		if (tabIndex === 0) postRef?.current?.focus();
	}, [tabIndex]);

	const dateToShow = lastModified ? lastModified : publishedDate;
	return (
		<Link
			ref={postRef}
			href={href}
			className={clsx(styles.container, className)}
			target={type === 'Resource' ? '_blank' : undefined}
			{...(tabIndex === 0 && { tabIndex: tabIndex })}
		>
			<div className={styles.imageContainer}>
				{image && (
					<Image
						src={image.src}
						alt=""
						fill
						sizes="100vw"
						style={{
							objectFit: 'cover',
							maxWidth: '100%'
						}}
					/>
				)}
			</div>
			<div className={styles.details}>
				<LabelS>
					<span className={styles.category}>{topic?.name}</span>{' '}
					{topic && dateToShow && '|'}{' '}
					{dateToShow && (
						<span className={styles.date}>
							<DateFormat date={dateToShow} format="short" />
						</span>
					)}
				</LabelS>
				<HeadingS as="h3" className={styles.title} title={title}>
					{title}
				</HeadingS>
				{!HIDE_EXCERPT && excerpt && (
					<TextM className={styles.excerpt}>{excerpt}</TextM>
				)}
				<Button
					size="large"
					newVariant="tertiary"
					iconName="ArrowRight"
					href={href}
					className={styles.readMore}
					as="span"
				>
					{ctaText}
				</Button>
			</div>
		</Link>
	);
};

export default PostCard;
