import PostCard from './post-card';

export default PostCard;
