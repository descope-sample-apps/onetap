import GlobeAnimation from './globe-animation';

export default GlobeAnimation;
