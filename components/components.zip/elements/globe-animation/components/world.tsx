/* eslint-disable react/no-unknown-property */
import { OrbitControls } from '@react-three/drei';
import { extend, useThree, Canvas } from '@react-three/fiber';
import { useEffect } from 'react';
import { Scene, Fog, Vector3, type PerspectiveCamera } from 'three';
import ThreeGlobe from 'three-globe';

import useWindowSize from '@/hooks/use-window-size';

import type { WorldProps } from '../globe-animation.types';
import { cameraZ, calculateViewportFromWidth, getFOV } from '../utils';

import { Globe } from './globe';

extend({ ThreeGlobe });

const WebGLRendererConfig = () => {
	const { gl, size, camera } = useThree();
	const windowSize = useWindowSize();

	useEffect(() => {
		if (typeof window === 'undefined') return;
		gl.setPixelRatio(window.devicePixelRatio);
		gl.setSize(size.width, size.height, true);
		gl.setClearColor(0xffaaff, 0);
		gl.setViewport(...calculateViewportFromWidth(size, windowSize));
		(camera as PerspectiveCamera).fov = getFOV(windowSize.width);
		camera.updateProjectionMatrix();
	}, [windowSize]);

	return null;
};

const World = ({ globeConfig, data }: WorldProps) => {
	const scene = new Scene();
	scene.fog = new Fog(0xffffff, 400, 2000);

	return (
		<Canvas gl={{ antialias: false }} scene={scene} frameloop="demand">
			<WebGLRendererConfig />
			<ambientLight color={globeConfig.ambientLight} intensity={0.6} />
			<directionalLight
				color={globeConfig.directionalLeftLight}
				position={new Vector3(-400, 100, 400)}
			/>
			<directionalLight
				color={globeConfig.directionalTopLight}
				position={new Vector3(-200, 500, 200)}
			/>
			<pointLight
				color={globeConfig.pointLight}
				position={new Vector3(-200, 500, 200)}
				intensity={0.8}
			/>
			<Globe globeConfig={globeConfig} data={data} />
			<OrbitControls
				enableZoom={false}
				minDistance={cameraZ}
				maxDistance={cameraZ}
				autoRotateSpeed={1}
				autoRotate={true}
				minPolarAngle={Math.PI / 3.5}
				maxPolarAngle={Math.PI - Math.PI / 3}
			/>
		</Canvas>
	);
};

export default World;
