/* eslint-disable no-mixed-spaces-and-tabs */
import { useState, useRef, useEffect } from 'react';
import { Color } from 'three';
import type ThreeGlobe from 'three-globe';

import countries from '@/assets/data/globe.json';

import type { WorldProps } from '../globe-animation.types';
import { hexToRgb, RING_PROPAGATION_SPEED, genRandomNumbers } from '../utils';

let numbersOfRings = [0];

declare global {
	namespace React {
		namespace JSX {
			interface IntrinsicElements {
				threeGlobe: any;
			}
		}
	}
}

export const Globe = ({ globeConfig, data }: WorldProps) => {
	const [globeData, setGlobeData] = useState<
		| {
				size: number;
				order: number;
				color: (t: number) => string;
				lat: number;
				lng: number;
		  }[]
		| null
	>(null);

	const globeRef = useRef<ThreeGlobe | null>(null);

	const defaultProps = {
		pointSize: 1,
		atmosphereColor: '#ffffff',
		showAtmosphere: true,
		atmosphereAltitude: 0.1,
		polygonColor: 'rgba(255,255,255,0.7)',
		globeColor: '#1d072e',
		emissive: '#000000',
		emissiveIntensity: 0.1,
		shininess: 0.9,
		arcTime: 2000,
		arcLength: 0.9,
		rings: 1,
		maxRings: 3,
		...globeConfig
	};

	useEffect(() => {
		if (globeRef.current) {
			_buildData();
			_buildMaterial();
		}
	}, [globeRef.current]);

	const _buildMaterial = () => {
		if (!globeRef.current) return;

		const globeMaterial = globeRef.current.globeMaterial() as unknown as {
			color: Color;
			emissive: Color;
			emissiveIntensity: number;
			shininess: number;
		};
		globeMaterial.color = new Color(globeConfig.globeColor);
		globeMaterial.emissive = new Color(globeConfig.emissive);
		globeMaterial.emissiveIntensity = globeConfig.emissiveIntensity || 0.1;
		globeMaterial.shininess = globeConfig.shininess || 0.9;
	};

	const _buildData = () => {
		const arcs = data;
		let points = [];
		for (let i = 0; i < arcs.length; i++) {
			const arc = arcs[i];
			const rgb = hexToRgb(arc.color) as { r: number; g: number; b: number };
			points.push({
				size: defaultProps.pointSize,
				order: arc.order,
				color: (t: number) => `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${1 - t})`,
				lat: arc.startLat,
				lng: arc.startLng
			});
			points.push({
				size: defaultProps.pointSize,
				order: arc.order,
				color: (t: number) => `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${1 - t})`,
				lat: arc.endLat,
				lng: arc.endLng
			});
		}

		// remove duplicates for same lat and lng
		const filteredPoints = points.filter(
			(v, i, a) =>
				a.findIndex((v2) =>
					['lat', 'lng'].every(
						(k) => v2[k as 'lat' | 'lng'] === v[k as 'lat' | 'lng']
					)
				) === i
		);

		setGlobeData(filteredPoints);
	};

	useEffect(() => {
		if (globeRef.current && globeData) {
			globeRef.current
				.hexPolygonsData(countries.features)
				.hexPolygonResolution(4)
				.hexPolygonMargin(0)
				.showAtmosphere(defaultProps.showAtmosphere)
				.atmosphereColor(defaultProps.atmosphereColor)
				.atmosphereAltitude(defaultProps.atmosphereAltitude)
				.hexPolygonColor((_) => {
					return defaultProps.polygonColor;
				});
			startAnimation();
		}
	}, [globeData]);

	const startAnimation = () => {
		if (!globeRef.current || !globeData) return;

		globeRef.current
			.arcsData(data)
			.arcStartLat((d) => (d as { startLat: number }).startLat * 1)
			.arcStartLng((d) => (d as { startLng: number }).startLng * 1)
			.arcEndLat((d) => (d as { endLat: number }).endLat * 1)
			.arcEndLng((d) => (d as { endLng: number }).endLng * 1)
			.arcColor((e: any) => (e as { color: string }).color)
			.arcAltitude((e) => {
				return (e as { arcAlt: number }).arcAlt * 1;
			})
			.arcStroke((_) => {
				return [0.32, 0.28, 0.3][Math.round(Math.random() * 2)];
			})
			.arcDashLength(defaultProps.arcLength)
			.arcDashInitialGap((e) => (e as { order: number }).order * 1)
			.arcDashGap(15)
			.arcDashAnimateTime((_) => defaultProps.arcTime);

		globeRef.current
			.pointsData(data)
			.pointColor((e) => (e as { color: string }).color)
			.pointsMerge(true)
			.pointAltitude(0.0)
			.pointRadius(2);

		globeRef.current
			.ringsData([])
			.ringColor((e: any) => (t: any) => e.color(t))
			.ringMaxRadius(defaultProps.maxRings)
			.ringPropagationSpeed(RING_PROPAGATION_SPEED)
			.ringRepeatPeriod(
				(defaultProps.arcTime * defaultProps.arcLength) / defaultProps.rings
			);
	};

	useEffect(() => {
		if (!globeRef.current || !globeData) return;

		const interval = setInterval(() => {
			if (!globeRef.current || !globeData) return;
			numbersOfRings = genRandomNumbers(
				0,
				data.length,
				Math.floor((data.length * 4) / 5)
			);

			globeRef.current.ringsData(
				globeData.filter((d, i) => numbersOfRings.includes(i))
			);
		}, 2000);

		return () => {
			clearInterval(interval);
		};
	}, [globeRef.current, globeData]);

	return (
		<>
			<threeGlobe ref={globeRef} />
		</>
	);
};
