'use client';

import dynamic from 'next/dynamic';

import { sampleArcs, globeConfig } from './config';

const World = dynamic(() => import('./components/world'), { ssr: false });

const GlobeAnimation = () => {
	return <World data={sampleArcs} globeConfig={globeConfig} />;
};

export default GlobeAnimation;
