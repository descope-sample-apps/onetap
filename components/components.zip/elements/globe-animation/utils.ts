import type { Size } from '@react-three/fiber';

export const RING_PROPAGATION_SPEED = 3;
export const aspect = 1;
export const cameraZ = 300;
export const colors = ['#7DEDED', '#90EB53', '#6366f1'];

export const hexToRgb = (hex: string) => {
	const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
	hex = hex.replace(shorthandRegex, (_m, r, g, b) => {
		return r + r + g + g + b + b;
	});

	const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	return result
		? {
				r: parseInt(result[1], 16),
				g: parseInt(result[2], 16),
				b: parseInt(result[3], 16)
			}
		: null;
};

export const genRandomNumbers = (min: number, max: number, count: number) => {
	const arr = [];
	while (arr.length < count) {
		const r = Math.floor(Math.random() * (max - min)) + min;
		if (arr.indexOf(r) === -1) arr.push(r);
	}

	return arr;
};

export const calculateViewportFromWidth = (
	size: Size,
	window: Pick<Size, 'height' | 'width'>
): [number, number, number, number] => {
	if (window.width > 1200) {
		return [window.width * 0.13, 0, size.width, size.height * 0.99];
	}

	if (window.width < 768) {
		return [window.width * 0.1, 200, size.width, size.height];
	}

	return [0, 0, size.width, size.height];
};

export const getFOV = (width: number) => {
	if (width < 768) {
		return 80;
	}

	return 45;
};
