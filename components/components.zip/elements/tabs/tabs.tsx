/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useEffect, useId, useMemo, type FC } from 'react';
import clsx from 'clsx';

import useMobileOnly from '@/hooks/use-mobile-only';
import useTabletOnly from '@/hooks/use-tablet-only';
import { Select } from '@/components/elements/input';

import type { TabsProps } from './tabs.types';
import { Tab } from './tab';
import styles from './tabs.module.scss';

const ALL_TAB = { value: 'all', label: 'All' };

const Tabs: FC<TabsProps> = ({
	tabs,
	value,
	forceSelect = false,
	onTabClick,
	showAll,
	className,
	selectAriaLabel,
	tabletMaxTabs = 3
}) => {
	const id = useId();

	const isMobile = useMobileOnly();
	const isTablet = useTabletOnly();

	const tabsComponent = useMemo(() => {
		const initialTabs = tabs || [];
		const allTabs = showAll ? [ALL_TAB, ...initialTabs] : initialTabs;

		if (isMobile)
			return (
				<Select
					options={allTabs}
					value={value}
					onChange={onTabClick}
					ariaLabel={selectAriaLabel}
				/>
			);

		if (isTablet || forceSelect) {
			const shownTabs = allTabs.slice(0, tabletMaxTabs);
			const hiddenTabs = allTabs.slice(tabletMaxTabs, allTabs.length);

			const valueInHiddenTabs = Boolean(
				hiddenTabs.find((tab) => tab.value === value)
			);

			return (
				<div className={clsx(className, styles.tabs)} role="tablist">
					{shownTabs.map((tab) => (
						<Tab
							key={tab.value}
							tabsId={id}
							onClick={() => onTabClick(tab)}
							label={tab.label}
							isActive={value === tab.value}
						/>
					))}
					{hiddenTabs.length > 0 && (
						<Select
							options={hiddenTabs}
							value={value}
							onChange={onTabClick}
							text={`+${hiddenTabs.length} more`}
							ariaLabel={selectAriaLabel}
							className={{
								root: styles.tabletTabSelectRoot,
								selectTrigger: clsx(
									styles.tabletTabSelectSelectTrigger,
									valueInHiddenTabs && styles.active
								),
								icon: clsx(
									styles.tabletTabSelectIcon,
									valueInHiddenTabs && styles.active
								)
							}}
						/>
					)}
				</div>
			);
		}

		return (
			<div className={clsx(className, styles.tabs)} role="tablist">
				{[...(showAll ? [ALL_TAB] : []), ...(tabs || [])].map((tab) => (
					<Tab
						key={tab.value}
						tabsId={id}
						onClick={() => onTabClick(tab)}
						label={tab.label}
						isActive={value === tab.value}
					/>
				))}
			</div>
		);
	}, [isMobile, isTablet, tabs, value]);

	useEffect(() => {
		if (value) return;

		if (showAll) onTabClick(ALL_TAB);
		else if (tabs[0]) onTabClick(tabs[0]);
	}, [value]);

	return tabsComponent;
};

export default Tabs;
export { ALL_TAB };
