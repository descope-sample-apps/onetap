export interface TabItem {
	value: string;
	label: string;
}

export interface TabsProps {
	/*
		Array of objects with `value` and `label` properties
	*/
	tabs: TabItem[];
	/*
		`value` of the currently selected tab
	*/
	value: string;
	/*
		Callback function that is called when a tab is clicked
	*/
	onTabClick: (tab: TabItem) => void;
	/*
		if `showAll` is true, an extra tab will be shown to display all tabs
		when this tab is clicked, the `value` state is set to `all`
	*/
	showAll?: boolean;
	/**
	 * Additional class name
	 */
	className?: string;

	/**
	 * if true, the select will be displayed
	 */
	forceSelect?: boolean;
	/**
	 * Aria Label for the select
	 */
	selectAriaLabel?: string;
	/**
	 * Maximum number of tabs to show on tablet
	 */
	tabletMaxTabs?: number;
}
