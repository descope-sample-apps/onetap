export { default as Tabs, ALL_TAB } from './tabs';
export type * from './tabs.types';

export * from './tab';
