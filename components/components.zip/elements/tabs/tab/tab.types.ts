export interface TabProps {
	label: string;
	isActive?: boolean;
	onClick?: () => void;
	tabsId?: string;
}
