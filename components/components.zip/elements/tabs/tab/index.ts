export { default as Tab } from './tab';
export type * from './tab.types';
