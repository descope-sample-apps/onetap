'use client';

import clsx from 'clsx';
import { motion } from 'framer-motion';
import { useId, type FC } from 'react';

import { TextM } from '../../typography';

import type { TabProps } from './tab.types';
import styles from './tab.module.scss';

const Tab: FC<TabProps> = ({ tabsId, label, isActive, onClick }) => {
	const id = useId();

	return (
		<button
			className={clsx(styles.tab, isActive && styles.active)}
			onClick={onClick}
			role="tab"
			aria-selected={isActive}
		>
			<TextM isMedium>{label}</TextM>
			{isActive && (
				<motion.span
					layoutId={tabsId || id}
					className={clsx(styles.bubble, isActive && styles.active)}
					transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
				/>
			)}
		</button>
	);
};

export default Tab;
