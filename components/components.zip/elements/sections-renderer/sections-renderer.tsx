import type { FC } from 'react';

import PageBlock from '@/components/templates/page-blocks';

import SectionDivider from '../section-divider';

import type {
	RenderSectionProps,
	SectionsRendererProps
} from './sections-renderer.types';

const RenderSection: FC<RenderSectionProps> = ({
	order,
	section,
	nextTheme
}) => {
	const Section = <PageBlock key={section.id} {...section} order={order} />;

	const currentTheme = section.theme || 'dark';

	if (currentTheme === 'dark' && (nextTheme === 'light' || !nextTheme)) {
		return (
			<>
				{Section}
				<SectionDivider />
			</>
		);
	}
	if (currentTheme === 'light' && nextTheme === 'dark') {
		return (
			<>
				{Section}
				<SectionDivider upsideDown />
			</>
		);
	}

	return Section;
};

const SectionsRenderer: FC<SectionsRendererProps> = ({ sections }) => {
	if (!sections) {
		return null;
	}

	return (
		<>
			{sections.map(
				(section, index) =>
					section && (
						<RenderSection
							key={section.id}
							section={section}
							order={index + 1}
							nextTheme={sections[index + 1]?.theme || null}
						/>
					)
			)}
		</>
	);
};

export default SectionsRenderer;
