import type { Page } from '@/types/page';
import type { SectionTheme } from '@/types/page-block';

export interface SectionsRendererProps {
	sections?: Page['body'];
}

export interface RenderSectionProps {
	order: number;
	section: NonNullable<Page['body']>[number];
	nextTheme: SectionTheme;
}
