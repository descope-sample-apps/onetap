import SectionsRenderer from './sections-renderer';

export default SectionsRenderer;
