import Button from '../button/button';

import styles from './styles.module.css';

interface PreviewAlertProps {
	isPreview: boolean;
}

export const PreviewAlert = ({ isPreview = false }: PreviewAlertProps) => {
	if (!isPreview) {
		return null;
	}

	return (
		<div className={styles.previewAlert}>
			<Button
				variant="extraLarge"
				iconName="ArrowRight"
				href="/api/draft-disable"
			>
				Exit preview mode
			</Button>
		</div>
	);
};
