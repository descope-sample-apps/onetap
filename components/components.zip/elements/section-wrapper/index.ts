import SectionWrapper from './section-wrapper';

export type * from './section-wrapper.types';

export default SectionWrapper;
