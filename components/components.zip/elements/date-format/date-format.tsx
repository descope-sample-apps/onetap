import type React from 'react';

import type { DateFormatProps } from './date-format.types';

const DateFormat: React.FC<DateFormatProps> = ({ date, format }) => {
	const dateString = new Date(date).toLocaleDateString('en-US', {
		month: format ? format : 'long',
		day: 'numeric',
		year: 'numeric'
	});

	return <time dateTime={date}>{dateString}</time>;
};

export default DateFormat;
