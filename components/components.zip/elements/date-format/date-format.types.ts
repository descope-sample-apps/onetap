export interface DateFormatProps {
	date: string;
	format?: 'numeric' | '2-digit' | 'long' | 'short' | 'narrow';
}
