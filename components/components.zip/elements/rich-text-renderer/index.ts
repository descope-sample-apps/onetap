export { default } from './rich-text-renderer';
