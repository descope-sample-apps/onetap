/* eslint-disable no-case-declarations */

import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import type { Document, Node } from '@contentful/rich-text-types';
import { BLOCKS, INLINES } from '@contentful/rich-text-types';
import clsx from 'clsx';
import type { ReactNode } from 'react';

import { generateId } from '@/components/sections/markdown-config/markdown-config';
import imageAdapter from '@/data/cms/contentful/adapters/image';
import { extractHrefFromReference } from '@/data/cms/contentful/adapters/link';
import { Link } from '@/components/elements/link';
import {
	bookADemoAdapter,
	faqListAdapter
} from '@/data/cms/contentful/adapters/block';

import AdvancedImage from '../advanced-image';
import RenderBlocks from '../blocks/blocks';
import {
	isAdvancedImageEntry,
	isBookADemoEntry,
	isFaqEntry,
	isLinkEntry,
	isNewsletterEntry,
	isSearchEntry
} from '../blocks/utils';
import CodeBlock from '../code-block/code-block';
import EmbedVideo from '../embed-video';
import Search from '../search';
import { Table, TableData, TableHeader, TableRow } from '../table/table';
import BookADemo from '../book-a-demo';
import { TextL, TextXXL } from '../typography';
import { NewsletterForm } from '../newsletter-form';
import { FAQ } from '../faq';

import ListIcon from './components/list-icon';
import type { RichTextSettings } from './rich-text-renderer.types';
import { RichHeading } from './components/rich-heading';
import {
	isEmptyParagraph,
	allChildrenAreHeaderCells,
	allChildrenAreBodyCells
} from './utils';
import { RichImage } from './components/rich-image';
import RichLink from './components/rich-link';

const RichTextRenderer =
	(styles: Record<string, string>, settings?: RichTextSettings) =>
	// eslint-disable-next-line react/display-name
	(content: Document) => {
		const options = {
			renderNode: {
				// BLOCKS
				[BLOCKS.HEADING_1]: (_: Node, children: ReactNode) => (
					<RichHeading as={settings?.h1As || 'h1'} className={styles.h1}>
						{children}
					</RichHeading>
				),
				[BLOCKS.HEADING_2]: (_: Node, children: ReactNode) => (
					<RichHeading
						as={settings?.h2As || 'h2'}
						id={generateId((children as string[])[0])}
						className={styles.h2}
					>
						{children}
					</RichHeading>
				),
				[BLOCKS.HEADING_3]: (_: Node, children: ReactNode) => (
					<RichHeading as={settings?.h3As || 'h3'} className={styles.h3}>
						{children}
					</RichHeading>
				),
				[BLOCKS.HEADING_4]: (_: Node, children: ReactNode) => (
					<RichHeading as={settings?.h4As || 'h4'} className={styles.h4}>
						{children}
					</RichHeading>
				),
				[BLOCKS.HEADING_5]: (_: Node, children: ReactNode) => (
					<RichHeading as={settings?.h5As || 'h5'} className={styles.h4}>
						{children}
					</RichHeading>
				),
				[BLOCKS.HEADING_6]: (_: Node, children: ReactNode) => (
					<RichHeading as={settings?.h6As || 'h6'} className={styles.h4}>
						{children}
					</RichHeading>
				),
				[BLOCKS.PARAGRAPH]: (_: Node, children: ReactNode) => {
					const Paragraph = settings?.paragraphAs || TextL;
					return isEmptyParagraph(children) ? (
						<br />
					) : (
						<Paragraph className={styles.description}>{children}</Paragraph>
					);
				},
				[BLOCKS.UL_LIST]: (_: Node, children: ReactNode) => (
					<ul className={styles.list}>{children}</ul>
				),
				[BLOCKS.OL_LIST]: (_: Node, children: ReactNode) => (
					<ol className={styles.orderedList}>{children}</ol>
				),
				[BLOCKS.LIST_ITEM]: (_: Node, children: ReactNode) => {
					return (
						<TextL as="li" isMedium className={styles.listItem}>
							{styles.listItemMarker && (
								<div className={styles.listItemMarker}>
									<ListIcon width="16" height="19" />
								</div>
							)}
							{children}
						</TextL>
					);
				},
				[BLOCKS.QUOTE]: (_: Node, children: ReactNode) => {
					return (
						<TextXXL as="blockquote" className={styles.quote}>
							{children}
						</TextXXL>
					);
				},
				[BLOCKS.TABLE]: (_: Node, children: ReactNode) => {
					return <Table className={styles.table}>{children}</Table>;
				},
				[BLOCKS.TABLE_HEADER_CELL]: (_: Node, children: ReactNode) => {
					return <TableHeader className={styles.table}>{children}</TableHeader>;
				},
				[BLOCKS.TABLE_ROW]: (_: Node, children: ReactNode) => {
					const tableRow = (
						<TableRow className={styles.table}>{children}</TableRow>
					);
					if (allChildrenAreHeaderCells(children)) {
						return <thead>{tableRow}</thead>;
					}
					if (allChildrenAreBodyCells(children)) {
						return <tbody>{tableRow}</tbody>;
					}
					return tableRow;
				},
				[BLOCKS.TABLE_CELL]: (_: Node, children: ReactNode) => {
					return <TableData className={styles.table}>{children}</TableData>;
				},
				[BLOCKS.EMBEDDED_ENTRY]: (node: Node) => {
					const block = node.data.target.fields;

					if (!block) return;

					if (node.data.target.sys.contentType?.sys.id === 'codeBlock')
						return (
							<CodeBlock
								code={block.code}
								name={block.title}
								language={block.language}
							/>
						);

					if (node.data.target.sys.contentType?.sys.id === 'embedVideo')
						return <EmbedVideo name={block.name} url={block.url} />;

					switch (true) {
						case isBookADemoEntry(block):
							return <BookADemo {...bookADemoAdapter(node.data.target)} />;
						case isFaqEntry(block):
							return <FAQ {...faqListAdapter(node.data.target)} isInRichText />;
						case isSearchEntry(block):
							return (
								<Search
									id={block.id}
									// @ts-ignore
									placeholder={block.inputPlaceholder}
									suggestionTitle={block.suggestionTitle}
									className={styles.search}
									allowSearchFor={block.allowSearchFor}
								/>
							);
						case isNewsletterEntry(block):
							return (
								<NewsletterForm
									className={styles.emailForm}
									buttonText={block.buttonText}
									newsletterText={block.heading}
									placeholder={block.inputPlaceholder}
								/>
							);

						case isLinkEntry(block):
							// @ts-expect-error
							const href = block.internalTarget
								? // @ts-expect-error
									extractHrefFromReference(block.internalTarget)
								: // @ts-expect-error
									block.externalTarget;

							const link = {
								id: href,
								href: href,
								text: block.text,
								style: block.style,
								newTab: block.newTab,
								newVariant: block.newVariant,
								size: block.size,
								iconName: block.iconName,
								iconAlignment: block.iconAlignment
							};

							return (
								<RenderBlocks
									blocks={link}
									linkClass={styles.button}
									wrapperClass={styles.blocks}
								/>
							);

						case isAdvancedImageEntry(block):
							const { advancedImage: asset, alignment, size, ...rest } = block;
							// @ts-expect-error
							const image = imageAdapter(asset);

							return (
								<AdvancedImage
									advancedImage={image}
									size={size}
									align={alignment}
									{...rest}
								/>
							);
						default:
							return null;
					}
				},
				[BLOCKS.EMBEDDED_ASSET]: (node: Node) => {
					const image = node.data.target.fields;

					return (
						<RichImage
							image={image}
							styles={styles}
							noLightboxImage={settings?.noLightboxImage}
						/>
					);
				},
				[BLOCKS.HR]: () => <hr className={styles.hr} />,
				// INLINES
				[INLINES.HYPERLINK]: (node: Node, children: ReactNode) => {
					const href: string = node.data.uri;
					const isExternal = !href.includes('#');
					return (
						<Link newTab={isExternal} href={href} className={styles.inlineLink}>
							{children}
						</Link>
					);
				},
				[INLINES.ENTRY_HYPERLINK]: (node: Node, children: ReactNode) => {
					const href = extractHrefFromReference(node.data.target);
					return (
						<Link href={href} className={styles.inlineLink}>
							{children}
						</Link>
					);
				},
				[INLINES.EMBEDDED_ENTRY]: (node: Node) => {
					const {
						id,
						style,
						text,
						internalTarget,
						externalTarget,
						additionalParameters,
						newTab,
						newVariant,
						size,
						iconName,
						iconAlignment
					} = node.data.target.fields;

					const href = internalTarget
						? extractHrefFromReference(internalTarget)
						: externalTarget;

					const link = {
						id,
						href,
						text,
						style,
						newTab,
						newVariant,
						size,
						iconName,
						iconAlignment
					};

					return additionalParameters?.onclick ? (
						<RichLink
							additionalParameters={additionalParameters}
							styles={styles}
							link={link}
						>
							{text}
						</RichLink>
					) : (
						<RenderBlocks
							blocks={link}
							isInlineBlock
							linkClass={clsx(styles.button, styles.embeddedInlineLink)}
							wrapperClass={styles.blocks}
						/>
					);
				},
				[INLINES.ASSET_HYPERLINK]: (node: Node) => {
					const image = node.data.target.fields;

					return (
						<RichImage
							image={image}
							styles={styles}
							noLightboxImage={settings?.noLightboxImage}
						/>
					);
				}
			}
		};

		return <>{content && documentToReactComponents(content, options)}</>;
	};

export default RichTextRenderer;
