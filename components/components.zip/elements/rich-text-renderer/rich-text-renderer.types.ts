import type { ComponentType } from 'react';

export interface RichTextSettings {
	noLightboxImage?: boolean;
	h1As?: ComponentType;
	h2As?: ComponentType;
	h3As?: ComponentType;
	h4As?: ComponentType;
	h5As?: ComponentType;
	h6As?: ComponentType;
	paragraphAs?: ComponentType;
}
