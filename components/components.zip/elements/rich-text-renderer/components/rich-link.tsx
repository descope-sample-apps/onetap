'use client';

import clsx from 'clsx';
import type { ReactNode } from 'react';

import { Link, type LinkProps } from '@/components/elements/link';

import { inlineFunction } from '../utils';

const RichLink = ({
	link,
	children,
	additionalParameters,
	styles
}: {
	link: Pick<
		LinkProps,
		| 'href'
		| 'style'
		| 'newTab'
		| 'newVariant'
		| 'size'
		| 'iconName'
		| 'iconAlignment'
	>;
	children: ReactNode;
	additionalParameters: any;
	styles: Record<string, string>;
}) => {
	return (
		<Link
			// @ts-ignore
			onClick={inlineFunction(additionalParameters.onclick)}
			className={clsx(styles.inlineLink)}
			href={link.href}
			style={link.style}
			newTab={link.newTab}
			newVariant={link.newVariant}
			size={link.size}
			iconName={link.iconName}
			iconAlignment={link.iconAlignment}
		>
			{children}
		</Link>
	);
};

export default RichLink;
