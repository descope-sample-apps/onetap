import type { ElementType } from 'react';

import {
	HeadingL,
	HeadingM,
	HeadingS,
	HeadingXS,
	HeadingXXL,
	type TypographyProps
} from '../../typography';

export const RichHeading = <T extends ElementType>({
	as,
	children,
	...props
}: TypographyProps<T>) => {
	switch (as) {
		case 'h1':
			return (
				<HeadingXXL as="h1" {...props}>
					{children}
				</HeadingXXL>
			);
		case 'h2':
			return (
				<HeadingL as="h2" {...props}>
					{children}
				</HeadingL>
			);
		case 'h3':
			return (
				<HeadingM as="h3" {...props}>
					{children}
				</HeadingM>
			);
		case 'h4':
			return (
				<HeadingS as="h4" {...props}>
					{children}
				</HeadingS>
			);
		case 'h5':
			return (
				<HeadingXS as="h5" {...props}>
					{children}
				</HeadingXS>
			);
		case 'h6':
			return (
				<HeadingXS as="h6" {...props}>
					{children}
				</HeadingXS>
			);

		default:
			return (
				<HeadingL as="h2" {...props}>
					{children}
				</HeadingL>
			);
	}
};
