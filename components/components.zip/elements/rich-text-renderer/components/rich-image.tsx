import Image from 'next/image';

import { imagePrefixer } from '../utils';
import AdvancedImage from '../../advanced-image';
import { TextM } from '../../typography';

interface RichImageProps {
	image: {
		title?: string;
		text?: string;
		description?: string;
		id: string;
		file: {
			url?: string;
			details: {
				image: {
					height: number;
					width: number;
				};
			};
		};
	};
	noLightboxImage?: boolean;
	styles: Record<string, string>;
}

export const RichImage = ({
	image,
	noLightboxImage,
	styles
}: RichImageProps) => {
	const src = image.file?.url && imagePrefixer(image.file.url);

	if (!src) return null;

	return noLightboxImage ? (
		<>
			<Image
				src={src}
				height={image.file?.details?.image?.height}
				width={image.file?.details?.image?.width}
				alt={image.description || ''}
				style={{
					maxWidth: '100%',
					height: 'unset',
					position: 'relative'
				}}
			/>
			{(image.title || image.text) && (
				<TextM as="figcaption" className={styles.imageCaption}>
					{image.title || image.text}
				</TextM>
			)}
		</>
	) : (
		<AdvancedImage
			caption={image.title || image.text || ''}
			id={image.id}
			advancedImage={{
				src,
				alt: image.description,
				width: image.file.details.image.width,
				height: image.file.details.image.height
			}}
		/>
	);
};
