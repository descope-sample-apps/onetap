import type { ReactNode } from 'react';

export const imagePrefixer = (src: string) => {
	if (src.startsWith('https')) return src;
	if (src.startsWith('//')) return `https:${src}`;
	return `https://${src}`;
};

export const inlineFunction = (inlineFunctionBody: string) => {
	return (e: any) => {
		e.preventDefault();
		try {
			Function(inlineFunctionBody)();
		} catch {
			// do nothing
		}
	};
};

export const isEmptyParagraph = (children: ReactNode) =>
	Array.isArray(children) && children.every((child) => child === '');

export const allChildrenAreHeaderCells = (children: ReactNode) =>
	Array.isArray(children) &&
	children.every((node) => node.type.name === 'TableHeader');

export const allChildrenAreBodyCells = (children: ReactNode) =>
	Array.isArray(children) &&
	children.every((node) => node.type.name === 'TableData');
