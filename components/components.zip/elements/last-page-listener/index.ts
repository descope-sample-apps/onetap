import LastPageListener from './last-page-listener';

export { LastPageListener };
