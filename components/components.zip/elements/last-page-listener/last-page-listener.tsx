'use client';

import { usePathname } from 'next/navigation';
import { useEffect } from 'react';

// to avoid storing last page in sessionStorage in strict mode
const isDevelopment = process.env.NODE_ENV === 'development';

/**
 * This component is essential for implementing "Back" button functionality in various hero components
 * (e.g., BlogAuthorHeader) across the application. These hero components
 * use the stored 'lastPage' value to determine where to navigate when the user clicks "Back".
 *
 * This component is used in the layout.tsx file to ensure that the last page visited is stored
 * in sessionStorage when the user navigates to a new page.
 */
const LastPageListener = () => {
	const pathname = usePathname();

	useEffect(() => {
		return () => {
			const isFirstVisit = window.sessionStorage.getItem('hasVisited') === null;

			if (isDevelopment && isFirstVisit) {
				// First page visit - don't set lastPage but mark that user has visited
				window.sessionStorage.setItem('hasVisited', 'true');
			} else {
				// Not first visit - can set lastPage
				window.sessionStorage.setItem('lastPage', pathname);
			}
		};
	}, [pathname]);

	return null;
};

export default LastPageListener;
