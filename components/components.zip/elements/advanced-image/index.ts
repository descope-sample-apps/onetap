import AdvancedImage from './advanced-image';

export default AdvancedImage;
