import clsx from 'clsx';
import Image from 'next/image';

import capitalize from '@/lib/helper/capitalize';
import type { Image as ImageProps } from '@/types/image';
import LightboxImage from '@/components/elements/lightbox-image';
import { TextM } from '@/components/elements/typography';

import styles from './advanced-image.module.scss';
import type { AdvancedImageProps } from './advanced-image.types';

const AdvancedImage = ({
	size,
	align,
	advancedImage: image,
	caption,
	imageClass,
	wrapperClass
}: AdvancedImageProps & { wrapperClass?: string; imageClass?: string }) => (
	<div
		className={clsx(
			styles.image,
			wrapperClass,
			styles[`imageAlign${capitalize(align)}`],
			styles[`imageSize${capitalize(size)}`]
		)}
	>
		<FigureImage
			image={image}
			imageClass={imageClass}
			figureClass={styles.figure}
			caption={caption}
		/>
	</div>
);

export const FigureImage = ({
	figureClass,
	imageClass,
	noMagnify,
	caption,
	image
}: {
	figureClass?: string;
	imageClass?: string;
	caption?: string;
	image?: ImageProps;
	noMagnify?: boolean;
}) => {
	return (
		<figure className={figureClass}>
			{image &&
				(noMagnify ? (
					<Image
						src={image.src}
						width={image.width}
						height={image.height}
						alt={image.alt || ''}
						className={imageClass}
						sizes="100vw"
						style={{
							width: '100%',
							height: 'auto',
							maxWidth: '100%'
						}}
					/>
				) : (
					<LightboxImage
						imageProps={{
							src: image.src,
							alt: image?.alt || '',
							width: image.width,
							height: image.height,
							// fill: true,
							objectFit: 'contain',
							className: imageClass
						}}
					/>
				))}
			{caption && (
				<TextM as="figcaption" className={styles.imageCaption}>
					{caption}
				</TextM>
			)}
		</figure>
	);
};

export default AdvancedImage;
