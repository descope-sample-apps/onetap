import type { Image } from '@/types/image';

type ContentImageSizing = 'small' | 'medium' | 'large';
export type ContentImageAlignment = 'left' | 'center' | 'right';

export interface AdvancedImageProps {
	id: string;
	advancedImage: Image;
	caption: string;
	target?: string;
	size?: ContentImageSizing;
	align?: ContentImageAlignment;
}
