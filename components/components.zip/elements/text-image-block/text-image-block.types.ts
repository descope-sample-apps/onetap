import type { Document } from '@contentful/rich-text-types';

import type { Link } from '@/types/link';
import type { Image } from '@/types/image';

export interface TextImageBlockProps {
	id: string;
	heading?: string;
	subHeading?: string;
	content?: Document;
	links?: Link[];
	image?: Image;
	imageOnTheLeft?: boolean;
}
