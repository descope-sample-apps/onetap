export type * from './text-image-block.types';
