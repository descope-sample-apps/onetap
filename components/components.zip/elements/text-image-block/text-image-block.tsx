import clsx from 'clsx';

import { Link } from '@/components/elements/link';

import { HeadingL, LabelS } from '../typography';
import RichTextRenderer from '../rich-text-renderer';
import LottieAnimation from '../lottie-animation';
import AdvancedImage from '../advanced-image';

import type { TextImageBlockProps } from './text-image-block.types';
import styles from './text-image-block.module.scss';

const TextImageBlock = ({
	heading,
	subHeading,
	content,
	image,
	imageOnTheLeft,
	links
}: TextImageBlockProps) => {
	return (
		<div className={styles.container}>
			<div>
				{subHeading && (
					<LabelS className={styles.label} as="p">
						{subHeading}
					</LabelS>
				)}
				{heading && (
					<HeadingL className={styles.heading} as="h3">
						{heading}
					</HeadingL>
				)}
				{content && (
					<div className={styles.content}>
						{RichTextRenderer(styles)(content)}
					</div>
				)}
				{links && links.length > 0 && (
					<div className={styles.links}>
						{links.map((link) => (
							<Link
								key={link.id}
								className={styles.link}
								href={link.href}
								newTab={link.newTab}
								downloadFile={link.downloadFile}
								video={link.video}
								videoEmbedLink={link.videoEmbedLink}
								style={link.style}
								newVariant={link.newVariant}
								size={link.size}
								iconName={link.iconName}
								iconAlignment={link.iconAlignment}
							>
								{link.text}
							</Link>
						))}
					</div>
				)}
			</div>
			{image?.src && (
				<div
					className={clsx(
						styles.imageContainer,
						imageOnTheLeft && styles.leftImage
					)}
				>
					{image.src.toString().endsWith('.lottie') ? (
						<LottieAnimation
							src={image.src}
							width={image.width!}
							height={image.height!}
						/>
					) : (
						<AdvancedImage
							wrapperClass={styles.image}
							id={image.src}
							advancedImage={image}
							caption=""
							size="large"
						/>
					)}
				</div>
			)}
		</div>
	);
};

export default TextImageBlock;
