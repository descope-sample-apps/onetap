import type { ImageProps } from 'next/image';
import type { LightboxExternalProps } from 'yet-another-react-lightbox';

export interface LightboxImageProps {
	imageProps: ImageProps;
	lightboxProps?: LightboxExternalProps;
}
