import LightboxImage from './lightbox-image';

export default LightboxImage;
