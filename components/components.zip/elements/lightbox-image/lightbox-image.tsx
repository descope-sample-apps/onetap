'use client';

// eslint-disable-next-line import/no-unresolved
import 'yet-another-react-lightbox/styles.css';
import clsx from 'clsx';
import Image from 'next/image';
import Lightbox from 'yet-another-react-lightbox';
import Video from 'yet-another-react-lightbox/plugins/video';
import type { CSSProperties, FC, MouseEventHandler } from 'react';

import useToggle from '@/hooks/use-toggle';

import Button from '../button/button';
import LottieAnimation from '../lottie-animation';

import styles from './lightbox-image.module.scss';
import type { LightboxImageProps } from './lightbox-image.types';

const LightboxImage: FC<LightboxImageProps> = ({
	imageProps,
	lightboxProps
}) => {
	const { isOn, setOff, setOn } = useToggle('off');
	const { src, alt, onClick, className, objectFit, ...rest } = imageProps;

	const isLottie = src && src.toString().endsWith('.lottie');

	// match video Url
	const videoRegex = /\.(mp4|avi|mov|wmv|flv|mkv)$/;
	const isVideo = src && videoRegex.test(src.toString());

	const handleClick: MouseEventHandler<HTMLImageElement> = (e) => {
		setOn();
		onClick && onClick(e);
	};

	if (!src) return null;

	if (isLottie) {
		return (
			<LottieAnimation
				src={src as string}
				width={rest.width!}
				height={rest.height!}
			/>
		);
	}

	return (
		<>
			{isVideo ? (
				<button
					aria-label="Magnify video"
					onClick={
						handleClick as unknown as MouseEventHandler<HTMLButtonElement>
					}
				>
					<video
						muted
						autoPlay
						loop
						src={src as string}
						className={clsx(className, 'yt-lite')}
						aria-hidden
					/>
				</button>
			) : (
				<Image
					src={src}
					alt={alt}
					{...rest}
					loading="lazy"
					onClick={handleClick}
					className={clsx(styles.image, className)}
					style={{
						maxWidth: '100%',
						objectFit:
							(objectFit as CSSProperties['objectFit'] | undefined) ?? 'contain'
					}}
				/>
			)}

			<Lightbox
				open={isOn}
				close={setOff}
				plugins={isVideo ? [Video] : []}
				carousel={{ finite: true }}
				className={styles.lightbox}
				slides={[
					isVideo
						? {
								type: 'video',
								width: 1280,
								height: 720,
								autoPlay: true,
								sources: [
									{
										src: src as string,
										type: 'video/mp4'
									}
								]
							}
						: { src: src as string, alt }
				]}
				controller={{ closeOnBackdropClick: true }}
				render={{
					buttonNext: () => null,
					buttonPrev: () => null,
					buttonClose: () => (
						<Button
							newVariant="icon"
							aria-label="Close"
							className={styles.close}
							onClick={setOff}
							iconName="Close"
						></Button>
					)
				}}
				{...lightboxProps}
			/>
		</>
	);
};

export default LightboxImage;
