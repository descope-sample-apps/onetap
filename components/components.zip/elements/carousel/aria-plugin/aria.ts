/* eslint-disable prefer-arrow/prefer-arrow-functions */

/* This is a copy of embla-carousel-aria package's code, created by Nikolas Schröter (https://github.com/nwidynski).
Original package link: https://github.com/nwidynski/embla-carousel-aria
It was adjusted here to suit our accessibility requirements.
The package was distributed under the MIT license, terms of which are included below.
MIT License

Copyright (c) 2020 Felix Leupold

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */

import type {
	EmblaCarouselType,
	EmblaEventType,
	OptionsHandlerType
} from 'embla-carousel';

import debounce from '../../../../lib/helper/debounce';

import { getFocusableTreeWalker } from './utils/getFocusableTreeWalker';
import type { FocusManagerOptions } from './utils/getFocusableTreeWalker';
import type {
	AriaOptions,
	AriaPluginType,
	AriaPluginOptions,
	AriaPluginFunction,
	AriaPluginAttributes
} from './aria.types';

declare module 'embla-carousel' {
	interface EmblaPluginsType {
		aria?: AriaPluginType;
	}
}

const IN_VIEW_EVENTS: EmblaEventType[] = ['slidesInView'];
const DEFAULT_DEBOUNCE = 300;

const CustomAriaPlugin: AriaPluginFunction = (
	userOptions: AriaPluginOptions = {}
): AriaPluginType => {
	let options: AriaPluginOptions;
	let emblaApi: EmblaCarouselType;

	function init(
		emblaApiInstance: EmblaCarouselType,
		optionsHandler: OptionsHandlerType
	): void {
		emblaApi = emblaApiInstance;

		const { mergeOptions, optionsAtMedia } = optionsHandler;

		const defaultOptions: Required<AriaOptions> = {
			active: true,
			breakpoints: {},
			locale: 'en-US',
			live: false,
			debounce: DEFAULT_DEBOUNCE,
			onFocusChange: () => {}
		};

		const base = mergeOptions(defaultOptions, CustomAriaPlugin.globalOptions);
		options = optionsAtMedia(mergeOptions(base, userOptions));

		for (const evt of IN_VIEW_EVENTS) {
			emblaApi.on(
				evt,
				debounce(
					toggleAriaSlideAttrs,
					options.debounce || defaultOptions.debounce
				)
			);
			emblaApi.on(
				evt,
				debounce(
					toggleFocusableSlideNodes,
					options.debounce || defaultOptions.debounce
				)
			);
		}

		toggleAriaSlideAttrs();
		toggleFocusableSlideNodes();
	}

	/**
	 * Restores the mount value of an attribute on a node.
	 *
	 * @param node - The node which carries the attribute.
	 * @param attr - The attribute to restore.
	 */
	function safelyRestoreNodeAttr(node: Node, attr: keyof AriaPluginAttributes) {
		if (node instanceof HTMLElement) {
			const mountAttr = node.getAttribute(`data-backup-${attr}`);

			if (mountAttr !== null && mountAttr !== 'null') {
				node.setAttribute(attr, mountAttr);
			} else {
				node.removeAttribute(attr);
			}
		}
	}

	/**
	 * Mounts an attribute on a node.
	 *
	 * @param node - The node which carries the attribute.
	 * @param attr - The attribute to mount.
	 */
	function safelyMountNodeAttr(
		node: Node,
		attr: keyof AriaPluginAttributes,
		value?: string
	) {
		if (node instanceof HTMLElement) {
			const current = node.getAttribute(attr);
			const mountAttr = node.getAttribute(`data-backup-${attr}`);

			if (mountAttr === null) {
				node.setAttribute(`data-backup-${attr}`, current ?? 'null');
			}

			if (value !== undefined && value !== current) {
				node.setAttribute(attr, value);
			}
		}
	}

	/**
	 * Unmounts an attribute on a node.
	 *
	 * @param node - The node which carries the attribute.
	 * @param attr - The attribute to destroy.
	 */
	function safelyUnmountNodeAttr(
		node: HTMLElement,
		attr: keyof AriaPluginAttributes
	) {
		safelyRestoreNodeAttr(node, attr);
		node.removeAttribute(`data-backup-${attr}`);
	}

	/**
	 * Destroys the focus ability of an element. Moves the focus if necessary.
	 *
	 * @param node - The element to destory focus for.
	 */
	function safelyDestroyFocus(node: HTMLElement) {
		const currentFocus = document.activeElement === node;

		if (document.hasFocus() && currentFocus) {
			const tree = getFocusableTreeWalker(emblaApi.containerNode(), {
				tabbable: true
			});

			const target = tree.nextNode() ?? emblaApi.rootNode();

			if (target instanceof HTMLElement) {
				target.focus();

				options.onFocusChange && options.onFocusChange(node, target);
			}
		}

		safelyMountNodeAttr(node, 'tabindex', '-1');
	}

	/**
	 * Destroys all attributes set by the aria plugin.
	 */
	function destroy(): void {
		for (const evt of IN_VIEW_EVENTS) {
			emblaApi.off(
				evt,
				debounce(toggleAriaSlideAttrs, options.debounce || DEFAULT_DEBOUNCE)
			);
			emblaApi.off(
				evt,
				debounce(
					toggleFocusableSlideNodes,
					options.debounce || DEFAULT_DEBOUNCE
				)
			);
		}

		const slides = emblaApi.slideNodes();

		for (const slide of slides) {
			safelyUnmountNodeAttr(slide, 'tabindex');

			safelyUnmountNodeAttr(slide, 'aria-hidden');

			executeForFocusDescendants(slide, (node) => {
				safelyUnmountNodeAttr(node, 'tabindex');
			});
		}
	}

	/**
	 * Executes a callback function for every focusable descendant.
	 *
	 * @param node - The node to start tree-walking from.
	 * @param callback - The callback function to invoke for every focusable node.
	 */
	function executeForFocusDescendants(
		node: HTMLElement,
		callback: (...args: any[]) => void,
		options?: FocusManagerOptions
	) {
		const tree = getFocusableTreeWalker(node, options);

		let focusable;
		while ((focusable = tree.nextNode())) {
			callback(focusable);
		}
	}

	/**
	 * Retrieves the nodes of slides and groups them by visibility.
	 */
	function getSlideElementsByVisibility() {
		const visible: HTMLElement[] = [];
		const invisible: HTMLElement[] = [];
		const slides = emblaApi.slideNodes();

		for (let index = 0; index <= slides.length; index++) {
			const slide = slides[index];

			if (slide !== undefined) {
				emblaApi.slidesInView().includes(index)
					? visible.push(slide)
					: invisible.push(slide);
			}
		}

		return [visible, invisible] as const;
	}

	/**
	 * Toggles aria attributes on all slides.
	 */
	function toggleAriaSlideAttrs(): void {
		const slides = emblaApi.slideNodes();

		for (let index = 0; index <= slides.length; index++) {
			const node = slides[index];
			if (!node) continue;

			const visible = emblaApi.slidesInView().includes(index);

			safelyMountNodeAttr(node, 'aria-hidden', visible ? 'false' : 'true');
		}
	}

	/**
	 * Toggles focus on all focusable slides & descendants.
	 */
	function toggleFocusableSlideNodes(): void {
		const [visible, invisible] = getSlideElementsByVisibility();

		for (const slide of visible) {
			safelyMountNodeAttr(slide, 'tabindex');
			safelyRestoreNodeAttr(slide, 'tabindex');
			executeForFocusDescendants(slide, (child) => {
				safelyRestoreNodeAttr(child, 'tabindex');
			});
		}

		for (const slide of invisible) {
			safelyDestroyFocus(slide);

			executeForFocusDescendants(slide, (child) => {
				safelyDestroyFocus(child);
			});
		}
	}

	const self: AriaPluginType = {
		name: 'aria',
		options: userOptions,
		init,
		destroy
	};

	return self;
};

CustomAriaPlugin.globalOptions = undefined;

export default CustomAriaPlugin;
