'use client';

import type React from 'react';
import type { EmblaOptionsType } from 'embla-carousel';
import useEmblaCarousel from 'embla-carousel-react';

import Button from '@/components/elements/button';
import { usePrevNextButtons } from '@/components/elements/carousel/control-buttons';

import CustomAriaPlugin from './aria-plugin/aria';

type PropType = {
	options?: EmblaOptionsType;
	styles?: any;
	children?: React.ReactNode;
};

const EmblaCarousel: React.FC<PropType> = (props) => {
	const { styles, children, options } = props;
	const [emblaRef, emblaApi] = useEmblaCarousel(
		{ watchFocus: false, ...options },
		[CustomAriaPlugin()]
	);
	const {
		prevBtnDisabled,
		nextBtnDisabled,
		onPrevButtonClick,
		onNextButtonClick
	} = usePrevNextButtons(emblaApi);
	return (
		<section className={styles.embla}>
			<div className={styles.emblaViewport} ref={emblaRef}>
				<div className={styles.emblaContainer}>{children}</div>
			</div>
			<div className={styles.emblaButtons}>
				<Button
					type="button"
					onClick={() => onPrevButtonClick()}
					newVariant="icon"
					iconName="ChevronUp"
					className={styles.previous}
					disabled={prevBtnDisabled}
					aria-label="Previous slide"
				/>
				<Button
					type="button"
					onClick={() => onNextButtonClick()}
					newVariant="icon"
					iconName="ChevronUp"
					className={styles.next}
					disabled={nextBtnDisabled}
					aria-label="Next slide"
				/>
			</div>
		</section>
	);
};

export default EmblaCarousel;
