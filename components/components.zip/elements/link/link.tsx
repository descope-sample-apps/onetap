'use client';

import { useModal } from '@faceless-ui/modal';
import NextLink from 'next/link';
import { useId, type ForwardedRef } from 'react';

import isExternalPage from '@/lib/helper/is-external-page';
import getNodeInnerText from '@/lib/helper/get-node-inner-text';

import Button from '../button/button';
import VideoEmbedPopup from '../video-popup';
import type { IconVariant } from '../icon';

import type { LinkProps } from './link.types';

const isAnchor = (url: string) => url.startsWith('#');

// NOTE: rest props are any props that support rendering link as Button
const Link = ({
	href,
	video,
	style = 'link',
	newTab,
	newVariant,
	size,
	className,
	ariaLabel,
	videoEmbedLink,
	downloadFile,
	children,
	iconName,
	iconAlignment,
	ref,
	...rest
}: LinkProps) => {
	const id = useId();
	const { toggleModal } = useModal();
	const uniqueSlug = `video-popup-modal-${id}`;
	const handleVideoPopup = () => toggleModal(uniqueSlug);

	const innerText = getNodeInnerText(children);

	const icon = iconName?.fields?.iconName as unknown as IconVariant;

	const handleDownloadFile = () => {
		if (downloadFile) {
			const link = document.createElement('a');
			link.download = downloadFile.fileName;
			link.href = downloadFile.url;
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		}
	};

	if (videoEmbedLink || video)
		return (
			<>
				<Button
					newVariant={newVariant}
					size={size}
					className={className}
					onClick={handleVideoPopup}
					iconName={icon}
					iconAlignment={iconAlignment}
					{...rest}
				>
					{children}
				</Button>
				<VideoEmbedPopup
					videoEmbedLink={videoEmbedLink}
					uniqueSlug={uniqueSlug}
					video={video}
				/>
			</>
		);

	if (downloadFile)
		return (
			<Button
				newVariant={newVariant}
				size={size}
				className={className}
				onClick={handleDownloadFile}
				iconName={icon}
				iconAlignment={iconAlignment}
				{...rest}
			>
				{children}
			</Button>
		);

	const renderButton = () => {
		return (
			<Button
				href={href}
				newVariant={newVariant}
				size={size}
				className={className}
				iconName={icon}
				iconAlignment={iconAlignment}
				{...(newTab && newTabProperties(href))}
				{...(ariaLabel && { 'aria-label': ariaLabel })}
				{...rest}
			>
				{children}
			</Button>
		);
	};

	if (!href) {
		return (
			<span className={className} ref={ref} {...rest}>
				{children}
			</span>
		);
	}

	if (isAnchor(href) || isExternalPage(href)) {
		if (style && style === 'button') return renderButton();
		else
			return (
				<a
					className={className}
					ref={ref as ForwardedRef<HTMLAnchorElement>}
					href={href}
					aria-label={`${ariaLabel || innerText}${newTab ? ', opens in new tab' : ''}`}
					{...(newTab && newTabProperties(href))}
					{...rest}
				>
					{children}
				</a>
			);
	}

	return style && style === 'button' ? (
		renderButton()
	) : (
		<NextLink
			href={href}
			prefetch={false}
			className={className}
			ref={ref as ForwardedRef<HTMLAnchorElement>}
			aria-label={`${ariaLabel || innerText}${newTab ? ', opens in new tab' : ''}`}
			{...(newTab && newTabProperties(href))}
			{...rest}
		>
			{children}
		</NextLink>
	);
};

export const newTabProperties = (_href?: string) => ({
	target: '_blank',
	rel: `noopener noreferrer`
});

export default Link;
