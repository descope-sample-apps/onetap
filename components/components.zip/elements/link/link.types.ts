import type { ReactNode, Ref } from 'react';

import type { File } from '@/types/file';
import type { Image } from '@/types/image';
import type { CFBlock } from '@/data/cms/contentful/types/block';

import type { ButtonNewVariant } from '../button';

export interface LinkProps {
	href: string;
	newTab?: boolean;
	ariaLabel?: string;
	className?: string;
	children?: ReactNode;
	downloadFile?: File;
	rel?: string;
	video?: Image | null;
	videoEmbedLink?: string;
	style?: 'button' | 'link';
	tabIndex?: number;
	ref?: Ref<HTMLAnchorElement>;

	newVariant?: ButtonNewVariant;
	size?: 'small' | 'large';
	iconName?: CFBlock;
	iconAlignment?: 'left' | 'right';
}
