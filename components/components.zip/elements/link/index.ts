export { default as Link, newTabProperties } from './link';
export type * from './link.types';
