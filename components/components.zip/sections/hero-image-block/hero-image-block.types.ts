import type { Document } from '@contentful/rich-text-types';

import type { Block } from '@/types/block';
import type { Image } from '@/types/image';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { ImageLink } from '@/types/image-link';

export interface HeroImageBlockModel {
	title: string;
	subTitle?: string;
	content?: Document | null;
	blocks?: Block[] | null;
	imageLinks?: ImageLink[] | null;
	image?: Image | null;
	sectionLayoutRatio?: '50/50' | '70/30';
	showGlobe: boolean;
}

export type HeroImageBlockProps = SectionBaseProps & HeroImageBlockModel;
