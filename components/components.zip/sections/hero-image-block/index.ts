import HeroImageBlock from './hero-image-block';

export default HeroImageBlock;
export type * from './hero-image-block.types';
