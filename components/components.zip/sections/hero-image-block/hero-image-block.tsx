import clsx from 'clsx';
import Image from 'next/image';

import { FigureImage } from '@/components/elements/advanced-image/advanced-image';
import RenderBlock from '@/components/elements/blocks/blocks';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import { HeadingXXL, LabelM } from '@/components/elements/typography';
import SectionWrapper from '@/components/elements/section-wrapper';
import DefaultGradient from '@/assets/section-bg/hero-image-gradient.svg';
import HeroCustomerGradient from '@/assets/section-bg/hero-customer-gradient.svg';
import SectionTitle from '@/components/elements/section-title';
import { Link } from '@/components/elements/link';
import { Icon } from '@/components/elements/icon';
import { arrayChunk } from '@/lib/utils/array-chunk';
import type { ImageLink } from '@/types/image-link';
import GlobeAnimation from '@/components/elements/globe-animation/globe-animation';

import styles from './hero-image-block.module.scss';
import type { HeroImageBlockProps } from './hero-image-block.types';

const HeroImageBlock = (props: HeroImageBlockProps) => {
	const {
		title,
		content,
		blocks,
		subTitle,
		sectionLayoutRatio,
		image,
		theme,
		order,
		showGlobe,
		titlesLoop,
		imageLinks = []
	} = props;
	const is5050Type = sectionLayoutRatio === '50/50';
	const is7030ype = sectionLayoutRatio === '70/30';
	const isHeroCustomer = !image?.src && !showGlobe;

	const imageLinkChunks = arrayChunk<ImageLink>(imageLinks as ImageLink[], 2);

	return (
		<SectionWrapper
			theme={theme}
			order={order}
			className={clsx(styles.heroSection, {
				[styles.section5050]: !showGlobe && is5050Type,
				[styles.section7030]: !showGlobe && is7030ype,
				[styles.withGlobe]: showGlobe,
				[styles.heroCustomer]: isHeroCustomer
			})}
			gradient={isHeroCustomer ? HeroCustomerGradient : DefaultGradient}
		>
			<Container className={styles.outerContainer}>
				<div
					className={clsx(styles.container, {
						[styles.heroCustomerOuterContainer]: isHeroCustomer
					})}
				>
					<div className={clsx(styles.headings, styles.mobileOnly)}>
						{subTitle && (
							<LabelM className={styles.subTitle}>{subTitle}</LabelM>
						)}
						{title && (
							<SectionTitle
								texts={titlesLoop}
								as={HeadingXXL}
								className={styles.title}
							>
								{title}
							</SectionTitle>
						)}
					</div>

					<div className={styles.content}>
						<div className={styles.details}>
							<div className={styles.headings}>
								{subTitle && (
									<LabelM className={styles.subTitle}>{subTitle}</LabelM>
								)}
								{title && (
									<HeadingXXL
										as="h1"
										className={clsx(styles.title, {
											[styles.b2cTitle]: image
										})}
									>
										{title}
									</HeadingXXL>
								)}
							</div>

							{content && (
								<div className={styles.richContent}>
									{RichTextRenderer(styles)(content)}
								</div>
							)}

							{blocks && (
								<div className={styles.blocks}>
									<RenderBlock
										blocks={blocks}
										wrapperClass={styles.blockWrapper}
										linkClass={styles.button}
										formClass={styles.emailForm}
										inputClass={styles.emailInput}
									/>
								</div>
							)}
						</div>

						{imageLinks && imageLinks?.length > 0 && (
							<div className={styles.imageLinksWrapper}>
								{imageLinkChunks?.map((chunk, index) => (
									<div key={index} className={styles.imageLinkRow}>
										{chunk.map((imageLink) => {
											const image = imageLink?.image;
											return (
												<Link
													key={imageLink.id}
													className={styles.imageLinkBlock}
													href={imageLink.href}
													ariaLabel={imageLink.ariaLabel}
												>
													<p className="visually-hidden">
														{imageLink.image.alt}
													</p>
													<span className={styles.imageWrapper}>
														<Image
															role="img"
															src={image.src}
															alt={image.alt || ''}
															aria-hidden="true"
															width={image.width}
															height={image.height}
															priority
															style={{ maxWidth: '100%' }}
														/>
													</span>
													{imageLink.href && (
														<span style={{ lineHeight: 0 }}>
															<Icon
																name="ChevronDown"
																width={16}
																height={16}
																className={styles.imageLinkIcon}
															/>
														</span>
													)}
												</Link>
											);
										})}
									</div>
								))}
							</div>
						)}

						{image && !showGlobe && (
							<FigureImage
								noMagnify
								image={image}
								figureClass={styles.figureImg}
							/>
						)}
					</div>
				</div>
				{showGlobe && (
					<div className={styles.globeWrapper}>
						<GlobeAnimation />
					</div>
				)}
			</Container>
		</SectionWrapper>
	);
};

export default HeroImageBlock;
