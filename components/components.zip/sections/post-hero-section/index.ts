import PostHeroSection from './post-hero-section';
import type { PostHeroSectionProps } from './post-hero-section.types';

export default PostHeroSection;
export type { PostHeroSectionProps };
