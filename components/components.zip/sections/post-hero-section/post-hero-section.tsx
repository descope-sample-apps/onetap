import Image from 'next/image';
import clsx from 'clsx';

import Container from '@/components/elements/container';
import { HeadingXL, LabelM } from '@/components/elements/typography';
import Button from '@/components/elements/button/button';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import AuthorDetails from '@/components/elements/blog/author-details';
import DateFormat from '@/components/elements/date-format/date-format';
import PostShare from '@/components/elements/post-share';
import SectionDivider from '@/components/elements/section-divider';
import Gradient from '@/assets/section-bg/blog-post-hero.svg';

import type { PostHeroSectionProps } from './post-hero-section.types';
import styles from './post-hero-section.module.scss';
import { CopyArticleLink } from './components/copy-link';

const PostHeroSection = ({
	title,
	slug,
	topic,
	author,
	image,
	date,
	goBackLink,
	theme,
	order
}: PostHeroSectionProps) => {
	return (
		<>
			<SectionWrapper theme={theme} order={order} gradient={Gradient}>
				<Container className={styles.container}>
					<div className={styles.postInfo}>
						{goBackLink && (
							<Button
								className={styles.goBack}
								href={goBackLink.href}
								newVariant="tertiary"
								iconAlignment="left"
								iconName="ArrowLeft"
								size="large"
							>
								{goBackLink.text}
							</Button>
						)}
						<HeadingXL
							as="h1"
							className={clsx(styles.title, !slug && styles.singleTitle)}
						>
							{title}
						</HeadingXL>
						<div className={styles.details}>
							{topic && (
								<Button
									className={clsx(styles.detailItem, styles.topic)}
									newVariant="tertiary"
									href={`/blog/${topic.slug}`}
									size="large"
								>
									{topic.name}
								</Button>
							)}
							{date && (
								<LabelM
									as="span"
									className={clsx(styles.detailItem, styles.date)}
								>
									<DateFormat date={date} format="long" />
								</LabelM>
							)}
							{slug && <CopyArticleLink />}
						</div>
						{author && <AuthorDetails className={styles.author} {...author} />}
						{slug && <PostShare className={styles.shareButtons} />}
					</div>
					{image && (
						<figure className={styles.imageContainer}>
							<Image fill priority src={image.src} alt="" />
						</figure>
					)}
				</Container>
			</SectionWrapper>
			<SectionDivider />
		</>
	);
};

export default PostHeroSection;
