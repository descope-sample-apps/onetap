import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type Author from '@/types/blog/author';
import type { BlogTopic } from '@/types/blog/topic';
import type { Image } from '@/types/image';

export interface PostHeroSectionModel {
	title: string;
	slug?: string;
	image?: Image;
	goBackLink?: {
		href: string;
		text: string;
	};
	date?: string;
	topic?: BlogTopic;
	author?: Author;
}

export type PostHeroSectionProps = PostHeroSectionModel & SectionBaseProps;
