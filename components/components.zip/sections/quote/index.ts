import QuoteSection from './quote';

export default QuoteSection;
