import clsx from 'clsx';
import Image from 'next/image';
import Script from 'next/script';

import BlurredBackgroundCarousel from '@/assets/section-bg/quotes-carousel.svg';
import BlurredBackgroundSingleQuote from '@/assets/section-bg/gradient-light.svg';
import leftLine from '@/assets/svg-shapes/quote-left.svg';
import rightLine from '@/assets/svg-shapes/quote-right.svg';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import { LabelM, TextL } from '@/components/elements/typography';
import Container from '@/components/elements/container';
import { QuoteCarousel } from '@/components/sections/quote/carousel/quote-carousel';
import { DEFAULT_SECTION_THEME } from '@/config/consts.config';
import Button from '@/components/elements/button';

import styles from './quote.module.scss';
import type { QuoteSectionItem, QuoteSectionProps } from './quote.types';

const RichTextRendererSettings = { noLightboxImage: true };

const renderSingleQuoteItem = ({
	id,
	description,
	name,
	logo,
	link
}: QuoteSectionItem) => {
	return (
		<div key={id} className={clsx(styles.singleQuoteWrapper)}>
			{logo && (
				<figure>
					<Image
						src={logo.src}
						alt={logo.alt || ''}
						width={logo.width}
						height={logo.height}
						className={styles.singleQuoteLogo}
					/>
				</figure>
			)}
			{description && (
				<div className={styles.quoteDescription}>
					{RichTextRenderer(styles, RichTextRendererSettings)(description)}
				</div>
			)}
			{name && (
				<LabelM as={'p'} className={styles.customerName}>
					{name}
				</LabelM>
			)}
			{link &&
				link.map((item) => {
					const { style: _, iconName, ...props } = item;

					return (
						<Button
							key={item.id}
							as="a"
							className={styles.cardLink}
							iconName={iconName?.fields?.iconName}
							iconAlignment={props.iconAlignment}
							newVariant={props.newVariant}
							href={props.href}
							aria-hidden="true"
							tabIndex={-1}
						>
							<TextL as={'span'} isMedium>
								{item.text}
							</TextL>
						</Button>
					);
				})}
		</div>
	);
};

const SingleQuote = (props: QuoteSectionProps) => {
	const { items } = props;

	return (
		<div className={clsx(styles.singleQuote)}>
			<div className={clsx(styles.leadImage, styles.left)}>
				<Image
					src={leftLine}
					width={1000}
					height={303}
					alt=""
					style={{ height: 'auto' }}
				/>
			</div>

			<div className={styles.quoteDetails}>
				{items && renderSingleQuoteItem(items[0])}
			</div>

			<div className={clsx(styles.leadImage, styles.right)}>
				<Image
					src={rightLine}
					width={1000}
					height={303}
					alt=""
					style={{ height: 'auto' }}
				/>
			</div>
		</div>
	);
};

const QuoteSection = (props: QuoteSectionProps) => {
	const { items, sectionClass, theme, order } = props;

	const existingJSONLD =
		items?.filter((item) => item.json).map((item) => item.json) || [];
	const isSingleQuote = items?.length === 1;
	return (
		<>
			<SectionWrapper
				className={clsx(styles.quoteSection, sectionClass)}
				theme={theme || DEFAULT_SECTION_THEME}
				gradient={
					isSingleQuote
						? BlurredBackgroundSingleQuote
						: BlurredBackgroundCarousel
				}
				order={order}
			>
				{isSingleQuote ? (
					<SingleQuote {...props} />
				) : (
					<Container className={styles.container}>
						<QuoteCarousel {...props} />
					</Container>
				)}
			</SectionWrapper>
			{existingJSONLD?.length > 0 && (
				<Script type="application/ld+json" id={props.id}>
					{JSON.stringify({
						'@context': 'http://schema.org/',
						'@type': 'ItemList',
						itemListElement: [...existingJSONLD]
					})}
				</Script>
			)}
		</>
	);
};

export default QuoteSection;
