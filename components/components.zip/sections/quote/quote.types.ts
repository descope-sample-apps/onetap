import type { Document } from '@contentful/rich-text-types';
import type { ReactNode } from 'react';

import type { Image } from '@/types/image';
import type { Link } from '@/types/link';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';

export interface QuoteSectionItem {
	id: string;
	title?: string;
	name?: string;
	description?: Document | null;
	json?: string;
	logo?: Image;
	link?: Link[];
	inView?: boolean;
}

export interface QuoteSectionModel {
	ctaSectionType: 'Generic' | 'Quote Section';
	title?: string;
	description?: Document | null;
	variant?: 'Standard' | 'Small';
	items?: QuoteSectionItem[];
	sectionClass?: string;
	customDescription?: ReactNode;
}

export type QuoteSectionProps = SectionBaseProps & QuoteSectionModel;
