import clsx from 'clsx';
import Image from 'next/image';

import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import { HeadingXL, HeadingXXL, TextL } from '@/components/elements/typography';
import VideoBlock from '@/components/elements/video-block';
import SectionTitle from '@/components/elements/section-title';
import { LottieAnimationEager } from '@/components/elements/lottie-animation';
import ContactFormGradient from '@/assets/section-bg/contact-form.svg';

import type { ContactFormProps } from './contact-form.types';
import styles from './contact-form.module.scss';
import { ContactCTAVariant } from './components/contact-cta-variant';
import { ContactFormLinks } from './components/contact-form-links';
import Label from './components/label';
import Form from './components/form';

const ContactForm = ({
	id,
	h1,
	title,
	subTitle,
	flowId,
	styleId,
	formId,
	content,
	cFSectionType,
	routeId,
	theme,
	order,
	video = null,
	sectionLayoutRatio = '50/50',
	videoEmbedLink,
	image,
	showWires,
	links,
	titlesLoop
}: ContactFormProps) => {
	const hasVideo = Boolean(video || videoEmbedLink);
	const iscfList = cFSectionType === 'CF-List';
	const hasNoForm = !formId && !flowId && !hasVideo;
	const ctaVersion = hasNoForm && !iscfList;

	const is6040Type = sectionLayoutRatio === '60/40';
	const is7030Type = sectionLayoutRatio === '70/30';

	if (ctaVersion) {
		return (
			<ContactCTAVariant
				showWires={showWires}
				id={id}
				title={title}
				subTitle={subTitle}
				theme={theme}
				order={order}
				h1={h1}
				content={content}
				links={links}
				titlesLoop={titlesLoop}
			/>
		);
	}

	const isHubspotForm = !!formId;

	return (
		<SectionWrapper
			className={styles.contactSection}
			theme={theme}
			order={order}
			gradient={ContactFormGradient}
		>
			<Container>
				<div
					className={clsx(styles.contactContent, {
						[styles.isHubspotForm]: isHubspotForm,
						[styles.contactFormWithList]: iscfList,
						[styles.videoWrapper]: hasVideo,
						[styles.noForm]: iscfList && hasNoForm,
						[styles.ratio6040]: is6040Type,
						[styles.ratio7030]: is7030Type,
						[styles.listNoAssetNoForm]: iscfList && hasNoForm && !image
					})}
				>
					<div className={styles.contactDetails}>
						{subTitle && iscfList && (
							<Label className={styles.label} image={Boolean(image)}>
								{subTitle}
							</Label>
						)}

						{title && (
							<SectionTitle
								as={h1 || iscfList ? HeadingXXL : HeadingXL}
								className={styles.title}
								texts={titlesLoop}
							>
								{title}
							</SectionTitle>
						)}

						{subTitle && !iscfList && (
							<TextL className={styles.subTitle}>{subTitle}</TextL>
						)}

						<div className={styles.description}>
							{content && (
								<TextL as="div">{RichTextRenderer(styles)(content)}</TextL>
							)}
						</div>

						<ContactFormLinks links={links} />
					</div>

					<div className={styles.contactForm}>
						{hasVideo && (
							<VideoBlock
								video={video}
								videoEmbedLink={videoEmbedLink}
								className={styles.video}
							/>
						)}
						{!hasVideo && (
							<Form
								id={id}
								theme={theme}
								flowId={flowId}
								styleId={styleId}
								formId={formId}
								routeId={routeId}
							/>
						)}

						{hasNoForm &&
							iscfList &&
							(image ? (
								image.src.toString().endsWith('.lottie') ? (
									<LottieAnimationEager
										src={image.src as string}
										width={image.width!}
										height={image.height!}
									/>
								) : (
									<Image
										src={image.src}
										alt={image.alt || ''}
										width={image.width}
										height={image.height}
										className={styles.noFormImage}
									/>
								)
							) : (
								<LottieAnimationEager name="breathing-circle" />
							))}
					</div>
				</div>
			</Container>
		</SectionWrapper>
	);
};

export default ContactForm;
