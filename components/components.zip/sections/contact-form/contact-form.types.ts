import type { Document } from '@contentful/rich-text-types';

import type { Image } from '@/types/image';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { Link } from '@/types/link';

type BaseContactFormProps = SectionBaseProps & ContactFormModel;

interface ContactFormPropsWithEmbedLinkProps extends BaseContactFormProps {
	videoEmbedLink: string;
	video?: never;
}

interface ContactFormPropsWithCMSVideoProps extends BaseContactFormProps {
	video: Image | null;
	videoEmbedLink?: never;
}

export interface ContactFormModel {
	h1?: boolean;
	title: string;
	flowId: string | null;
	formId: string | null;
	styleId?: string;
	cFSectionType: 'Generic' | 'CF-List';
	subTitle?: string;
	content?: Document | null;
	routeId: string | null;
	videoEmbedLink?: string;
	video?: Image | null;
	showWires?: boolean;
	links?: Link[];
	image?: Image | null;
	sectionLayoutRatio: '50/50' | '60/40' | '70/30';
}

export type ContactFormProps =
	| ContactFormPropsWithEmbedLinkProps
	| ContactFormPropsWithCMSVideoProps;

export type ContactCTAVariantProps = Pick<
	ContactFormModel,
	'title' | 'subTitle' | 'content' | 'h1' | 'showWires' | 'links'
> &
	SectionBaseProps;
