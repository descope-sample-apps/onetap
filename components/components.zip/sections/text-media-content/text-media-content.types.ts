import type { Document } from '@contentful/rich-text-types';

import type { Image } from '@/types/image';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';

export interface TextMediaContentModel {
	image?: Image;
	title: string;
	content?: Document | null;
}

export type TextMediaContentProps = SectionBaseProps & TextMediaContentModel;
