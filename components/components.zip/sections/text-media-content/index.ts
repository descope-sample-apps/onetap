import TextMediaContent from './text-media-content';

export default TextMediaContent;
export type * from './text-media-content.types';
