import Image from 'next/image';

import { HeadingXL } from '@/components/elements/typography';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import SectionTitle from '@/components/elements/section-title';

import styles from './text-media-content.module.scss';
import type { TextMediaContentProps } from './text-media-content.types';

const TextMediaContent = ({
	title,
	image,
	content,
	theme,
	order,
	titlesLoop
}: TextMediaContentProps) => (
	<SectionWrapper theme={theme} order={order}>
		<Container>
			<div className={styles.wrapper}>
				<SectionTitle
					as={HeadingXL}
					texts={titlesLoop}
					className={styles.title}
				>
					{title}
				</SectionTitle>
				<div className={styles.content}>
					<div className={styles.text}>
						{content && RichTextRenderer(styles)(content)}
					</div>
					<div className={styles.media}>
						{image && (
							<Image
								src={image.src}
								alt={image.alt || ''}
								width={image.width}
								height={image.height}
								style={{ maxWidth: '100%', height: 'auto' }}
							/>
						)}
					</div>
				</div>
			</div>
		</Container>
	</SectionWrapper>
);

export default TextMediaContent;
