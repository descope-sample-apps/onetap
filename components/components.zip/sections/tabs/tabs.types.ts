import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { BlockItem } from '@/types/block';
import type { Link } from '@/types/link';

export interface TabsModel {
	title: string;
	tabItems: BlockItem[];
	ctaLink?: Link;
}

export type TabsProps = SectionBaseProps & TabsModel;
