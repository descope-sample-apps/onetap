'use client';

import clsx from 'clsx';
import { useState } from 'react';

import CodeBlock from '@/components/elements/code-block/code-block';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import { HeadingXL } from '@/components/elements/typography';
import type { BlockItem } from '@/types/block';
import type { TabItem } from '@/components/elements/tabs';
import { Tabs } from '@/components/elements/tabs';
import { Grid } from '@/components/elements/grid';
import type { CardProps } from '@/components/elements/card';
import Card from '@/components/elements/card';
import Link from '@/components/elements/link/link';
import LightboxImage from '@/components/elements/lightbox-image';

import type { TabsProps } from './tabs.types';
import styles from './tabs.module.scss';

const renderTabPanel = (tab: BlockItem) => {
	const { description, image, codeBlock, listItems } = tab;
	return (
		<div className={styles.tabPanel} key={tab.id}>
			{listItems?.length && listItems.length > 0 ? (
				<Grid className={styles.tabGridItems}>
					{listItems?.map((item, index) => {
						if (item.blockType === 'Card Block') {
							return (
								<Card
									key={`${item.id}-${index}`}
									className={styles.tabGridItem}
									{...(item as CardProps)}
								/>
							);
						}

						return null;
					})}
				</Grid>
			) : null}

			{description && (
				<div className={styles.content}>
					{RichTextRenderer(styles)(description)}
				</div>
			)}

			{(image || codeBlock) && (
				<div
					className={clsx(styles.tabBlock, image && styles.tabBlockWithImage)}
				>
					{image ? (
						<div className={styles.imageContainer}>
							<div className={styles.image}>
								<LightboxImage
									imageProps={{
										src: image.src,
										alt: image.alt || '',
										sizes: '506',
										fill: true,
										objectFit: 'contain'
									}}
								/>
							</div>
						</div>
					) : codeBlock ? (
						<CodeBlock
							code={codeBlock?.code}
							preClassName={styles.pre}
							language={codeBlock?.language}
							codeBlockClassName={styles.codeBlock}
						/>
					) : null}
				</div>
			)}
		</div>
	);
};

const TabsComponent = ({
	title,
	tabItems: tabComponentItems,
	ctaLink,
	theme,
	order
}: TabsProps) => {
	const [activeTab, setActiveTab] = useState(tabComponentItems[0]);
	const tabItems = tabComponentItems.map((item) => ({
		value: item.id,
		label: item.title
	}));

	const handleTabSelect = (tab: TabItem) => {
		const selectedTab = tabComponentItems.find((item) => item.id === tab.value);
		if (selectedTab) {
			setActiveTab(selectedTab);
		}
	};

	return (
		<SectionWrapper theme={theme} order={order} className={styles.tabsSection}>
			<Container className={styles.container}>
				<HeadingXL className={styles.title}>{title}</HeadingXL>

				<Tabs
					className={styles.tabsControlWrapper}
					tabs={tabItems as TabItem[]}
					onTabClick={handleTabSelect}
					value={activeTab.id || tabItems[0].value}
				/>
				{renderTabPanel(activeTab)}

				{ctaLink && (
					<div className={styles.ctaLinkWrapper}>
						<Link {...ctaLink}>{ctaLink.text}</Link>
					</div>
				)}
			</Container>
		</SectionWrapper>
	);
};

export default TabsComponent;
