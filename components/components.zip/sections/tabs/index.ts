import Tabs from './tabs';

export type * from './tabs.types';
export default Tabs;
