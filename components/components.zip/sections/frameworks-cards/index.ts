import FrameworksCards from './frameworks-cards';
import type { FrameworksCardsProps } from './frameworks-cards.types';

export default FrameworksCards;
export type { FrameworksCardsProps };
