import { HeadingM } from '@/components/elements/typography';
import Button from '@/components/elements/button/button';
import FrameworkCard from '@/components/elements/framework-card';

import type { FrameworksCardsProps } from './frameworks-cards.types';
import styles from './frameworks-cards.module.scss';

const FrameworksCards = ({
	heading,
	cards = [],
	href,
	linkText
}: FrameworksCardsProps) => {
	return (
		<div>
			<HeadingM className={styles.title} as="h3">
				{heading}
			</HeadingM>
			{cards.length > 0 && (
				<div className={styles.cardsContainer}>
					{cards.map((card) => (
						<FrameworkCard
							className={styles.frameworkCard}
							key={card.id}
							{...card}
						/>
					))}
				</div>
			)}
			{href && linkText && (
				<Button
					iconName="ArrowRight"
					size="large"
					newVariant="secondary"
					href={href}
					className={styles.frameworkLink}
				>
					{linkText}
				</Button>
			)}
		</div>
	);
};

export default FrameworksCards;
