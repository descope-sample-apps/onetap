import type { FrameworkCardProps } from '@/components/elements/framework-card';

export interface FrameworksCardsProps {
	id: string;
	heading?: string;
	cards?: FrameworkCardProps[];
	href?: string;
	linkText?: string;
}
