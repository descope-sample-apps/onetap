import type { FC } from 'react';
import Image from 'next/image';
import clsx from 'clsx';

import Container from '@/components/elements/container';
import { HeadingXL, TextL } from '@/components/elements/typography';
import SectionWrapper from '@/components/elements/section-wrapper';
import type { Image as ImageType } from '@/types/image';
import SectionTitle from '@/components/elements/section-title';
import TextImageVideoBackground from '@/assets/section-bg/text-image-video.svg';
import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';
import { Link } from '@/components/elements/link';

import type { TextImageVideoSectionProps } from './text-image-video-section.types';
import styles from './text-image-video-section.module.scss';
import LazyVideo from './components/lazy-video';

const Video: FC<
	({ video: ImageType | null } | { videoEmbedLink: string }) & {
		image?: ImageType | null;
	}
> = (props) => {
	if ('video' in props && props.video) {
		return (
			// eslint-disable-next-line jsx-a11y/media-has-caption
			<video controls src={props.video?.src} className={styles.embed}></video>
		);
	} else if ('videoEmbedLink' in props && props.videoEmbedLink) {
		return (
			<LazyVideo videoEmbedLink={props.videoEmbedLink} image={props.image} />
		);
	} else {
		return null;
	}
};

const TextImageVideoSection: FC<TextImageVideoSectionProps> = ({
	title,
	link,
	description,
	theme,
	order,
	image,
	titlesLoop,
	...videoProps
}) => {
	const isVideo = videoProps.video || videoProps.videoEmbedLink;

	return (
		<SectionWrapper
			theme={theme}
			order={order}
			gradient={TextImageVideoBackground}
		>
			<Container
				className={clsx(styles.wrapper, theme === 'light' && styles.light)}
			>
				<div className={styles.text}>
					{title && (
						<SectionTitle
							as={HeadingXL}
							className={styles.title}
							texts={titlesLoop}
						>
							{title}
						</SectionTitle>
					)}
					{description && (
						<TextL className={styles.content} as="div">
							{RichTextRenderer(styles)(description)}
						</TextL>
					)}
					{link && (
						<Link
							href={link.href}
							newTab={link.newTab}
							downloadFile={link.downloadFile}
							video={link.video}
							videoEmbedLink={link.videoEmbedLink}
							style={link.style}
							newVariant={link.newVariant}
							size={link.size}
							iconName={link.iconName}
							iconAlignment={link.iconAlignment}
							className={styles.button}
						>
							{link.text}
						</Link>
					)}
				</div>
				<div className={clsx(styles.imageVideo, !isVideo && styles.image)}>
					{isVideo ? (
						<Video {...videoProps} image={image} />
					) : (
						image && <Image src={image.src} alt={image.alt || ''} fill />
					)}
				</div>
			</Container>
		</SectionWrapper>
	);
};

export default TextImageVideoSection;
