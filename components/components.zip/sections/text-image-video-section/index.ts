import TextImageVideoSection from './text-image-video-section';

export type * from './text-image-video-section.types';
export default TextImageVideoSection;
