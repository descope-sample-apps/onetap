import type { Document } from '@contentful/rich-text-types';

import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { Image } from '@/types/image';
import type { Link } from '@/types/link';

type TextImageVideoSectionBaseProps = SectionBaseProps &
	TextImageVideoSectionModel;

interface TextImageVideoSectionWithEmbedLinkProps
	extends TextImageVideoSectionBaseProps {
	videoEmbedLink: string;
	video?: never;
}

interface TextImageVideoSectionWithCMSVideoProps
	extends TextImageVideoSectionBaseProps {
	video: Image | null;
	videoEmbedLink?: never;
}

export interface TextImageVideoSectionModel {
	title?: string;
	description?: Document | null;
	link?: Link;
	videoEmbedLink?: string;
	video?: Image | null;
	image?: Image | null;
}

export type TextImageVideoSectionProps =
	| TextImageVideoSectionWithCMSVideoProps
	| TextImageVideoSectionWithEmbedLinkProps;
