'use client';
import { Fragment, useState } from 'react';
import Image from 'next/image';
import clsx from 'clsx';

import SectionWrapper from '@/components/elements/section-wrapper';
import {
	HeadingXL,
	TextL,
	TextM,
	TextXL
} from '@/components/elements/typography';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import type { DetailedComparisonWrapper } from '@/types/detailed-comparison-wrapper';
import type { TabItem } from '@/components/elements/tabs';
import type { SectionTheme } from '@/types/page-block';

import Tabs from '../../elements/tabs/tabs';

import type { DetailedComparisonProps } from './detailed-comparison.types';
import styles from './detailed-comparison.module.scss';

const NUMBER_OF_COLUMNS = 2;

const renderRows = (
	{
		title,
		content,
		clientQuote
	}: DetailedComparisonProps['items'][number]['rows'][number],
	index: number,
	isLast: boolean
) => {
	const limitedContent = content.filter(
		(_, index) => index < NUMBER_OF_COLUMNS
	);

	return (
		<Fragment key={`${index}-row`}>
			<tr className={styles.tableContentTitleMobile}>
				<td colSpan={content.length} className={styles.tableContentTitle}>
					<TextL as="p" isMedium>
						{title}
					</TextL>
				</td>
			</tr>
			<tr className={clsx(isLast && styles.tableContentRow)}>
				<td
					rowSpan={clientQuote ? 2 : 1}
					className={clsx(
						styles.tableContentTitle,
						styles.tableContentTitleDesktop
					)}
				>
					<TextXL as="p" isMedium>
						{title}
					</TextXL>
				</td>
				{limitedContent.map((item, index) => (
					<td key={index} className={styles.tableContentText}>
						{item && RichTextRenderer(styles, { paragraphAs: TextM })(item)}
					</td>
				))}
			</tr>
			<tr className={clsx(isLast && clientQuote && styles.tableContentRow)}>
				{clientQuote && (
					<td
						colSpan={content.length}
						className={clsx(styles.tableContentText, styles.clientQuote)}
					>
						{clientQuote && RichTextRenderer(styles)(clientQuote)}
					</td>
				)}
			</tr>
		</Fragment>
	);
};

const renderTable = ({
	table,
	theme
}: {
	table: DetailedComparisonWrapper;
	theme: SectionTheme;
}) => {
	const isDarkMode = theme === 'dark';
	const { imagesDark, images, rows, id } = table;
	const imagesByTheme = isDarkMode ? images : imagesDark;
	const limitedImages = imagesByTheme?.filter(
		(_, index) => index < NUMBER_OF_COLUMNS
	);

	return (
		<div className={styles.tableContent} key={id}>
			<table className={styles.table}>
				<thead>
					<tr>
						<th
							className={clsx(
								styles.tableContentHeadPlaceholder,
								styles.tableContentHead
							)}
						></th>
						{limitedImages?.map((image, index) => (
							<th key={index} className={styles.tableContentHead}>
								<figure className={styles.tableContentHeadImage}>
									<Image
										src={image.src}
										alt={image.alt || ''}
										width={image.width}
										height={image.height}
										style={{
											maxWidth: '100%',
											height: 'auto',
											objectFit: 'contain'
										}}
									/>
								</figure>
							</th>
						))}
					</tr>
				</thead>
				<tbody>
					{rows?.map((value, index) =>
						renderRows(value, index, index === rows.length - 1)
					)}
				</tbody>
			</table>
		</div>
	);
};

export const DetailedComparison = ({
	title,
	items,
	theme,
	order
}: DetailedComparisonProps) => {
	const [activeTable, setActiveTable] = useState<DetailedComparisonWrapper>(
		items[0]
	);
	const tabItems = items.map((item) => ({
		value: item.id,
		label: item.title
	}));

	const handleTabSelect = (tab: TabItem) => {
		const selectedTable = items.find((item) => item.id === tab.value);
		if (selectedTable) {
			setActiveTable(selectedTable);
		}
	};

	return (
		<SectionWrapper theme={theme} order={order}>
			<Container className={styles.wrapper}>
				{title && (
					<HeadingXL as="h2" className={styles.title}>
						{title}
					</HeadingXL>
				)}
				<Tabs
					tabs={tabItems}
					onTabClick={handleTabSelect}
					value={activeTable.id || tabItems[0].value}
				/>
				{items.length > 0 && (
					<div className={styles.tableWrapper}>
						{renderTable({
							table: activeTable,
							theme: theme || 'light'
						})}
					</div>
				)}
			</Container>
		</SectionWrapper>
	);
};
