import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { DetailedComparisonWrapper } from '@/types/detailed-comparison-wrapper';

export interface DetailedComparisonModel {
	title: string;
	items: DetailedComparisonWrapper[];
}

export type DetailedComparisonProps = SectionBaseProps &
	DetailedComparisonModel;
