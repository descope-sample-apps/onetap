import { DetailedComparison } from './detailed-comparison';

export default DetailedComparison;
export type * from './detailed-comparison.types';
