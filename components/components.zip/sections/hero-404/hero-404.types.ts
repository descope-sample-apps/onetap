import type { Document } from '@contentful/rich-text-types';

import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { Link } from '@/types/link';
import type { Image } from '@/types/image';

export interface Hero404Model {
	title: string;
	subTitle: string;
	content?: Document | null;
	link?: Link;
	subLinks?: Link[];
	image?: Image | null;
}

export type ContentRoadProps = SectionBaseProps & Hero404Model;
