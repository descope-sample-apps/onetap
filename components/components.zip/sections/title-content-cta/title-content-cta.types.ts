import type { Document } from '@contentful/rich-text-types';

import type { Block } from '@/types/block';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { LottieName } from '@/components/elements/lottie-animation';
import type { Image } from '@/types/image';

export interface TitleContentCTAModel {
	h1?: boolean;
	title: string;
	subTitle?: string;
	content?: Document | null;
	useAnimatedIllustration?: boolean;
	linkBlocks?: Block[];
	lottie?: LottieName | null;
	image?: Image | null;
	addTopSpacing?: boolean;
}

export type TitleContentCTAProps = SectionBaseProps & TitleContentCTAModel;
