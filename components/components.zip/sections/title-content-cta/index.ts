import TitleContentCTA from './title-content-cta';

export type * from './title-content-cta.types';
export default TitleContentCTA;
