import clsx from 'clsx';

import RenderBlocks from '@/components/elements/blocks/blocks';
import RichTextRenderer from '@/components/elements/rich-text-renderer/rich-text-renderer';
import { LabelM, TextL } from '@/components/elements/typography';

import styles from './title-content-cta.module.scss';
import type { TitleContentCTAProps } from './title-content-cta.types';
import TitleContentCTAContainer from './components/container';
import TitleContentCTAHeading from './components/heading';
import { HeroImage, HomepageHeroLottie } from './components/hero';
import Wrapper from './components/wrapper';

const TitleContentCTA = ({
	title,
	content,
	subTitle,
	linkBlocks,
	lottie,
	image,
	titlesLoop,
	theme,
	order
}: TitleContentCTAProps) => {
	return (
		<Wrapper theme={theme} order={order}>
			<TitleContentCTAContainer order={order} image={image} subTitle={subTitle}>
				{subTitle && <LabelM className={styles.subTitle}>{subTitle}</LabelM>}
				{title && (
					<TitleContentCTAHeading
						titlesLoop={titlesLoop}
						order={order}
						theme={theme}
						title={title}
					/>
				)}

				{content && (
					<TextL as="div" className={styles.content}>
						{RichTextRenderer(styles)(content)}
					</TextL>
				)}

				{linkBlocks && linkBlocks.length > 0 && (
					<RenderBlocks
						blocks={linkBlocks}
						linkClass={styles.button}
						wrapperClass={clsx(
							styles.buttonsWrapper,
							order === 1 && styles.isFirstInPage
						)}
					/>
				)}
				{(lottie || image) && (
					<HeroImage lottie={lottie} image={image} order={order} />
				)}
			</TitleContentCTAContainer>
			<HomepageHeroLottie order={order} />
		</Wrapper>
	);
};

export default TitleContentCTA;
