import CaseStudyTemplate from './case-study-template';

export type * from './case-study-template.types';
export default CaseStudyTemplate;
