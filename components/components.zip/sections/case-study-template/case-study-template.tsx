import type { FC } from 'react';

import Container from '@/components/elements/container';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import SectionDivider from '@/components/elements/section-divider';
import RichTextContent from '@/components/elements/rich-text-content';
import SectionsRenderer from '@/components/elements/sections-renderer';

import styles from './case-study-template.module.scss';
import type { CaseStudyTemplateProps } from './case-study-template.types';
import CaseStudyHero from './components/hero';
import KeyPointsPanel from './components/key-points-panel';

const CaseStudyTemplate: FC<CaseStudyTemplateProps> = ({ caseStudy }) => {
	return (
		<>
			<CaseStudyHero title={caseStudy.title} image={caseStudy.image} />
			<SectionDivider />
			<SectionWrapper order={2} theme="light">
				<Container className={styles.contentWrapper}>
					<aside className={styles.keyPointsWrapper}>
						<KeyPointsPanel keyPoints={caseStudy.keyPoints} />
					</aside>
					<RichTextContent content={caseStudy.content} />
				</Container>
			</SectionWrapper>
			{caseStudy.sections && caseStudy.sections.length > 0 && (
				<SectionsRenderer sections={caseStudy.sections} />
			)}
		</>
	);
};

export default CaseStudyTemplate;
