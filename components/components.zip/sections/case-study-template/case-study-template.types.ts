import type { CaseStudy } from '@/types/case-study';
import type { Image } from '@/types/image';

export interface CaseStudyTemplateProps {
	caseStudy: CaseStudy;
}

export interface CaseStudyHeroProps {
	title: string;
	image?: Image;
}

export interface KeyPointsPanelProps {
	keyPoints: CaseStudy['keyPoints'];
	className?: string;
}
