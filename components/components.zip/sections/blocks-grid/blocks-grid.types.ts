import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { BlockItem } from '@/types/block';

export interface BlocksGridModel {
	title: string;
	gridItems?: BlockItem[];
}

export type BlocksGridProps = SectionBaseProps & BlocksGridModel;
