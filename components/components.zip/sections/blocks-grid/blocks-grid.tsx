import Link from 'next/link';
import Image from 'next/image';

import type { BlocksGridProps } from '@/components/sections/blocks-grid/blocks-grid.types';
import SectionWrapper from '@/components/elements/section-wrapper';
import Container from '@/components/elements/container';
import SectionTitle from '@/components/elements/section-title';
import { HeadingM, HeadingXL } from '@/components/elements/typography';
import RichTextRenderer from '@/components/elements/rich-text-renderer';
import { Icon } from '@/components/elements/icon';
import type { BlockItem } from '@/types/block';

import styles from './blocks-grid.module.scss';

const GridCard = ({ card, index }: { card: BlockItem; index: number }) => {
	return (
		<Link
			href={card.href || '/'}
			key={index}
			data-index={index}
			className={styles.card}
		>
			<div className={styles.textContent}>
				{card.title && (
					<div className={styles.titleWrapper}>
						<HeadingM className={styles.cardTitle}>{card.title}</HeadingM>
						<Icon name="ArrowRight" className={styles.arrow} />
					</div>
				)}
				{card.description && RichTextRenderer(styles)(card.description)}
			</div>
			{card.image && (
				<Image
					src={card.image.src}
					alt={card.image.alt || ''}
					width={card.image.width}
					height={card.image.height}
					className={styles.cardImage}
					data-index={index}
				/>
			)}
		</Link>
	);
};

const BlocksGrid = ({
	title,
	gridItems,
	theme,
	order,
	titlesLoop
}: BlocksGridProps) => {
	const baseItems = gridItems?.slice(0, 3);
	const additionalItems = gridItems?.slice(3);
	return (
		<SectionWrapper theme={theme} order={order}>
			<Container className={styles.sectionContainer}>
				{title && (
					<SectionTitle
						as={HeadingXL}
						className={styles.title}
						texts={titlesLoop}
					>
						{title}
					</SectionTitle>
				)}
				{baseItems && baseItems.length > 0 && (
					<div className={styles.grid}>
						{baseItems.map((item, index) => (
							<GridCard card={item} index={index} key={item.id} />
						))}
					</div>
				)}
				{additionalItems && additionalItems.length > 0 && (
					<div className={styles.additionalGrid}>
						{additionalItems.map((item, index) => (
							<GridCard card={item} index={index + 3} key={item.id} />
						))}
					</div>
				)}
			</Container>
		</SectionWrapper>
	);
};

export default BlocksGrid;
