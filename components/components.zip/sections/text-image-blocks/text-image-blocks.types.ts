import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { TextImageBlockProps } from '@/components/elements/text-image-block';

export interface TextImageBlocksModel {
	heading: string;
	blocks: TextImageBlockProps[];
}

export type TextImageBlocksProps = TextImageBlocksModel & SectionBaseProps;
