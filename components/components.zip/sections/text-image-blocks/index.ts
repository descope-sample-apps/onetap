import TextImageBlocks from './text-image-blocks';

export type * from './text-image-blocks.types';
export default TextImageBlocks;
