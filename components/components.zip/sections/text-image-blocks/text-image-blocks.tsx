import Container from '@/components/elements/container/container';
import SectionWrapper from '@/components/elements/section-wrapper/section-wrapper';
import SectionTitle from '@/components/elements/section-title';
import TextImageBlock from '@/components/elements/text-image-block/text-image-block';
import { HeadingXL } from '@/components/elements/typography';

import type { TextImageBlocksProps } from './text-image-blocks.types';
import styles from './text-image-blocks.module.scss';

const TextImageBlocks = ({
	heading,
	blocks,
	theme,
	order,
	titlesLoop
}: TextImageBlocksProps) => {
	return (
		<SectionWrapper theme={theme} order={order}>
			<Container className={styles.container}>
				{heading && (
					<SectionTitle
						className={styles.title}
						as={HeadingXL}
						texts={titlesLoop}
					>
						{heading}
					</SectionTitle>
				)}
				{blocks && (
					<div className={styles.blocksConatiner}>
						{blocks.map((block) => (
							<TextImageBlock key={block.id} {...block} />
						))}
					</div>
				)}
			</Container>
		</SectionWrapper>
	);
};

export default TextImageBlocks;
