import type { IconVariant } from '@/components/elements/icon';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';

export interface FlowsGridItem {
	id: string;
	title: string;
	tags: string[];
	description: string;
	link: {
		isExternal: boolean;
		href: string;
		newTab: boolean;
		text: string;
	};
	iconName?: IconVariant;
}

export interface FlowsGridModel {
	title: string;
	items: FlowsGridItem[];
}

export type FlowsGridProps = SectionBaseProps & FlowsGridModel;
