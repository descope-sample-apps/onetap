'use client';
import type { Dispatch, SetStateAction, FormEvent } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { useInView } from 'react-intersection-observer';

import SectionWrapper from '@/components/elements/section-wrapper';
import Container from '@/components/elements/container';
import { LoadingDots } from '@/components/elements/loading-dots';
import SectionTitle from '@/components/elements/section-title';
import { Tabs } from '@/components/elements/tabs';
import Input from '@/components/elements/input';
import { Icon } from '@/components/elements/icon';
import { HeadingXL } from '@/components/elements/typography';

import type { FlowsGridProps } from './flows-grid.types';
import { FlowGridCard } from './components/card/card';
import styles from './flows-grid.module.scss';

const getUniqueStrings = (arr: string[][]) => {
	const flattened = arr.flat();
	const unique = [...new Set(flattened)];
	const uniqueObjects = unique.map((str) => ({ value: str, label: str }));
	return [
		{
			value: 'All',
			label: 'All'
		},
		...uniqueObjects
	];
};

interface Value {
	label: string;
	value: string;
}

const DEFAULT_OPTION = {
	value: 'All',
	label: 'All'
};
const ITEMS_PER_PAGE = 9;

const FlowSearch = ({
	id,
	searchText,
	listItemsLength,
	handleSearch,
	setSearchText,
	isMobile = false
}: {
	id: string;
	searchText: string;
	listItemsLength: number;
	setSearchText: Dispatch<SetStateAction<string>>;
	handleSearch: (event: FormEvent<HTMLInputElement>) => void;
	isMobile?: boolean;
}) => {
	const handleClear = () => {
		setSearchText('');
	};

	return (
		<div className={styles.searchWrapper} data-mobile={isMobile}>
			<div className={styles.search}>
				<div style={{ position: 'relative' }}>
					<Input
						id={`search-${id}`}
						value={searchText}
						type="text"
						name={`search-${id}`}
						placeholder="Search Flows"
						icon="Search"
						onInput={handleSearch}
					/>
					{searchText && (
						<div
							aria-hidden="true"
							className={styles.clearButton}
							onClick={handleClear}
						>
							<Icon name="RemoveCircle" />
						</div>
					)}
				</div>
				{searchText && (
					<p className={styles.searchText}>
						{listItemsLength} result{listItemsLength !== 1 && 's'} for Flows
						matching{' '}
						<span className={styles.searchTextQuery}>
							&quot;{searchText.trim()}&quot;
						</span>
					</p>
				)}
			</div>
		</div>
	);
};

export const FlowsGrid = ({ title, items, theme, order }: FlowsGridProps) => {
	const [page, setPage] = useState(1);
	const [loading, setLoading] = useState(false);
	const [searchText, setSearchText] = useState('');
	const [selectedCategory, setSelectedCategory] =
		useState<Value>(DEFAULT_OPTION);
	const categories = getUniqueStrings(items.map((item) => item.tags));
	const handleSearch = (event: FormEvent<HTMLInputElement>) => {
		setSearchText(event.currentTarget.value);
	};

	const handleSelectedOption = (newValue: string) => {
		const selectedOption = categories.find(
			(category) => category.value === newValue
		);
		setSelectedCategory(selectedOption ?? DEFAULT_OPTION);
	};

	const filteredList = useMemo(() => {
		let _listItems = items;
		if (searchText) {
			_listItems = items.filter((item) =>
				item.title.toLowerCase().includes(searchText.toLowerCase().trim())
			);
		}
		_listItems =
			selectedCategory?.value === 'All' || !selectedCategory
				? _listItems
				: _listItems.filter((item) =>
						item.tags.includes(selectedCategory?.value ?? '')
					);
		return _listItems;
	}, [items, searchText, selectedCategory]);

	const list = filteredList.slice(0, page * ITEMS_PER_PAGE);

	const listItemsLength = filteredList.length;

	const shouldFetch =
		listItemsLength > ITEMS_PER_PAGE && list.length < listItemsLength;

	const handleInfiniteScroll = (inView: boolean) => {
		if (inView) {
			setLoading(true);
			setTimeout(() => {
				setPage(page + 1);
				setLoading(false);
			}, 300);
		}
	};

	const [viewMoreRoot] = useInView({
		onChange: handleInfiniteScroll
	});

	useEffect(() => {
		setPage(1);
	}, [selectedCategory, searchText]);

	return (
		<SectionWrapper theme={theme} order={order}>
			<Container className={styles.wrapper}>
				<div className={styles.titleWrapper}>
					{title && (
						<SectionTitle as={HeadingXL} className={styles.title}>
							{title}
						</SectionTitle>
					)}

					<FlowSearch
						id="mobile"
						isMobile
						handleSearch={handleSearch}
						listItemsLength={listItemsLength}
						searchText={searchText}
						setSearchText={setSearchText}
					/>
				</div>
				<div className={styles.controlWrapper}>
					<Tabs
						className={styles.tabsWrapper}
						onTabClick={({ value }) => handleSelectedOption(value)}
						tabs={categories}
						value={selectedCategory.value}
					/>
					<FlowSearch
						id="desktop"
						handleSearch={handleSearch}
						listItemsLength={listItemsLength}
						searchText={searchText}
						setSearchText={setSearchText}
					/>
				</div>
				<div className={styles.cardsContainer}>{list.map(FlowGridCard)}</div>
				{shouldFetch && (
					<>
						<div
							className={styles.viewMoreButtonWrapper}
							ref={viewMoreRoot}
						></div>
						{loading && <LoadingDots className={styles.loadingWrapper} />}
					</>
				)}
			</Container>
		</SectionWrapper>
	);
};
