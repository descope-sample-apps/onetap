import type { Document } from '@contentful/rich-text-types';

import type { Block, BlockItem } from '@/types/block';
import type { Image } from '@/types/image';
import type { SectionBaseProps } from '@/components/elements/section-wrapper';
import type { CardProps } from '@/components/elements/card';
import type { LottieName } from '@/components/elements/lottie-animation';

export interface FeaturesGridModel {
	title: string;
	subTitle: string;
	content?: Document | null;
	blocks?: Block[] | null;
	items?: FeatureGridItemProps[];
	hasCarousel?: boolean;
	hasCarouselOnMobile?: boolean;
	isLogoList?: boolean;
	showWires?: boolean;
	lottieName?: LottieName | null;
	image?: Image | null;
}

export type FeaturesGridProps = SectionBaseProps & FeaturesGridModel;

export type FeatureGridItemProps =
	| BlockItem
	| FeatureImageLinkProps
	| CardProps;

export interface FeatureImageLinkProps {
	id: string;
	href: string;
	image: Image;
	name: string;
}

export type FeatureGridVariantProps = Pick<
	FeaturesGridProps,
	| 'title'
	| 'subTitle'
	| 'items'
	| 'isLogoList'
	| 'showWires'
	| 'hasCarouselOnMobile'
	| 'lottieName'
	| 'image'
	| 'theme'
	| 'titlesLoop'
>;

export type FeatureCarouselVariantProps = Pick<
	FeaturesGridProps,
	'title' | 'subTitle' | 'items' | 'titlesLoop'
>;

export type FeatureGridItemComponentProps = { item: FeatureGridItemProps } & {
	hasCarousel: boolean;
	isCols2Layout?: boolean;
	className?: string;
};
