import clsx from 'clsx';

import RenderBlock from '@/components/elements/blocks/blocks';
import Container from '@/components/elements/container';
import RichTextRenderer from '@/components/elements/rich-text-renderer';

import type { FeaturesGridProps } from './features-grid.types';
import styles from './features-grid.module.scss';
import { CarouselVariant } from './components/carousel-variant';
import { GridVariant } from './components/grid-variant';
import FeaturesGridSection from './components/features-grid-section';

const FeaturesGrid = ({
	title,
	items,
	blocks,
	content,
	subTitle,
	hasCarousel,
	isLogoList,
	theme,
	order,
	showWires,
	hasCarouselOnMobile,
	lottieName,
	image,
	titlesLoop
}: FeaturesGridProps) => {
	// @ts-expect-error
	const isVideoBlockSection = items[0]?.blockType === 'Video Block Card';

	return (
		<FeaturesGridSection
			isVideoBlockSection={isVideoBlockSection}
			theme={theme}
			order={order}
		>
			<Container
				className={clsx({ [styles.containerMask]: isVideoBlockSection })}
			>
				<div
					className={clsx(
						(hasCarousel || hasCarouselOnMobile) && styles.sliderBox
					)}
				>
					{hasCarousel ? (
						<CarouselVariant
							title={title}
							subTitle={subTitle}
							items={items}
							titlesLoop={titlesLoop}
						/>
					) : (
						<GridVariant
							title={title}
							subTitle={subTitle}
							items={items}
							isLogoList={isLogoList}
							showWires={showWires}
							hasCarouselOnMobile={hasCarouselOnMobile}
							lottieName={lottieName}
							image={image}
							theme={theme}
							titlesLoop={titlesLoop}
						/>
					)}

					{content && (
						<div className={styles.content}>
							{RichTextRenderer(styles)(content)}
						</div>
					)}

					{blocks && (
						<div className={styles.joinLink}>
							<RenderBlock
								blocks={blocks}
								wrapperClass={styles.featuresBlocks}
								formClass={styles.emailForm}
								inputClass={styles.emailInput}
								linkClass={styles.featuresLink}
							/>
						</div>
					)}
				</div>
			</Container>
		</FeaturesGridSection>
	);
};

export default FeaturesGrid;
