import FeaturesGrid from './features-grid';

export default FeaturesGrid;
export type * from './features-grid.types';
