'use client';

import clsx from 'clsx';
import React, { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import dynamic from 'next/dynamic';

import Hamburger from '@/components/elements/hamburger';
import LogoGIF from '@/components/elements/logo-gif/logo-gif';
import { useDisableBodyScroll } from '@/hooks/use-disable-page-scroll';
import useToggle from '@/hooks/use-toggle';
import Container from '@/components/elements/container';

import type { NavbarProps } from './navbar.types';
import styles from './navbar.module.scss';
import NavbarContainer from './components/navbar-container';

const MobileMenu = dynamic(
	() => import('./components/mobile-menu/mobile-menu'),
	{ ssr: false }
);

const NavbarMobile = ({ links }: Pick<NavbarProps, 'links'>) => {
	const pathname = usePathname();
	const mobileMenuOpen = useToggle('off');

	useDisableBodyScroll(mobileMenuOpen?.isOn || false);

	useEffect(() => {
		React.startTransition(() => {
			mobileMenuOpen?.setOff();
		});
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [pathname]);

	useEffect(() => {
		const topWideBanner = document.getElementById('top-wide-banner');

		if (!topWideBanner) {
			return;
		}

		if (mobileMenuOpen?.isOn) {
			topWideBanner.style.maxHeight = '0';
			topWideBanner.style.overflow = 'hidden';
			topWideBanner.style.padding = '0';
		} else {
			topWideBanner.style.maxHeight = '';
			topWideBanner.style.padding = '';
			topWideBanner.style.overflow = '';
		}
	}, [mobileMenuOpen?.isOn]);

	return (
		<>
			<NavbarContainer
				className={clsx(styles.mobile, mobileMenuOpen?.isOn && styles.full)}
			>
				<Container className={clsx(styles.containerMobile, styles.navbar)}>
					<LogoGIF className={styles.logo} />
					<Hamburger
						open={mobileMenuOpen?.isOn || false}
						onClick={mobileMenuOpen?.toggle}
					/>
				</Container>
			</NavbarContainer>
			{mobileMenuOpen?.isOn && (
				<MobileMenu links={links} onToggleParentMenu={mobileMenuOpen.toggle} />
			)}
		</>
	);
};

export default NavbarMobile;
