'use client';

import type { FC } from 'react';
import clsx from 'clsx';
import { usePathname } from 'next/navigation';

import { Link } from '@/components/elements/link';
import { Icon, type IconVariant } from '@/components/elements/icon';
import { TextM } from '@/components/elements/typography';

import type { SubLinkButtonProps } from '../navbar.types';

import styles from './links-block/links-block.module.scss';

const SubLinkButton: FC<SubLinkButtonProps> = ({
	className,
	href,
	text,
	newTab,
	iconName,
	tabIndex
}) => {
	const pathname = usePathname();
	const icon = iconName?.fields?.iconName as unknown as IconVariant;

	return (
		<Link
			href={href}
			className={clsx(
				styles.subLinkButton,
				pathname === href && styles.isActive,
				className
			)}
			newTab={newTab}
			style="link"
			tabIndex={tabIndex}
		>
			<Icon name={icon} className={styles.icon} />
			<TextM as="span">{text}</TextM>
			{newTab && <Icon name="ArrowTopRight" className={styles.externalIcon} />}
		</Link>
	);
};

export default SubLinkButton;
