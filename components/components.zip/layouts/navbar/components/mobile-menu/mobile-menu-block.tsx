'use client';

import clsx from 'clsx';
import { useState } from 'react';
import { usePathname } from 'next/navigation';

import { TextL } from '@/components/elements/typography';
import { Icon } from '@/components/elements/icon';

import type { BlockProps } from '../../navbar.types';
import SublinkContentMobile from '../sublink-content/sublink-content.mobile';

import styles from './mobile-menu.module.scss';

const NavBlock = ({
	id,
	text,
	href,
	linkClasses,
	onToggleParentMenu,
	navLinkItemBlocks
}: BlockProps) => {
	const pathname = usePathname();

	const [active, setActive] = useState<string | null>(null);

	const isOn = active === id;
	const toggle = () => setActive(isOn ? null : id);

	const hasSubLinks = navLinkItemBlocks && navLinkItemBlocks.length > 0;
	const isActive = hasSubLinks
		? navLinkItemBlocks?.some((block) =>
				block?.links.some((link) => link.href === pathname)
			)
		: href === pathname;

	return (
		<li key={id} className={clsx(styles.navBlock, isOn && styles.open)}>
			<button
				onClick={toggle}
				className={clsx(linkClasses, styles.buttonLinkItem, {
					[styles.active]: pathname === href || id === active || isActive
				})}
			>
				<TextL
					as="span"
					isMedium
					className={clsx(styles.navBlockTitle, isOn && styles.active)}
				>
					{text}
				</TextL>
				<Icon name="ChevronRight" />
			</button>
			{isOn && (
				<SublinkContentMobile
					navLinkItemBlocks={navLinkItemBlocks}
					onToggleSubMenu={toggle}
					onToggleParentMenu={onToggleParentMenu}
					subMenuTitle={text}
				/>
			)}
		</li>
	);
};

export default NavBlock;
