import clsx from 'clsx';

import type { Link as NavbarLink } from '@/types/link';
import { Link } from '@/components/elements/link';
import { TextL } from '@/components/elements/typography';
import Button from '@/components/elements/button';
import routes from '@/lib/routes';

import type { NavbarProps } from '../../navbar.types';

import styles from './mobile-menu.module.scss';
import NavBlock from './mobile-menu-block';

const renderButton = ({
	id,
	href,
	text,
	newVariant,
	iconName,
	iconAlignment
}: NavbarLink) => {
	return (
		<Link
			key={id}
			style="button"
			href={href}
			newVariant={newVariant}
			size="large"
			iconName={iconName}
			iconAlignment={iconAlignment}
		>
			{text}
		</Link>
	);
};

interface MobileMenuProps extends Pick<NavbarProps, 'links'> {
	onToggleParentMenu?: () => void;
}

const MobileMenu = ({ links, onToggleParentMenu }: MobileMenuProps) => {
	const buttonLinks = links.filter((link) => link.style === 'button');
	const otherLinks = links.filter((link) => link.style === 'link');

	const renderLinks = (props: NavbarLink) => {
		const { id, href, text, newTab, navLinkItemBlocks } = props;

		const linkClasses = clsx(styles.mobileMenuItem);

		if (navLinkItemBlocks && navLinkItemBlocks.length > 0) {
			return (
				<NavBlock
					key={id}
					{...props}
					href={href}
					linkClasses={linkClasses}
					onToggleParentMenu={onToggleParentMenu}
				/>
			);
		}

		return (
			<li key={id} className={linkClasses}>
				<Link href={href} newTab={newTab}>
					<TextL as="span" isMedium className={styles.navBlockTitle}>
						{text}
					</TextL>
				</Link>
			</li>
		);
	};

	return (
		<div className={clsx(styles.mobileMenu, 'dark')}>
			<ul className={styles.mobileMenuList}>{otherLinks.map(renderLinks)}</ul>
			<div className={styles.buttonLink}>
				<div className={styles.buttonLinkButtons}>
					{Array.isArray(buttonLinks) && buttonLinks.map(renderButton)}
				</div>
				<Button
					href={routes.DESCOPE_APP_LINK}
					newVariant="tertiary"
					iconName="UserCircle"
					iconAlignment="right"
				>
					<TextL isMedium as="span">
						Log In
					</TextL>
				</Button>
			</div>
		</div>
	);
};

export default MobileMenu;
