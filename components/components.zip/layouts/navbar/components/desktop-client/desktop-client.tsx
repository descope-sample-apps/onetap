'use client';

import clsx from 'clsx';
import { useRef, useEffect, useState, useMemo } from 'react';
import { usePathname } from 'next/navigation';
// eslint-disable-next-line import/no-namespace
import * as Primitive from '@radix-ui/react-navigation-menu';

import useToggle from '@/hooks/use-toggle';
import useTabletOnly from '@/hooks/use-tablet-only';
import { useScroll } from '@/hooks/use-scroll';

import type { NavbarProps } from '../../navbar.types';
import styles from '../../navbar.module.scss';
import DesktopLink from '../desktop-link';

const calculateMarginLeft = (linkOpen: number, isTablet: boolean) => {
	if (linkOpen === 2) {
		if (isTablet) {
			return '100px';
		} else {
			return '-100px';
		}
	} else if (linkOpen > 2) {
		return `${(linkOpen - 3) * 250}px`;
	} else {
		if (isTablet) {
			return `${linkOpen * 350 - 340}px`;
		} else {
			return `${linkOpen * 400 - 400}px`;
		}
	}
};

const NavbarDesktopClient = ({ links }: NavbarProps) => {
	const blurEffectInDom = useToggle();
	const blurEffectVisible = useToggle();
	const { isScrolled } = useScroll();

	const megaMenuOpen = useToggle();
	const pathname = usePathname();
	const isTablet = useTabletOnly();

	const cooldownTimerRef = useRef<NodeJS.Timeout | null>(null);
	const previousLinkOpenRef = useRef<number>(-1);

	const [linkOpen, setLinkOpen] = useState<number>(-1);
	const [isRouteChanging, setIsRouteChanging] = useState(false);

	const handleOpen = () => megaMenuOpen.setOn();
	const handleClose = () => megaMenuOpen.setOff();

	const marginLeft = useMemo(() => {
		if (previousLinkOpenRef.current !== -1 && linkOpen === -1) {
			const value = calculateMarginLeft(previousLinkOpenRef.current, isTablet);
			previousLinkOpenRef.current = linkOpen;
			return value;
		}

		previousLinkOpenRef.current = linkOpen;
		return calculateMarginLeft(linkOpen, isTablet);
	}, [linkOpen, isTablet]);

	useEffect(() => {
		if (megaMenuOpen.isOn) {
			blurEffectVisible?.setOn();
			blurEffectInDom?.setOn();
			return;
		}

		let timeout2: NodeJS.Timeout;

		setLinkOpen(-1);
		const timeout = setTimeout(() => {
			blurEffectVisible?.setOff();

			timeout2 = setTimeout(() => blurEffectInDom?.setOff(), 400);
		}, 100);

		return () => {
			clearTimeout(timeout);
			timeout2 && clearTimeout(timeout2);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [megaMenuOpen.isOn]);

	useEffect(() => {
		setIsRouteChanging(true);
		handleClose();

		if (cooldownTimerRef.current) {
			clearTimeout(cooldownTimerRef.current);
		}

		cooldownTimerRef.current = setTimeout(() => {
			setIsRouteChanging(false);
		}, 500); // Adjust this delay as needed

		return () => {
			if (cooldownTimerRef.current) {
				clearTimeout(cooldownTimerRef.current);
			}
		};
	}, [pathname]);

	useEffect(() => {
		const mainContainer = document.getElementsByClassName(
			'main-container-blur'
		)?.[0];

		const navbarDesktop = document.querySelector(
			'nav[data-block="navbar-desktop"]'
		);

		if (navbarDesktop) {
			if (blurEffectVisible.isOn) {
				navbarDesktop.classList.add('blurEffectVisible');
			} else {
				navbarDesktop.classList.remove('blurEffectVisible');
			}
		}

		if (!mainContainer) return;

		if (blurEffectVisible.isOn) {
			mainContainer.classList.add('visible');
		} else {
			mainContainer.classList.remove('visible');
		}

		if (isScrolled) {
			mainContainer.classList.add('isScrolled');
		} else {
			mainContainer.classList.remove('isScrolled');
		}
	}, [blurEffectVisible.isOn, isScrolled]);

	return (
		<Primitive.Root>
			<Primitive.List className={styles.items}>
				{links.map((link, index) => (
					<DesktopLink
						key={link.id}
						index={index}
						{...link}
						pathname={pathname || ''}
						megaMenuOpen={megaMenuOpen}
						linkOpen={{ value: linkOpen, setValue: setLinkOpen }}
					/>
				))}
			</Primitive.List>
			<div
				className={clsx(
					styles.viewportPosition,
					isRouteChanging && styles.hidden
				)}
			>
				<Primitive.Viewport
					className={styles.viewport}
					style={{ marginLeft }}
					onFocusCapture={handleOpen}
					onFocus={handleOpen}
					onMouseEnter={handleOpen}
					onMouseLeave={handleClose}
					onClick={handleOpen}
				/>
			</div>
		</Primitive.Root>
	);
};

export default NavbarDesktopClient;
