import type { FC } from 'react';
import clsx from 'clsx';

import { LabelS } from '@/components/elements/typography';
import type { LinksBlockProps } from '@/components/layouts/navbar';

import SubLinkButton from '../sublink-button';

import styles from './links-block.module.scss';

const MAX_LINKS_IN_COLUMN = 6;

const LinksBlock: FC<LinksBlockProps> = ({
	title,
	links,
	className,
	isSingle
}) => {
	return (
		<div className={clsx(styles.container, className)}>
			{title && (
				<>
					<LabelS className={styles.title}>{title}</LabelS>
					<span className={styles.line} />
				</>
			)}
			<div
				className={clsx(
					styles.linksContainer,
					links.length <= MAX_LINKS_IN_COLUMN && styles.singleColumn,
					isSingle && styles.singleColumnTablet
				)}
			>
				{Array.isArray(links) &&
					links.map((link) => <SubLinkButton key={link.id} {...link} />)}
			</div>
		</div>
	);
};

export default LinksBlock;
