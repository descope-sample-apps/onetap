'use client';

// eslint-disable-next-line import/no-namespace
import * as Primitive from '@radix-ui/react-navigation-menu';
import clsx from 'clsx';

import { TextS } from '@/components/elements/typography';
import { Icon } from '@/components/elements/icon';

import styles from '../navbar.module.scss';
import type { DesktopLinkProps } from '../navbar.types';

import SublinkContent from './sublink-content/sublink-content';

const DesktopLink = ({
	id,
	index,
	href,
	text,
	navLinkItemBlocks,
	pathname,
	megaMenuOpen,
	linkOpen
}: DesktopLinkProps) => {
	const hasSubLinks = navLinkItemBlocks && navLinkItemBlocks.length > 0;
	const isActive = hasSubLinks
		? navLinkItemBlocks?.some((block) =>
				block?.links.some((link) => link.href === pathname)
			)
		: href === pathname;

	const isMegaMenuOpen = megaMenuOpen.isOn && linkOpen.value === index;

	const handleOpen = () => {
		megaMenuOpen.setOn();
		linkOpen.setValue(index);
	};
	const handleClose = () => {
		megaMenuOpen.setOff();
		linkOpen.setValue(-1);
	};

	if (!hasSubLinks) {
		return (
			<Primitive.Item key={id} className={styles.linkContainer}>
				<Primitive.Link
					key={id}
					className={clsx(
						styles.link,
						isActive && linkOpen.value === -1 && styles.active
					)}
					onMouseEnter={() => linkOpen.setValue(index)}
					onMouseLeave={handleClose}
					href={href}
				>
					<TextS isMedium>{text}</TextS>
				</Primitive.Link>
			</Primitive.Item>
		);
	}

	return (
		<Primitive.Item
			key={id}
			className={styles.linkContainer}
			onMouseEnter={handleOpen}
			onMouseLeave={handleClose}
		>
			<Primitive.Trigger
				className={clsx(
					styles.link,
					((isActive && linkOpen.value === -1) || isMegaMenuOpen) &&
						styles.active
				)}
			>
				<TextS isMedium>{text}</TextS>
				<Icon name="CaretDown" />
			</Primitive.Trigger>

			<Primitive.Content
				className={styles.linkDropdown}
				onMouseEnter={handleOpen}
				onEscapeKeyDown={handleClose}
				onPointerDownOutside={handleClose}
				onFocusOutside={handleClose}
				onInteractOutside={handleClose}
			>
				<SublinkContent navLinkItemBlocks={navLinkItemBlocks} />
			</Primitive.Content>
		</Primitive.Item>
	);
};

export default DesktopLink;
