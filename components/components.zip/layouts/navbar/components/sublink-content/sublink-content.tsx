'use client';

import type { FC } from 'react';
import Image from 'next/image';
import clsx from 'clsx';

import { LabelS, TextM } from '@/components/elements/typography';
import { Link } from '@/components/elements/link';
import useMobileOnly from '@/hooks/use-mobile-only';
import Tooltip from '@/components/elements/tooltip';
import { Icon } from '@/components/elements/icon';

import type { SublinkContentProps } from '../../navbar.types';
import LinksBlock from '../links-block/links-block';
import PostCard from '../post-card/post-card';

import styles from './sublink-content.module.scss';

const SDKS_FRAMEWORKS_TITLE = `sdks and frameworks`;

const SublinkContent: FC<SublinkContentProps> = ({ navLinkItemBlocks }) => {
	const isMobile = useMobileOnly();

	const linkBlocks = navLinkItemBlocks
		? navLinkItemBlocks.filter(
				(block) =>
					block.title?.toLowerCase() !== SDKS_FRAMEWORKS_TITLE &&
					block.featuredPosts?.length === 0
			)
		: [];

	const sdksFrameworksBlock = navLinkItemBlocks
		? navLinkItemBlocks.find(
				(block) =>
					block.title?.toLowerCase() === SDKS_FRAMEWORKS_TITLE &&
					block.featuredPosts?.length === 0
			)
		: null;
	const articlesBlock = navLinkItemBlocks
		? navLinkItemBlocks.find((block) => block.featuredPosts?.length > 0)
		: null;
	const singleColumn = navLinkItemBlocks?.length === 1;

	return (
		<>
			<div className={styles.linkDropdownCol} id="drawer">
				<div className={styles.linkDropdownContent}>
					<div className={styles.blocks}>
						{linkBlocks.map((block, i) => (
							<LinksBlock
								key={i}
								title={block.title}
								links={block.links}
								className={styles.block}
								isSingle={singleColumn}
								featuredPosts={block.featuredPosts}
							/>
						))}
					</div>
				</div>
				{sdksFrameworksBlock && (
					<div
						className={clsx(
							styles.linkDropdownContent,
							styles.sdksFrameworksBlock
						)}
					>
						{sdksFrameworksBlock.title && (
							<>
								<LabelS className={styles.title}>
									{sdksFrameworksBlock.title}
								</LabelS>
								<span className={styles.line} />
							</>
						)}
						<div className={styles.sdksGrid}>
							{sdksFrameworksBlock.links.map((link) => (
								<Tooltip key={link.id} label={link.text}>
									<Link
										className={styles.sdksGridItem}
										href={link.href}
										newTab={link.newTab}
									>
										<div className={styles.logo}>
											{link.icon?.src && (
												<Image
													src={link.icon.src}
													alt={link.icon?.alt || link.text}
													width={24}
													height={24}
													aria-hidden
												/>
											)}
										</div>
										<TextM as="span">
											{link.text}
											{link.newTab && <Icon name="ArrowTopRight" />}
										</TextM>
									</Link>
								</Tooltip>
							))}
						</div>
					</div>
				)}
			</div>
			{articlesBlock && (
				<div
					className={clsx(
						styles.linkDropdownContent,
						styles.articles,
						articlesBlock.featuredPosts.length === 1 && styles.singleArticle
					)}
				>
					{articlesBlock.title && (
						<>
							<LabelS className={clsx(styles.title, styles.padding)}>
								{articlesBlock.title}
							</LabelS>
							<span className={styles.line} />
						</>
					)}
					<div className={styles.blogCardsContainer}>
						{articlesBlock.featuredPosts.map((post) => (
							<PostCard
								key={post.id}
								variant={
									articlesBlock.featuredPosts.length === 1 && !isMobile
										? 'col'
										: 'row'
								}
								post={post}
							/>
						))}
					</div>
				</div>
			)}
		</>
	);
};

export default SublinkContent;
