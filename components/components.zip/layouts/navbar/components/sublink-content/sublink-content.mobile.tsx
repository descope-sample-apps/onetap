'use client';

import type { FC } from 'react';
import Image from 'next/image';
import clsx from 'clsx';
import { FloatingPortal } from '@floating-ui/react';

import {
	HeadingS,
	LabelS,
	TextL,
	TextM
} from '@/components/elements/typography';
import { Link } from '@/components/elements/link';
import Tooltip from '@/components/elements/tooltip';
import { Icon } from '@/components/elements/icon';
import Container from '@/components/elements/container/container';
import Hamburger from '@/components/elements/hamburger';

import type { SublinkContentProps } from '../../navbar.types';
import LinksBlock from '../links-block/links-block';
import PostCard from '../post-card/post-card';

import styles from './sublink-content.module.scss';

const SDKS_FRAMEWORKS_TITLE = `sdks and frameworks`;

const SublinkContentMobile: FC<SublinkContentProps> = ({
	navLinkItemBlocks,
	onToggleSubMenu,
	onToggleParentMenu,
	subMenuTitle
}) => {
	const linkBlocks = navLinkItemBlocks
		? navLinkItemBlocks.filter(
				(block) =>
					block.title?.toLowerCase() !== SDKS_FRAMEWORKS_TITLE &&
					block.featuredPosts?.length === 0
			)
		: [];
	const sdksFrameworksBlock = navLinkItemBlocks
		? navLinkItemBlocks.find(
				(block) =>
					block.title?.toLowerCase() === SDKS_FRAMEWORKS_TITLE &&
					block.featuredPosts?.length === 0
			)
		: null;
	const articlesBlock = navLinkItemBlocks
		? navLinkItemBlocks.find((block) => block.featuredPosts?.length > 0)
		: null;
	const singleColumn = navLinkItemBlocks?.length === 1;

	const handleSubMenuActive = () => {
		onToggleSubMenu?.();
	};

	const handleToggleParentMenu = () => {
		onToggleParentMenu?.();
	};

	return (
		<FloatingPortal>
			<div className={styles.linkDropdownCol}>
				<Container className={styles.subMenuControlContainer}>
					{/* Temp solution for catch focus on portal */}
					<input
						aria-hidden={true}
						readOnly
						// eslint-disable-next-line jsx-a11y/no-autofocus
						autoFocus
						className="visually-hidden"
					/>
					<button
						aria-label="Go Back"
						onClick={handleSubMenuActive}
						className={styles.goBack}
					>
						<Icon name="ArrowLeft" />
						<TextL isMedium>Back</TextL>
					</button>
					<Hamburger open onClick={handleToggleParentMenu} />
				</Container>

				<div className={styles.linkDropdownContent}>
					<HeadingS className={styles.subMenuHeading}>{subMenuTitle}</HeadingS>
					<div className={styles.blocks}>
						{linkBlocks.map((block, i) => (
							<LinksBlock
								key={i}
								{...block}
								className={styles.block}
								isSingle={singleColumn}
							/>
						))}
					</div>
				</div>
				{sdksFrameworksBlock && (
					<div
						className={clsx(
							styles.linkDropdownContent,
							styles.sdksFrameworksBlock
						)}
					>
						{sdksFrameworksBlock.title && (
							<>
								<LabelS className={styles.title}>
									{sdksFrameworksBlock.title}
								</LabelS>
								<span className={styles.line} />
							</>
						)}
						<div className={styles.sdksGrid}>
							{sdksFrameworksBlock.links.map((link) => (
								<Tooltip key={link.id} label={link.text}>
									<Link
										className={styles.sdksGridItem}
										href={link.href}
										newTab={link.newTab}
									>
										<div className={styles.logo}>
											{link.icon?.src && (
												<Image
													src={link.icon.src}
													alt={link.icon?.alt || link.text}
													width={24}
													height={24}
													aria-hidden
												/>
											)}
										</div>
										<TextM as="span">
											{link.text}
											{link.newTab && <Icon name="ArrowTopRight" />}
										</TextM>
									</Link>
								</Tooltip>
							))}
						</div>
					</div>
				)}
				{articlesBlock && (
					<div
						className={clsx(
							styles.linkDropdownContent,
							styles.articles,
							styles.articlesMobile,
							articlesBlock.featuredPosts.length === 1 && styles.singleArticle
						)}
					>
						{articlesBlock.title && (
							<>
								<LabelS className={clsx(styles.title, styles.padding)}>
									{articlesBlock.title}
								</LabelS>
								<span className={styles.line} />
							</>
						)}
						<div className={styles.blogCardsContainer}>
							{articlesBlock.featuredPosts.map((post) => (
								<PostCard
									key={post.id}
									variant={
										articlesBlock.featuredPosts.length === 1 ? 'col' : 'row'
									}
									post={post}
								/>
							))}
						</div>
					</div>
				)}
			</div>
		</FloatingPortal>
	);
};

export default SublinkContentMobile;
