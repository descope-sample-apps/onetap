import type { FC } from 'react';
import clsx from 'clsx';
import Image from 'next/image';

import type { BlogPostMin } from '@/types/blog/post';
import type { LCPostMin } from '@/types/learning-center/post';
import Link from '@/components/elements/link/link';
import routes from '@/lib/routes';
import { TextM, TextS } from '@/components/elements/typography';
import DateFormat from '@/components/elements/date-format/date-format';

import styles from './post-card.module.scss';

interface PostCardProps {
	variant?: 'row' | 'col';
	post: LCPostMin | BlogPostMin;
}

const PostCard: FC<PostCardProps> = ({ variant = 'col', post }) => {
	const href =
		post.type === 'LCPost'
			? routes.POST(post.slug)
			: routes.BLOG_POST(post.slug);

	const date = post.publishedDate || post.lastModified;

	return (
		<Link
			className={clsx(styles.container, variant === 'col' && styles.col)}
			href={href}
		>
			<div className={styles.image}>
				{post.tileImage && (
					<Image
						src={post.tileImage.src}
						alt={post.tileImage.alt || post.title}
						fill
					/>
				)}
			</div>
			<div className={styles.details}>
				{date && (
					<TextS className={styles.date}>
						<DateFormat date={date} format="short" />
					</TextS>
				)}
				<TextM className={styles.title}>{post.title}</TextM>
			</div>
		</Link>
	);
};

export default PostCard;
