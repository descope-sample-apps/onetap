'use client';

import clsx from 'clsx';
import { usePathname } from 'next/navigation';

import Container, {
	type ContainerProps
} from '@/components/elements/container';
import { useScroll } from '@/hooks/use-scroll';
import routes from '@/lib/routes';

import styles from '../navbar.module.scss';

const SCROLL_THRESHOLD = 128;

const NavbarContainer = (props: ContainerProps) => {
	const { scrollPosition } = useScroll();
	const pathname = usePathname();

	const transparentNavbar =
		pathname === routes.HOME_ROUTE && scrollPosition <= SCROLL_THRESHOLD;

	return (
		<Container
			as="nav"
			{...props}
			className={clsx(
				styles.navbarWrapper,
				scrollPosition > SCROLL_THRESHOLD && styles.scrolled,
				transparentNavbar && styles.transparent,
				'dark',
				props.className
			)}
		/>
	);
};

export default NavbarContainer;
