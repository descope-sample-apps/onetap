import NavbarDesktop from './navbar.desktop';
import NavbarMobile from './navbar.mobile';
import type { NavbarProps } from './navbar.types';

const Navbar = ({ links }: NavbarProps) => (
	<>
		<NavbarDesktop links={links} />
		<NavbarMobile links={links} />
	</>
);

export default Navbar;
