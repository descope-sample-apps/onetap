import clsx from 'clsx';
import { type FC } from 'react';
import dynamic from 'next/dynamic';

import { Link } from '@/components/elements/link';
import LogoGIF from '@/components/elements/logo-gif/logo-gif';
import type { Link as NavbarLink } from '@/types/link';
import Container from '@/components/elements/container';

import type { NavbarProps } from './navbar.types';
import styles from './navbar.module.scss';
import NavbarContainer from './components/navbar-container';

const NavbarDesktopClient = dynamic(
	() => import('./components/desktop-client/desktop-client')
);

const Button = ({
	id,
	href,
	text,
	newVariant,
	size,
	iconName,
	iconAlignment
}: NavbarLink) => {
	return (
		<Link
			key={id}
			style="button"
			href={href}
			newVariant={newVariant}
			size={size}
			iconName={iconName}
			iconAlignment={iconAlignment}
		>
			{text}
		</Link>
	);
};

const NavbarDesktop: FC<Pick<NavbarProps, 'links'>> = ({
	links: linkBlocks
}) => {
	const links = linkBlocks.filter((link) => link.style === 'link');
	const buttons = linkBlocks.filter((link) => link.style === 'button');

	return (
		<NavbarContainer data-block="navbar-desktop" className={styles.desktop}>
			<Container className={clsx(styles.containerDesktop, styles.navbar)}>
				<div className={styles.logoLinks}>
					<LogoGIF large />
					<NavbarDesktopClient links={links} />
				</div>
				<div className={clsx(styles.items, styles.buttons)}>
					{buttons.map(Button)}
				</div>
			</Container>
		</NavbarContainer>
	);
};

export default NavbarDesktop;
