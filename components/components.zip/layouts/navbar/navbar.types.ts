import type { Dispatch, SetStateAction } from 'react';

import type { Image } from '@/types/image';
import type { Link, NavLinkItemBlock } from '@/types/link';
import type useToggle from '@/hooks/use-toggle';

export type BlockProps = Link & {
	href: string;
	linkClasses: string;
	onToggleParentMenu?: () => void;
};

export interface NavbarProps {
	links: Link[];
	logo?: Image;
	blurEffectInDom?: ReturnType<typeof useToggle>;
	blurEffectVisible?: ReturnType<typeof useToggle>;
}

export type DesktopLinkProps = NavbarProps['links'][number] & {
	index: number;
	pathname: string;
	megaMenuOpen: Pick<
		ReturnType<typeof useToggle>,
		'isOn' | 'isOff' | 'setOff' | 'setOn'
	>;
	linkOpen: {
		value: number;
		setValue: Dispatch<SetStateAction<number>>;
	};
};

export type LinksBlockProps = NonNullable<
	NavbarProps['links'][number]['navLinkItemBlocks']
>[number] & { className?: string; isSingle?: boolean };

export type SubLinkButtonProps = Link & {
	className?: string;
	tabIndex?: number;
};

export interface SublinkContentProps {
	navLinkItemBlocks?: NavLinkItemBlock[];
	onToggleSubMenu?: () => void;
	onToggleParentMenu?: () => void;
	subMenuTitle?: string;
}
