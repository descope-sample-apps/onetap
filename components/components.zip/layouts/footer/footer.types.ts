import type { ReactNode } from 'react';

import type { Link } from '@/types/link';
import type { Image } from '@/types/image';
import type { ImageLink } from '@/types/image-link';

export type BlockProps = Link & {
	linkClasses: string;
	href: string;
};

export type FooterIcon = ImageLink;

export interface FooterProps {
	logo?: Image;
	status?: string;
	copyrightText?: string;
	items: (Link | string)[];
	socialMediaIcons?: FooterIcon[];
	footerBadge?: ImageLink;
	statusComponent?: ReactNode;
}
