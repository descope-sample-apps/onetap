import clsx from 'clsx';
import Image from 'next/image';
import { Suspense } from 'react';

import { Link } from '@/components/elements/link';
import { TextM } from '@/components/elements/typography';
import type { Link as LinkType } from '@/types/link';
import LogoDark from '@/components/elements/logo/logo-dark';
import { SlackButton } from '@/components/elements/slack-button/slack-button';

import styles from './footer.module.scss';
import type { FooterProps } from './footer.types';
import { renderIcon } from './footer.desktop';
import Block from './components/block';

const FooterMobile = ({
	items,
	copyrightText,
	footerBadge,
	statusComponent,
	socialMediaIcons
}: FooterProps) => {
	const renderFooterItem = (item: LinkType | string) => {
		if (typeof item === 'string') return renderText(item);
		return renderLink(item);
	};

	const renderLink = (props: LinkType) => {
		const { href, text, newTab, navLinkItemBlocks } = props;

		const linkClasses = clsx(styles.item, {
			[styles.blockHead]: navLinkItemBlocks
			// [styles.active]: pathname === href
		});

		if (navLinkItemBlocks) {
			return (
				<Block
					{...props}
					key={props.id}
					href={href}
					linkClasses={linkClasses}
				/>
			);
		}

		return (
			<li id={props.id} key={props.id} className={linkClasses}>
				<Link href={href} newTab={newTab}>
					<TextM as="span" key={props.id} className={styles.blockTitle}>
						{text}
					</TextM>
				</Link>
			</li>
		);
	};

	const renderText = (text: string) => (
		<TextM className={styles.item} key={text}>
			{text}
		</TextM>
	);

	return (
		<div className={clsx(styles.footer, styles.footerMobile)}>
			<div className={styles.container}>
				<div className={styles.logoMobile}>
					<LogoDark id="0" width={135} height={32} />
				</div>
				<SlackButton />
				<ul className={styles.itemsMobile}>{items.map(renderFooterItem)}</ul>
				<hr className={styles.divider} />
				{footerBadge && (
					<div className={styles.badgeWrapper}>
						<Image
							src={footerBadge.image?.src}
							alt={footerBadge?.image?.alt || ''}
							width={footerBadge.image?.width}
							height={footerBadge.image?.height}
							style={{
								maxWidth: '81px',
								height: 'auto'
							}}
						/>
						<TextM as={Link} isMedium newTab href={footerBadge?.href}>
							Leave a Descope review
						</TextM>
					</div>
				)}
				<hr className={styles.divider} />
				<div className={styles.bottom}>
					<div className={styles.icons}>
						{socialMediaIcons?.map(renderIcon)}
					</div>
					<hr className={styles.divider} />
					<Suspense>{statusComponent}</Suspense>
					<TextM className={styles.copy}>{copyrightText}</TextM>
				</div>
			</div>
		</div>
	);
};

export default FooterMobile;
