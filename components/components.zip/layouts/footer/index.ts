import Footer from './footer';

export type * from './footer.types';

export default Footer;
