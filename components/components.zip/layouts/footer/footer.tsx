import type { FooterProps } from './footer.types';
import FooterDesktop from './footer.desktop';
import FooterMobile from './footer.mobile';

const Footer = (props: FooterProps) => {
	const { statusComponent, ...rest } = props;

	return (
		<>
			<FooterDesktop {...rest} statusComponent={statusComponent} />
			<FooterMobile {...rest} statusComponent={statusComponent} />
		</>
	);
};

export default Footer;
