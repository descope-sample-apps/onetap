'use client';

import clsx from 'clsx';
import { useState } from 'react';
import { usePathname } from 'next/navigation';

import { Link } from '@/components/elements/link';
import { TextL, TextM } from '@/components/elements/typography';
import { Icon } from '@/components/elements/icon';

import styles from '../footer.module.scss';
import type { BlockProps } from '../footer.types';

const Block = ({
	id,
	text,
	linkClasses,
	href,
	navLinkItemBlocks
}: BlockProps) => {
	const [active, setActive] = useState<string | null>(null);
	const pathname = usePathname();
	const isOn = active === id;
	const toggle = () => setActive(isOn ? null : id);

	return (
		<li key={id} className={clsx(styles.block, isOn && styles.open)}>
			<button
				aria-expanded={isOn}
				onClick={toggle}
				className={clsx(linkClasses, { [styles.active]: pathname === href })}
			>
				<TextL
					key={id}
					as="span"
					isMedium
					className={clsx(styles.blockTitle, isOn && styles.active)}
				>
					{text}
				</TextL>
				<Icon
					name="CaretDown"
					className={clsx(styles.dropdown, isOn && styles.open)}
				/>
			</button>
			{isOn && (
				<div className={styles.blockBody}>
					{navLinkItemBlocks?.map((block) =>
						block.links.map(({ id, text, href, newTab }) => (
							<TextM
								key={id}
								as={Link}
								href={href}
								newTab={newTab}
								newVariant="secondary"
								className={styles.blockLink}
							>
								{text}
							</TextM>
						))
					)}
				</div>
			)}
		</li>
	);
};

export default Block;
