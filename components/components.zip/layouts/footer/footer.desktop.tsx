import clsx from 'clsx';
import { Suspense } from 'react';
import type React from 'react';
import Image from 'next/image';

import { Link } from '@/components/elements/link';
import LogoDark from '@/components/elements/logo/logo-dark';
import { TextL, TextM } from '@/components/elements/typography';
import Container from '@/components/elements/container';
import type { Link as LinkType } from '@/types/link';
import { SlackButton } from '@/components/elements/slack-button/slack-button';

import styles from './footer.module.scss';
import type { FooterIcon, FooterProps } from './footer.types';

const minColLinksIndex = 3;

const renderText = (text: string) => (
	<TextM className={styles.item} key={text}>
		{text}
	</TextM>
);

const renderLink = (link: LinkType) => {
	const { id, href, text, style, newTab, navLinkItemBlocks } = link;
	const rest = { style, newTab };

	if (navLinkItemBlocks) {
		return (
			<div key={id} className={styles.item}>
				<TextL isMedium className={styles.text}>
					{text}
				</TextL>
				<ul className={styles.block}>
					{navLinkItemBlocks.map((block) =>
						block.links?.map(({ id, text, href }) => (
							<li key={id} className={styles.blockItem}>
								<TextM
									{...rest}
									as={Link}
									href={href}
									className={styles.blockLink}
								>
									{text}
								</TextM>
							</li>
						))
					)}
				</ul>
			</div>
		);
	}

	return (
		<TextM
			key={id}
			as={Link}
			{...rest}
			href={href}
			isMedium
			className={clsx(styles.link, styles.text)}
		>
			{text}
		</TextM>
	);
};

const renderFooterItem = (item: LinkType | string) => {
	if (typeof item === 'string') return renderText(item);
	return renderLink(item);
};

const Footer: React.FC<FooterProps> = ({
	items,
	copyrightText,
	footerBadge,
	statusComponent,
	socialMediaIcons
}) => {
	return (
		<Container
			as="footer"
			className={clsx(styles.footer, styles.footerDesktop, 'light')}
		>
			<div className={styles.container}>
				<div className={styles.containerItems}>
					<div className={styles.logoColumn}>
						<LogoDark />
						<SlackButton />
						{footerBadge && (
							<div className={styles.badgeWrapper}>
								<Image
									src={footerBadge.image?.src}
									alt={footerBadge?.image?.alt || ''}
									width={footerBadge.image?.width}
									height={footerBadge.image?.height}
									style={{
										maxWidth: '98px',
										height: 'auto'
									}}
								/>
								<Link newTab href={footerBadge?.href}>
									Leave a Descope review
								</Link>
							</div>
						)}
					</div>

					<div className={styles.itemLinksColumn}>
						<div className={styles.itemLinksColumnTop}>
							{items.slice(0, minColLinksIndex).map(renderFooterItem)}
						</div>
						<div className={styles.itemLinksColumnBottom}>
							{items.slice(minColLinksIndex).map(renderFooterItem)}
						</div>
					</div>
				</div>
				<div className={styles.bottom}>
					<TextM className={styles.copy}>{copyrightText}</TextM>
					<div className={styles.bottomSocials}>
						<Suspense>{statusComponent}</Suspense>
						<div className={styles.icons}>
							{socialMediaIcons?.map(renderIcon)}
						</div>
					</div>
				</div>
			</div>
		</Container>
	);
};

export const renderIcon = ({ id, href, image, ariaLabel }: FooterIcon) => (
	<Link
		newTab
		key={id}
		className={styles.icon}
		href={href}
		ariaLabel={ariaLabel}
	>
		<p className="visually-hidden">{image.alt}</p>
		<Image
			role="img"
			src={image.src}
			alt={image.alt || ''}
			aria-hidden="true"
			width={image.width}
			height={image.height}
			style={{
				maxWidth: '100%',
				height: 'auto'
			}}
		/>
	</Link>
);

export default Footer;
