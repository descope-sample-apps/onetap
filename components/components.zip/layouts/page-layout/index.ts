import PageLayout from './page-layout';

export default PageLayout;
