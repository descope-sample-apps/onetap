import { Suspense } from 'react';

import BannerBlock from '@/components/elements/banner-block';
import { SystemStatusBadge } from '@/components/elements/systems-status-badge';
import { SlackChatButtonProvider } from '@/components/providers/slack-chat-button';

import Navbar from '../navbar';
import Footer from '../footer';

import type { PageLayoutProps } from './page-layout.types';

const PageLayout = (props: PageLayoutProps) => {
	const { navbar, footer, siteBannerBlock, children } = props;

	return (
		<SlackChatButtonProvider isSlackButtonActive={true}>
			{siteBannerBlock && <BannerBlock {...siteBannerBlock} siteWide={true} />}
			{navbar && <Navbar {...navbar} />}
			<main>{children}</main>
			{footer && (
				<Footer
					{...footer}
					statusComponent={
						<Suspense fallback={null}>
							<SystemStatusBadge statusPlatformUrl={footer.status ?? ''} />
						</Suspense>
					}
				/>
			)}
		</SlackChatButtonProvider>
	);
};

export default PageLayout;
