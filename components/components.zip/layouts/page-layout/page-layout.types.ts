import type React from 'react';

import type { BlockItem } from '@/types/block';

import type { NavbarProps } from '../navbar';
import type { FooterProps } from '../footer';

export interface GlobalLayout {
	navbar?: NavbarProps;
	footer?: FooterProps;
	hubspotFormId?: string;
	siteBannerBlock?: BlockItem;
	newsletterText?: string;
	isSlackChatButtonActive?: boolean;
}

export interface PageLayoutProps extends GlobalLayout {
	children: React.ReactNode;
}
