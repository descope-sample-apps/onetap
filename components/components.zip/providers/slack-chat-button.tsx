'use client';

import type { ReactNode } from 'react';
import { createContext, useContext } from 'react';

interface SlackChatButtonContextType {
	isSlackButtonActive: boolean;
}

const SlackChatButtonContext = createContext<
	SlackChatButtonContextType | undefined
>(undefined);

interface SlackChatButtonProviderProps {
	children: ReactNode;
	isSlackButtonActive: boolean;
}

export const useSlackChatButtonContext = () => {
	const context = useContext(SlackChatButtonContext);
	if (context === undefined) {
		throw new Error(
			'useSlackChatButtonContext must be used within a SlackChatButtonProvider'
		);
	}
	return context;
};

export const SlackChatButtonProvider = ({
	children,
	isSlackButtonActive
}: SlackChatButtonProviderProps) => {
	return (
		<SlackChatButtonContext.Provider value={{ isSlackButtonActive }}>
			{children}
		</SlackChatButtonContext.Provider>
	);
};
