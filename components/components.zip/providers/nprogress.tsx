'use client';

import dynamic from 'next/dynamic';
import type { ReactNode } from 'react';

const ProgressBar = dynamic(
	() => import('next-nprogress-bar').then((mod) => mod.AppProgressBar),
	{ ssr: false, loading: () => null }
);

const NProgressProvider = ({
	children,
	nonce
}: {
	children: ReactNode;
	nonce: string;
}) => {
	return (
		<>
			{children}
			<ProgressBar
				height="2px"
				color="#126fc7"
				options={{ showSpinner: true }}
				shallowRouting
				nonce={nonce}
			/>
		</>
	);
};

export default NProgressProvider;
