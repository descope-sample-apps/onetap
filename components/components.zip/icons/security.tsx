import { IconBase, type IconComponent } from '@/components/elements/icon';

const Security: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M5.25 9.75h13.5s1.5 0 1.5 1.5v10.5s0 1.5-1.5 1.5H5.25s-1.5 0-1.5-1.5v-10.5s0-1.5 1.5-1.5ZM6.75 9.75V6a5.25 5.25 0 1 1 10.5 0v3.75M12 15v3"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Security;
