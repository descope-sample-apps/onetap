import { IconBase, type IconComponent } from '@/components/elements/icon';

const CredentialStuffing: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M5.25.746h16.5s1.5 0 1.5 1.5v16.5s0 1.5-1.5 1.5H5.25s-1.5 0-1.5-1.5v-16.5s0-1.5 1.5-1.5Z" />
			<path d="M20.25 23.246h-18a1.5 1.5 0 0 1-1.5-1.5v-18" />
			<path
				d="M8.857 14.858a.857.857 0 1 0 0-1.714.857.857 0 0 0 0 1.714ZM13.571 14.858a.857.857 0 1 0 0-1.714.857.857 0 0 0 0 1.714ZM18.286 14.858a.857.857 0 1 0 0-1.714.857.857 0 0 0 0 1.714Z"
				fill="currentColor"
			/>
			<path d="M8.25 5.746h10.5M8.25 8.746h7.5" />
		</g>
	</IconBase>
);

export default CredentialStuffing;
