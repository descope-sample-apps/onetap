import { IconBase, type IconComponent } from '@/components/elements/icon';

const GlobalReach: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M12 23.143c6.154 0 11.143-4.989 11.143-11.143C23.143 5.846 18.154.857 12 .857 5.846.857.857 5.846.857 12c0 6.154 4.99 11.143 11.143 11.143Z" />
			<path d="M1.715 16.286h3a3 3 0 0 0 3-3v-2.571a3 3 0 0 1 3-3 3 3 0 0 0 3-3V.978M23.143 11.829a6.104 6.104 0 0 0-2.777-.686h-3.651a3 3 0 0 0 0 6 2.143 2.143 0 0 1 2.143 2.143v1.491" />
		</g>
	</IconBase>
);

export default GlobalReach;
