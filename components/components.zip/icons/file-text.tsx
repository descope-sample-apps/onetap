import { IconBase, type IconComponent } from '@/components/elements/icon';

const FileText: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M14.2863 14.2861C14.2863 14.5892 14.1659 14.8799 13.9515 15.0942C13.7372 15.3085 13.4465 15.4289 13.1434 15.4289H2.8577C2.5546 15.4289 2.26391 15.3085 2.04958 15.0942C1.83525 14.8799 1.71484 14.5892 1.71484 14.2861V1.71463C1.71484 1.41153 1.83525 1.12084 2.04958 0.906512C2.26391 0.692185 2.5546 0.571777 2.8577 0.571777H8.57199L14.2863 6.28606V14.2861Z" />
		<path d="M5.14258 5.14307H7.42829" />
		<path d="M5.14258 8.57178H10.8569" />
		<path d="M5.14258 12.0005H10.8569" />
	</IconBase>
);

export default FileText;
