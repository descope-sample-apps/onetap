import { IconBase, type IconComponent } from '@/components/elements/icon';

const Client: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M22.372 19.977a1.227 1.227 0 0 1-1.1 1.775H2.726a1.224 1.224 0 0 1-1.1-1.775L3 15.748h18l1.372 4.229Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M6 3.754H4.506a1.5 1.5 0 0 0-1.5 1.5v10.5H21v-10.5a1.5 1.5 0 0 0-1.5-1.5H18M11.25 18.752h1.5"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M9.375 4.879a2.625 2.625 0 1 0 5.25 0 2.625 2.625 0 0 0-5.25 0ZM7.5 12.754a4.5 4.5 0 1 1 9 0h-9Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Client;
