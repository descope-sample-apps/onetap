import { type IconComponent, IconBase } from '../elements/icon';

const Hyperlink: IconComponent = (props) => (
	<IconBase
		width="20"
		height="21"
		viewBox="0 0 20 21"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M5.714 9.772 1.13 14.315a1.428 1.428 0 0 0 0 2.028l3.028 3.029a1.43 1.43 0 0 0 2.029 0l4.543-4.586M14.286 11.229l4.543-4.543a1.428 1.428 0 0 0 0-2.029L15.843 1.63a1.428 1.428 0 0 0-2.028 0L9.272 6.214M12.857 7.643l-5.714 5.714"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Hyperlink;
