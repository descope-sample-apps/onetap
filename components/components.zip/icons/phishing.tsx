import { IconBase, type IconComponent } from '@/components/elements/icon';

const Phishing: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M3.333 8.834h17.334S22 8.834 22 10.167v10.667s0 1.333-1.333 1.333H3.333S2 22.167 2 20.833V10.168s0-1.333 1.333-1.333ZM15.277 15.91l3.39 3.133M8.722 15.91l-3.389 3.133"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="m21.671 11.5-8.456 5.831a2.139 2.139 0 0 1-2.43 0L2.33 11.5"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M15.667 5.5v3m-3.334 4.333A3.333 3.333 0 0 1 9 9.5V4.833l1.5 1.5M14.333 4.167a1.333 1.333 0 1 0 2.667 0 1.333 1.333 0 0 0-2.667 0ZM15.667 2.5V1"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Phishing;
