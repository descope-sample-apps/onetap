import { IconBase, type IconComponent } from '@/components/elements/icon';

const Close: IconComponent = (props) => (
	<IconBase
		width="20"
		height="20"
		viewBox="0 0 20 20"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M19.2863 0.715332L0.714844 19.2868" />
		<path d="M0.714844 0.715332L19.2863 19.2868" />
	</IconBase>
);

export default Close;
