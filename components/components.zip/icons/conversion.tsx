import { IconBase, type IconComponent } from '@/components/elements/icon';

const Conversion: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M14.885 17.625V12l7.788-7.788c.433-.433.577-.866.577-1.443 0-1.154-.865-2.019-2.02-2.019H2.77C1.614.75.75 1.615.75 2.77c0 .576.144 1.009.577 1.442L9.115 12v11.25l5.77-5.625Z"
			strokeWidth="1.5"
			strokeMiterlimit="10"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Conversion;
