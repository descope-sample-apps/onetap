import { IconBase, type IconComponent } from '@/components/elements/icon';

const Support: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M2.572 10.286h1.714a.857.857 0 0 1 .857.857v4.286a.857.857 0 0 1-.857.857H2.572a1.714 1.714 0 0 1-1.715-1.714V12a1.714 1.714 0 0 1 1.715-1.714v0ZM21.43 16.286h-1.715a.857.857 0 0 1-.857-.857v-4.286a.857.857 0 0 1 .857-.857h1.714A1.714 1.714 0 0 1 23.144 12v2.572a1.715 1.715 0 0 1-1.715 1.714v0Z" />
			<path d="M16.286 21a3.429 3.429 0 0 0 3.429-3.428v-1.286" />
			<path d="M14.143 18.857a2.143 2.143 0 0 1 0 4.286h-2.571a2.143 2.143 0 1 1 0-4.286h2.571ZM4.286 10.286V8.572a7.714 7.714 0 0 1 15.429 0v1.714M9.429 6.857V9.43M14.572 6.857V9.43M9.429 12.857c0 2.28 5.143 2.28 5.143 0" />
		</g>
	</IconBase>
);

export default Support;
