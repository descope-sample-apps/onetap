import { IconBase, type IconComponent } from '@/components/elements/icon';

const Banking: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M1.5 23.25h21M1.5 20.25h21M3 9.75v7.5M6 9.75v7.5M10.5 9.75v7.5M13.5 9.75v7.5M18 9.75v7.5M21 9.75v7.5M22.5 6.75h-21L11.189.988a1.5 1.5 0 0 1 1.622 0L22.5 6.75Z" />
		</g>
	</IconBase>
);

export default Banking;
