import { IconBase, type IconComponent } from '@/components/elements/icon';

const TimeBasedOTP: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M12.0001 23.1432C17.2074 23.1432 21.4287 18.9218 21.4287 13.7146C21.4287 8.50733 17.2074 4.28601 12.0001 4.28601C6.79285 4.28601 2.57153 8.50733 2.57153 13.7146C2.57153 18.9218 6.79285 23.1432 12.0001 23.1432Z" />
		<path d="M9.42871 0.857422H14.5716" />
		<path d="M12 0.857422V4.28599" />
		<path d="M9.42871 10.286L12.0001 13.7146H16.2859" />
		<path d="M20.5715 3.42883L22.2858 5.14312" />
		<path d="M3.42864 3.42883L1.71436 5.14312" />
	</IconBase>
);

export default TimeBasedOTP;
