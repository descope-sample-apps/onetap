import { IconBase, type IconComponent } from '@/components/elements/icon';

const UX: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M15 23.254H9l.75-4.5h4.5l.75 4.5ZM6.75 23.254h10.5M3.75.754h16.5s3 0 3 3v12s0 3-3 3H3.75s-3 0-3-3v-12s0-3 3-3Z" />
			<path d="M3.75 9.754a4.5 4.5 0 1 0 9 0 4.5 4.5 0 0 0-9 0Z" />
			<path d="M8.25 5.254v4.5l3.182 3.182M15.75 6.754h3M15.75 9.754h3M15.75 12.754h3" />
		</g>
	</IconBase>
);

export default UX;
