import { IconBase, type IconComponent } from '@/components/elements/icon';

const ChevronDown: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M1.71387 7.4975L12.2567 18.0404C12.3337 18.1224 12.4266 18.1877 12.5298 18.2324C12.633 18.2771 12.7443 18.3001 12.8567 18.3001C12.9692 18.3001 13.0804 18.2771 13.1836 18.2324C13.2868 18.1877 13.3798 18.1224 13.4567 18.0404L23.9996 7.4975" />
	</IconBase>
);

export default ChevronDown;
