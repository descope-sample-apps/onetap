import { IconBase, type IconComponent } from '@/components/elements/icon';

const Question: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5">
			<path
				d="M21.75 18.75h-10.5l-6 4.5v-4.5h-3a1.5 1.5 0 0 1-1.5-1.5v-15a1.5 1.5 0 0 1 1.5-1.5h19.5a1.5 1.5 0 0 1 1.5 1.5v15a1.5 1.5 0 0 1-1.5 1.5Z"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
			<path
				d="M9 6.75a3 3 0 1 1 4 2.828 1.5 1.5 0 0 0-1 1.415v.256"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
			<path d="M12 15a.375.375 0 0 1 0-.75M12 15a.375.375 0 0 0 0-.75" />
		</g>
	</IconBase>
);

export default Question;
