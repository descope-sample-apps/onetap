import { IconBase, type IconComponent } from '@/components/elements/icon';

const Flexibility: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="m.857 19.695 4.286 4.286V5.124a3.429 3.429 0 1 1 6.857 0v15.428a3.428 3.428 0 1 0 6.857 0V1.695l4.286 4.286"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Flexibility;
