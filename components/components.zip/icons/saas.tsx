import { IconBase, type IconComponent } from '@/components/elements/icon';

const Saas: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M11.25 18a2.25 2.25 0 1 0 4.5 0 2.25 2.25 0 0 0-4.5 0ZM18.75 21a2.25 2.25 0 1 0 4.5 0 2.25 2.25 0 0 0-4.5 0ZM18.75 13.5a2.25 2.25 0 1 0 4.5 0 2.25 2.25 0 0 0-4.5 0ZM15.425 16.844l3.65-2.19M15.588 18.836l3.324 1.33M22.877 9a4.869 4.869 0 0 0-7.266-2.135 7.499 7.499 0 1 0-7.36 8.885" />
		</g>
	</IconBase>
);

export default Saas;
