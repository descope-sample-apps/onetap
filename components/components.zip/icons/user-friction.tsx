import { IconBase, type IconComponent } from '@/components/elements/icon';

const UserFriction: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M8 1.485v8M4 5.485l4 4 4-4M22 15h-8M18 11l-4 4 4 4M5 12h6v6H5v-6ZM2 22h17"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default UserFriction;
