import { IconBase, type IconComponent } from '@/components/elements/icon';

const Biometrics: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M15.5 10.5V14.5C15.5 14.7652 15.3946 15.0196 15.2071 15.2071C15.0196 15.3946 14.7652 15.5 14.5 15.5H10.5" />
		<path d="M10.5 0.5H14.5C14.7652 0.5 15.0196 0.605357 15.2071 0.792893C15.3946 0.98043 15.5 1.23478 15.5 1.5V5.5" />
		<path d="M0.5 5.5V1.5C0.5 1.23478 0.605357 0.98043 0.792893 0.792893C0.98043 0.605357 1.23478 0.5 1.5 0.5H5.5" />
		<path d="M5.5 15.5H1.5C1.23478 15.5 0.98043 15.3946 0.792893 15.2071C0.605357 15.0196 0.5 14.7652 0.5 14.5V10.5" />
		<path d="M12 9.25V8.25C12 5.77467 10.2 3.75 8 3.75C5.8 3.75 4 5.77467 4 8.25V12.25" />
		<path d="M12 12.25V11.25" />
		<path d="M6 11.25V12.25" />
		<path d="M10 12.25V8.75C10 7.37467 9.1 6.25 8 6.25C6.9 6.25 6 7.37467 6 8.75V9.25" />
		<path d="M8 11.75V12.25" />
		<path d="M8 8.25V9.75" />
	</IconBase>
);

export default Biometrics;
