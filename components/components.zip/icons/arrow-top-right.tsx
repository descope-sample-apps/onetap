import { IconBase, type IconComponent } from '@/components/elements/icon';

const ArrowTopRight: IconComponent = (props) => (
	<IconBase
		width="12"
		height="12"
		viewBox="0 0 12 12"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M11.625 3.74902V0.374023H8.25" />
		<path d="M11.625 0.374023L4.125 7.87402" />
		<path d="M5.625 2.62402H1.125C0.926088 2.62402 0.735322 2.70304 0.59467 2.84369C0.454018 2.98435 0.375 3.17511 0.375 3.37402V10.874C0.375 11.0729 0.454018 11.2637 0.59467 11.4044C0.735322 11.545 0.926088 11.624 1.125 11.624H8.625C8.82391 11.624 9.01468 11.545 9.15533 11.4044C9.29598 11.2637 9.375 11.0729 9.375 10.874V6.37402" />
	</IconBase>
);

export default ArrowTopRight;
