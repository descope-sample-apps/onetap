import { IconBase, type IconComponent } from '@/components/elements/icon';

const OneTap: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="m11.382 23.023-3.715-3.03a1.605 1.605 0 0 1 1.72-2.69l1.152.577v-6.615a1.47 1.47 0 0 1 2.94 0v4.41l1.953.327a2.94 2.94 0 0 1 2.457 2.9v4.123"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M19.485 14.436c3.58-5.76-.42-13.237-7.2-13.456-4.978-.161-9.1 3.833-9.096 8.813.001 1.838.58 3.628 1.657 5.118"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M16.223 12.733c2.273-3.244.181-7.73-3.764-8.077-3.946-.346-6.786 3.71-5.113 7.299.127.272.277.532.45.778"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default OneTap;
