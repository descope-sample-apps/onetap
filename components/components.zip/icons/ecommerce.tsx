import { IconBase, type IconComponent } from '@/components/elements/icon';

const ECommerce: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M6 19.126h9.921a1.5 1.5 0 0 0 1.479-1.25l2.637-15.5a1.5 1.5 0 0 1 1.479-1.247h.984"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M7.875 22.125a.375.375 0 0 1 0-.75M7.875 22.125a.375.375 0 0 0 0-.75M15.375 22.125a.375.375 0 0 1 0-.75M15.375 22.125a.375.375 0 0 0 0-.75"
			strokeWidth="1.5"
		/>
		<path
			d="M17.953 14.625H5.883a3 3 0 0 1-2.91-2.272l-1.45-5.8a.75.75 0 0 1 .727-.932h17.234M6 8.625v2.25M10.5 8.625v2.25M15 8.625v2.25"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default ECommerce;
