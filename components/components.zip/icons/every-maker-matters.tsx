import { IconBase, type IconComponent } from '@/components/elements/icon';

const EveryMakerMatters: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="m14.248 23.207-4.3-1.84V18.91s1.063-.429 1.063-3.068c.839 0 1.158-2.454-.009-2.454a3.227 3.227 0 0 0 .54-2.455c-.6-2.454-6.542-2.454-7.145 0-2.535-.527-.517 2.1-.517 2.455-1.2 0-1.2 2.454 0 2.454 0 2.64 1.159 3.068 1.159 3.068v2.455L.75 23.206" />
			<path d="M14.25 12.844v4.5l4.5-4.5h3a1.5 1.5 0 0 0 1.5-1.5v-9a1.5 1.5 0 0 0-1.5-1.5h-12a1.5 1.5 0 0 0-1.5 1.5v3" />
			<path d="M12.75 4.594 15 6.844l-2.25 2.25M18 6.844h2.25" />
		</g>
	</IconBase>
);

export default EveryMakerMatters;
