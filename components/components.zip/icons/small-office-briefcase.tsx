import { IconBase, type IconComponent } from '@/components/elements/icon';

const SmallOfficeBriefcase: IconComponent = (props) => (
	<IconBase
		width="24"
		height="25"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M18 18.998C18 19.598 17.6 19.998 17 19.998H7C6.4 19.998 6 19.598 6 18.998V11.998C6 11.398 6.4 10.998 7 10.998H17C17.6 10.998 18 11.398 18 11.998V18.998Z" />
		<path d="M6 14.998H18" />
		<path d="M12 14.998V16.498" />
		<path d="M8.70312 10.9919L9.7 8.59805C9.9 8.19805 10.2 7.99805 10.6 7.99805H13.2C13.6 7.99805 14 8.19805 14.1 8.59805L15 10.9919" />
		<path d="M22.2544 23.3984C22.7522 23.3984 23.25 22.9984 23.25 22.3984V9.89844C23.25 9.59844 23.0509 9.29845 22.8518 9.09845L12 0.898438L1.14823 9.09845C0.949117 9.29845 0.75 9.59844 0.75 9.89844V22.3984C0.75 22.8984 1.14823 23.3984 1.74558 23.3984H22.2544Z" />
	</IconBase>
);

export default SmallOfficeBriefcase;
