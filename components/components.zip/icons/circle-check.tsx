import { type IconComponent, IconBase } from '../elements/icon';

const CircleCheck: IconComponent = (props) => (
	<IconBase
		width="20"
		height="21"
		viewBox="0 0 20 21"
		fill="currentColor"
		stroke="none"
		{...props}
	>
		<path d="M14.167 3.283A8.333 8.333 0 1 1 1.67 10.77l-.004-.27.004-.27a8.333 8.333 0 0 1 12.496-6.947Zm-1.078 4.961a.833.833 0 0 0-1.1-.069l-.078.07-2.744 2.743L8.089 9.91l-.078-.07a.833.833 0 0 0-1.17 1.17l.07.078 1.666 1.667.079.069a.833.833 0 0 0 1.021 0l.079-.07 3.333-3.333.07-.078a.833.833 0 0 0-.07-1.1Z" />
	</IconBase>
);

export default CircleCheck;
