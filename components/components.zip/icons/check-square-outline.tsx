import { type IconComponent, IconBase } from '../elements/icon';

const CheckSquareOutline: IconComponent = (props) => (
	<IconBase width="17" height="17" viewBox="0 0 17 17" fill="none" {...props}>
		<g clipPath="url(#clip0_2962_172040)">
			<path
				d="M12.4129 1.07227H4.41295C2.5194 1.07227 0.984375 2.60729 0.984375 4.50084V12.5008C0.984375 14.3944 2.5194 15.9294 4.41295 15.9294H12.4129C14.3065 15.9294 15.8415 14.3944 15.8415 12.5008V4.50084C15.8415 2.60729 14.3065 1.07227 12.4129 1.07227Z"
				stroke="#9DFAFA"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
			<path
				d="M4.98438 9.64369L7.32723 11.518C7.39015 11.5698 7.46383 11.6069 7.54291 11.6267C7.62198 11.6465 7.70447 11.6484 7.78437 11.6323C7.86504 11.6171 7.9415 11.5848 8.00855 11.5375C8.07561 11.4901 8.13168 11.4289 8.17295 11.358L11.8415 5.07227"
				stroke="#9DFAFA"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
		</g>
		<defs>
			<clipPath id="clip0_2962_172040">
				<rect
					width="16"
					height="16"
					fill="white"
					transform="translate(0.414062 0.5)"
				/>
			</clipPath>
		</defs>
	</IconBase>
);

export default CheckSquareOutline;
