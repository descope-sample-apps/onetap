import { IconBase, type IconComponent } from '@/components/elements/icon';

const Localization: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M19.714 8.57c0 4.269-7.715 14.571-7.715 14.571S4.285 12.84 4.285 8.57a7.714 7.714 0 1 1 15.429 0v0Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M12 11.141a2.571 2.571 0 1 0 0-5.143 2.571 2.571 0 0 0 0 5.143Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Localization;
