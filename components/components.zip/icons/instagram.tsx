import { IconBase, type IconComponent } from '@/components/elements/icon';

const Instagram: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 20 20"
		fill="currentColor"
		stroke="none"
		{...props}
	>
		<path d="M6.5 1.667h7A4.837 4.837 0 0 1 18.333 6.5v7a4.833 4.833 0 0 1-4.833 4.833h-7A4.837 4.837 0 0 1 1.667 13.5v-7A4.833 4.833 0 0 1 6.5 1.667Zm-.167 1.666a3 3 0 0 0-3 3v7.334c0 1.658 1.342 3 3 3h7.333a3 3 0 0 0 3-3V6.333c0-1.658-1.341-3-3-3H6.333Zm8.042 1.25a1.042 1.042 0 1 1 0 2.083 1.042 1.042 0 0 1 0-2.083ZM10 5.833a4.167 4.167 0 1 1 0 8.334 4.167 4.167 0 0 1 0-8.334ZM10 7.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z" />
	</IconBase>
);

export default Instagram;
