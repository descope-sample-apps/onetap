import { IconBase, type IconComponent } from '@/components/elements/icon';

const Risk: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeLinecap="round" strokeLinejoin="round">
			<path d="M12.001 8.571v5.143" strokeWidth="1.5" />
			<path
				d="M12 19.714A.857.857 0 1 0 12 18a.857.857 0 0 0 0 1.714Z"
				fill="currentColor"
			/>
			<path
				d="M13.527 1.8a1.715 1.715 0 0 0-3.052 0L1.047 20.657a1.714 1.714 0 0 0 1.525 2.486H21.43a1.714 1.714 0 0 0 1.525-2.486L13.527 1.8Z"
				strokeWidth="1.5"
			/>
		</g>
	</IconBase>
);

export default Risk;
