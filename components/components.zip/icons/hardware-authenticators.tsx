import { IconBase, type IconComponent } from '@/components/elements/icon';

const HardwareAuthenticators: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M15.75 6.75h-7.5a1.5 1.5 0 0 0-1.5 1.5V18a5.25 5.25 0 0 0 10.5 0V8.25a1.5 1.5 0 0 0-1.5-1.5ZM8.25.75h7.5v6h-7.5v-6ZM11.25 3.75h1.5"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default HardwareAuthenticators;
