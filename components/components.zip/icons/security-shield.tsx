import { IconBase, type IconComponent } from '@/components/elements/icon';

const SecurityShield: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M12.617 23.861a1.714 1.714 0 0 1-1.234 0v0A16.405 16.405 0 0 1 .857 8.535V4.061a.874.874 0 0 1 .618-.84 36.977 36.977 0 0 1 21.051 0 .874.874 0 0 1 .617.84v4.474a16.405 16.405 0 0 1-10.526 15.326v0Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default SecurityShield;
