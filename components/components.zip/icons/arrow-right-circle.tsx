import { IconBase, type IconComponent } from '@/components/elements/icon';

const ArrowRightCircle: IconComponent = (props) => (
	<IconBase
		width="24"
		height="25"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M6.85767 12.0414H17.1434" />
		<path d="M14.572 9.46997L17.1435 12.0414L14.572 14.6128" />
		<path d="M12.0005 23.1843C18.1546 23.1843 23.1434 18.1954 23.1434 12.0414C23.1434 5.88739 18.1546 0.89856 12.0005 0.89856C5.84649 0.89856 0.857666 5.88739 0.857666 12.0414C0.857666 18.1954 5.84649 23.1843 12.0005 23.1843Z" />
	</IconBase>
);

export default ArrowRightCircle;
