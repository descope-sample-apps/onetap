import { IconBase, type IconComponent } from '@/components/elements/icon';

const ChevronUp: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M1.71387 18.2968L12.2567 7.75392C12.3337 7.67192 12.4266 7.60657 12.5298 7.56189C12.633 7.51722 12.7443 7.49417 12.8567 7.49417C12.9692 7.49417 13.0804 7.51722 13.1836 7.56189C13.2868 7.60657 13.3798 7.67192 13.4567 7.75392L23.9996 18.2968" />
	</IconBase>
);

export default ChevronUp;
