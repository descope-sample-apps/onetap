import { IconBase, type IconComponent } from '@/components/elements/icon';

const BotAttaks: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M21.76 10.5V2.255a1.5 1.5 0 0 0-1.5-1.5h-18a1.5 1.5 0 0 0-1.5 1.5v16.5a1.5 1.5 0 0 0 1.5 1.5h6M.76 5.254h21"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M21.261 15.637a5.63 5.63 0 0 0-10.027-3.524 5.63 5.63 0 0 0 .498 7.58v2.008a1.3 1.3 0 0 0 2.6 0 1.3 1.3 0 0 0 2.598 0 1.3 1.3 0 0 0 2.599 0v-2.007a5.61 5.61 0 0 0 1.732-4.057Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M12.5 15.337a1 1 0 1 0 2 0 1 1 0 0 0-2 0ZM16.93 15.337a1 1 0 1 0 2 0 1 1 0 0 0-2 0Z"
			fill="currentColor"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default BotAttaks;
