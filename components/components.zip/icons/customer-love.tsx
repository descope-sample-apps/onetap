import { IconBase, type IconComponent } from '@/components/elements/icon';

const CustomerLove: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M.857 14.571h3.429a4.286 4.286 0 0 1 4.286 4.286" />
			<path d="M3.429 18.857H12a3.428 3.428 0 0 1 3.429 3.428.858.858 0 0 1-.857.857H.857M15 14.572 8.143 8.229C4.406 4.474 9.857-2.794 15 3.086c5.143-5.863 10.646 1.406 6.858 5.143L15 14.572Z" />
		</g>
	</IconBase>
);

export default CustomerLove;
