import { IconBase, type IconComponent } from '@/components/elements/icon';

const API: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M16.695 13.716A5.277 5.277 0 0 0 22.06 8.53a5.278 5.278 0 0 0-5.366-5.186c-.455 0-.907.055-1.348.165A4.934 4.934 0 0 0 10.883.75a4.855 4.855 0 0 0-4.9 4.342 4.382 4.382 0 0 0-4.044 4.3 4.4 4.4 0 0 0 4.471 4.321l10.285.002ZM20.245 23.25v-6.533M18.939 16.717h2.613M18.939 23.25h2.613M11.097 23.25v-2.613M11.1 20.637h1.96a1.96 1.96 0 1 0 0-3.92H11.1v3.92ZM1.95 23.25l.736-4.919a1.9 1.9 0 0 1 3.752 0l.738 4.92M2.292 20.963h4.541"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default API;
