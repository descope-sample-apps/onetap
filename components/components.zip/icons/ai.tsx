import { IconBase, type IconComponent } from '@/components/elements/icon';

const AI: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M15.5 23.25v-3.74l1.007.168A3 3 0 0 0 20 16.718V14.26l.935-.234a1.5 1.5 0 0 0 .884-2.287L20 9.01v-.75C20 3.834 15.521.3 10.182.8A8.994 8.994 0 0 0 6.5 17.545v5.7"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M13.786 7.785H9.5a.714.714 0 0 0-.714.715v4.285c0 .395.32.715.714.715h4.286c.395 0 .714-.32.714-.715V8.5a.714.714 0 0 0-.714-.715ZM10.214 7.786V6M13.072 7.786V6M8.786 12.071H7M8.786 9.214H7M13.072 13.5v1.786M10.214 13.5v1.786M14.5 9.214h1.786M14.5 12.071h1.786"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default AI;
