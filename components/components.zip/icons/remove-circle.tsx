import { IconBase, type IconComponent } from '@/components/elements/icon';

const RemoveCircle: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 17"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M.5 8.499a7.5 7.5 0 1 0 15 0 7.5 7.5 0 0 0-15 0ZM5 11.499l6-6M11 11.499l-6-6" />
	</IconBase>
);

export default RemoveCircle;
