import { IconBase, type IconComponent } from '@/components/elements/icon';

const ChevronRight: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M4.40234 0.572266L11.4309 7.60084C11.4856 7.65214 11.5291 7.7141 11.5589 7.7829C11.5887 7.8517 11.6041 7.92587 11.6041 8.00084C11.6041 8.0758 11.5887 8.14998 11.5589 8.21877C11.5291 8.28757 11.4856 8.34953 11.4309 8.40084L4.40234 15.4294"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default ChevronRight;
