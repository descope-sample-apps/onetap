import { IconBase, type IconComponent } from '@/components/elements/icon';

const Success: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M11.778 16.286a7.714 7.714 0 1 0 0-15.429 7.714 7.714 0 0 0 0 15.429Z" />
			<path d="M11.778 12a3.429 3.429 0 1 0 0-6.857 3.429 3.429 0 0 0 0 6.857ZM10.287 16.149l-1.509 6.343a.874.874 0 0 1-.445.566.927.927 0 0 1-.738 0l-5.691-2.486a.873.873 0 0 1-.309-1.337l4.406-5.52M13.715 16.064l1.543 6.429a.858.858 0 0 0 .463.566.874.874 0 0 0 .72 0l5.657-2.486a.856.856 0 0 0 .48-.6.823.823 0 0 0-.172-.737l-4.594-5.846" />
		</g>
	</IconBase>
);

export default Success;
