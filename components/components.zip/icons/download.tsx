import { IconBase, type IconComponent } from '@/components/elements/icon';

const Download: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M1.35718 18.6487V20.363C1.35718 21.2723 1.7184 22.1444 2.36138 22.7873C3.00436 23.4303 3.87644 23.7915 4.78575 23.7915H20.2143C21.1236 23.7915 21.9957 23.4303 22.6387 22.7873C23.2817 22.1444 23.6429 21.2723 23.6429 20.363V18.6487" />
		<path d="M7.35718 10.9343L12.5 16.9343L17.6429 10.9343" />
		<path d="M12.5 16.9344V1.50586" />
	</IconBase>
);

export default Download;
