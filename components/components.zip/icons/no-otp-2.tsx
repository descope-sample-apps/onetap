import { IconBase, type IconComponent } from '@/components/elements/icon';

const NoOtp2: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M5.143.857H2.572A1.714 1.714 0 0 0 .857 2.572v2.571M18.857.857h2.572a1.714 1.714 0 0 1 1.714 1.715v2.571M5.143 23.143H2.572A1.714 1.714 0 0 1 .857 21.43v-2.572M18.857 23.143h2.572a1.714 1.714 0 0 0 1.714-1.714v-2.572M5.23 15.328v1.377h1.377v2.066M5 5h5.508v5.508H5V5ZM15.328 5h2.066M13.263 5v2.754h2.065M18.541 7.754v2.754h-4.13M5 13.262h5.508v2.984M9.13 19h1.378M17.394 19h1.377M13.262 15.787V19h1.377M18.999 19v-5.508M13.262 13.262h2.754v1.377" />
		</g>
	</IconBase>
);

export default NoOtp2;
