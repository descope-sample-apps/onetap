import { IconBase, type IconComponent } from '@/components/elements/icon';

const InterfaceSettingToolBox: IconComponent = (props) => (
	<IconBase
		width="25"
		height="24"
		viewBox="0 0 25 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M22.1969 7.71399H3.33977C2.393 7.71399 1.62549 8.4815 1.62549 9.42827V21.4283C1.62549 22.375 2.393 23.1426 3.33977 23.1426H22.1969C23.1437 23.1426 23.9112 22.375 23.9112 21.4283V9.42827C23.9112 8.4815 23.1437 7.71399 22.1969 7.71399Z" />
		<path d="M1.62549 14.5712H23.9112" />
		<path d="M12.7683 12.8569V16.2855" />
		<path d="M17.9112 7.71402C17.9112 6.35005 17.3694 5.04195 16.4049 4.07748C15.4404 3.113 14.1323 2.57117 12.7683 2.57117V2.57117C11.4044 2.57117 10.0963 3.113 9.1318 4.07748C8.16732 5.04195 7.62549 6.35005 7.62549 7.71402" />
	</IconBase>
);

export default InterfaceSettingToolBox;
