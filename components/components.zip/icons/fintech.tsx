import { IconBase, type IconComponent } from '@/components/elements/icon';

const FinTech: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g
			strokeWidth="1.5"
			strokeMiterlimit="10"
			strokeLinecap="round"
			strokeLinejoin="round"
		>
			<path d="M7.75 14.25a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM11.75 9.75a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM11.75 9.75v8M15.75 14.25a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z" />
			<path d="M20.25 18.75c0 1.1-.9 2-2 2h-13c-1.1 0-2-.9-2-2v-13c0-1.1.9-2 2-2h13c1.1 0 2 .9 2 2v13ZM.75 5.25h2.563M.75 9.75h2.5M.75 14.25h2.5M20.25 9.75h3M20.25 14.25h3M.75 18.75h2.5M23.25 5.25h-3.064M23.25 18.75h-3M15.75 14.25v3.5M7.75 14.25v3.5M18.75 23.25v-2.563M14.25 23.25v-2.5M9.75 23.25v-2.5M14.25 3.75v-3M9.75 3.75v-3M5.25 23.25v-2.5M18.75.75v3.063M5.25.75v3" />
		</g>
	</IconBase>
);

export default FinTech;
