import { IconBase, type IconComponent } from '@/components/elements/icon';

const Money: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M18.75 4.5H2.25A1.5 1.5 0 0 0 .75 6v9a1.5 1.5 0 0 0 1.5 1.5h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M4.125 8.25a.375.375 0 1 1 0-.75M4.125 8.25a.375.375 0 1 0 0-.75M16.875 13.5a.375.375 0 0 1 0-.75M16.875 13.5a.375.375 0 0 0 0-.75"
			strokeWidth="1.5"
		/>
		<path
			d="M10.5 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM23.25 9v9a1.5 1.5 0 0 1-1.5 1.5H5.25"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Money;
