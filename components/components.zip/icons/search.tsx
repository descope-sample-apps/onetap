import { IconBase, type IconComponent } from '@/components/elements/icon';

const Search: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M11.0053 20.3386C16.1368 20.3386 20.2967 16.1787 20.2967 11.0472C20.2967 5.91565 16.1368 1.75574 11.0053 1.75574C5.87378 1.75574 1.71387 5.91565 1.71387 11.0472C1.71387 16.1787 5.87378 20.3386 11.0053 20.3386Z" />
		<path d="M23.9999 24.0415L17.5713 17.6129" />
	</IconBase>
);

export default Search;
