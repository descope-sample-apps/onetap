import { IconBase, type IconComponent } from '@/components/elements/icon';

const Check: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M1.71387 15.5565L6.39387 21.5737C6.55179 21.7788 6.75414 21.9456 6.98572 22.0614C7.2173 22.1772 7.47211 22.239 7.73101 22.2422C7.98574 22.2452 8.23793 22.1913 8.46923 22.0846C8.70053 21.9778 8.90513 21.8208 9.06815 21.6251L23.9996 3.55652" />
	</IconBase>
);

export default Check;
