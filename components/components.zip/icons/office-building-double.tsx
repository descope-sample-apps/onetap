import { IconBase, type IconComponent } from '@/components/elements/icon';

const OfficeBuildingDouble: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M23.5 23.2504H1" />
		<path d="M1 23.2504V1.75037C1 1.15037 1.4 0.750366 2 0.750366H16C16.6 0.750366 17 1.15037 17 1.75037V23.2504" />
		<path d="M17 10.2504H22.5C23.1 10.2504 23.5 10.6504 23.5 11.2504V23.2504" />
		<path d="M7.25 3.75037H4.25V7.75037H7.25V3.75037Z" />
		<path d="M13.75 3.75037H10.75V7.75037H13.75V3.75037Z" />
		<path d="M7.25 11.2504H4.25V15.2504H7.25V11.2504Z" />
		<path d="M13.75 11.2504H10.75V15.2504H13.75V11.2504Z" />
		<path d="M7.2002 23.2508V19.9508C7.2002 18.9508 8.0002 18.1508 9.0002 18.1508C10.0002 18.1508 10.8002 18.9508 10.8002 19.9508V23.2508" />
	</IconBase>
);

export default OfficeBuildingDouble;
