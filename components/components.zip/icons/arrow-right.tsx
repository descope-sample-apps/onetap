import { IconBase, type IconComponent } from '@/components/elements/icon';

const ArrowRight: IconComponent = (props) => (
	<IconBase
		width="16"
		height="17"
		viewBox="0 0 16 17"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M0.572266 8.50098H15.4294" />
		<path d="M11.4297 12.501L15.4297 8.50098L11.4297 4.50098" />
	</IconBase>
);

export default ArrowRight;
