import { IconBase, type IconComponent } from '../elements/icon';

const StepUp: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M23.1422 1.13647H15.4279V8.85076H8.57073V15.7079H0.856445V23.4222H23.1422V1.13647Z" />
	</IconBase>
);

export default StepUp;
