import { IconBase, type IconComponent } from '@/components/elements/icon';

const IdeaBulb: IconComponent = (props) => (
	<IconBase
		width="24"
		height="25"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M18.5 11.2461C18.5 7.64609 15.6 4.74609 12 4.74609C8.4 4.74609 5.5 7.64609 5.5 11.2461C5.5 13.0461 6.2 14.5461 7.3 15.7461C8.4 16.8461 9 18.346 9 19.846V20.046C9 21.346 10.1 22.346 11.3 22.346H12.5C13.8 22.346 14.8 21.246 14.8 20.046V19.846C14.8 18.346 15.4 16.8461 16.5 15.7461C17.8 14.5461 18.5 12.9461 18.5 11.2461Z" />
		<path d="M12.0996 22.3477V23.5478" />
		<path d="M9.09961 18.1465H14.9996" />
		<path d="M21 11.0469H22" />
		<path d="M12.0996 2.04688V1.04688" />
		<path d="M5.7 4.44607L5 3.74609" />
		<path d="M3 11.0469H2" />
		<path d="M18.5 4.44607L19.2 3.74609" />
		<path d="M10.5 10.2461L9 11.7461L10.5 13.2461" />
		<path d="M13.5 10.2461L15 11.7461L13.5 13.2461" />
	</IconBase>
);

export default IdeaBulb;
