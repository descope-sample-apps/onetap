import { IconBase, type IconComponent } from '@/components/elements/icon';

const Server: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5">
			<path
				d="M12.001 9.75h1.5M16.501 9.75h3M23.251 9.75a4.5 4.5 0 0 1-4.5 4.5h-13.5a4.5 4.5 0 1 1 0-9h13.5a4.5 4.5 0 0 1 4.5 4.5ZM12.001 18.75h1.5M16.501 18.75h3"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
			<path
				d="M23.251 18.75a4.5 4.5 0 0 1-4.5 4.5h-13.5a4.5 4.5 0 1 1 0-9h13.5a4.5 4.5 0 0 1 4.5 4.5Z"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
			<path d="M5.625 19.125a.375.375 0 1 1 0-.75M5.625 19.125a.375.375 0 1 0 0-.75M5.625 10.125a.375.375 0 1 1 0-.75M5.625 10.125a.375.375 0 1 0 0-.75" />
			<path
				d="M22.827 7.843 20.31 2.476A3 3 0 0 0 17.594.75H6.408A3 3 0 0 0 3.69 2.476L1.175 7.843"
				strokeLinecap="round"
				strokeLinejoin="round"
			/>
		</g>
	</IconBase>
);

export default Server;
