import StartupProductRocketBox from './startup-product-rocket-box';
import Growth from './growth';
import ChartIncrease from './chart-increase';
import OfficeBuildingDouble from './office-building-double';
import ArrowRight from './arrow-right';
import Search from './search';
import User from './user';
import Group from './group';
import X from './x';
import LinkedIn from './linkedin';
import Github from './github';
import AlertTriangle from './alert-triangle';
import ChevronDown from './chevron-down';
import ChevronUp from './chevron-up';
import ChevronRight from './chevron-right';
import Check from './check';
import CheckTick from './check-tick';
import CaretDown from './caret-down';
import LayoutDashboard from './layout-dashboard';
import Flows from './flows';
import Integrations from './integrations';
import FileText from './file-text';
import ArrowTopRight from './arrow-top-right';
import Biometrics from './biometrics';
import Login from './login';
import MagicLinks from './magic-links';
import MFA from './mfa';
import Passkeys from './passkeys';
import Key from './key';
import Authorization from './authorization';
import WhatsappIcon from './whatsapp-icon';
import OneTimePassword from './one-time-password';
import AuthorizationEye from './authorization-eye';
import Password from './password';
import BookOpen from './book-open';
import CodeApp from './code-app';
import GithubIcon from './github-icon';
import Users from './users';
import VideoPlayerSlider from './video-player-slider';
import MessageBubble from './message-bubble';
import NotificationBell from './notification-bell';
import BookOpenBookmark from './book-open-bookmark';
import NotesBook from './notes-book';
import GuardLock from './guard-lock';
import UserCircle from './user-circle';
import Menu from './menu';
import Close from './close';
import SSO from './sso';
import IdeaBulb from './idea-bulb';
import BuildInPublic from './build-in-public';
import FineGrainedAuthorization from './fine-grained-authorization';
import Workflow from './workflow';
import ArrowRightCircle from './arrow-right-circle';
import Instagram from './instagram';
import Slack from './slack';
import UserManagement from './user-management';
import OtpEmail from './otp-email';
import Sdk from './sdk';
import UserEdit from './user-edit';
import Tenants from './tenants';
import StepUp from './step-up';
import InfoCircle from './info-circle';
import Speed from './speed';
import SecurityShield from './security-shield';
import Flexibility from './flexibility';
import RemoveCircle from './remove-circle';
import ArrowLeft from './arrow-left';
import CircleCheck from './circle-check';
import Hyperlink from './hyperlink';
import Tick from './tick';
import SavingPiggyCoins from './saving-piggy-coins';
import InterfaceSettingToolBox from './interface-setting-tool';
import Cross from './cross';
import SmallOfficeBriefcase from './small-office-briefcase';
import TimeBasedOTP from './time-based-otp';
import Widgets from './widgets';
import WrenchDouble from './wrench-double';
import Download from './download';
import AccountTakeover from './account-takeover';
import UX from './ux';
import EveryMakerMatters from './every-maker-matters';
import NoOtp2 from './no-otp-2';
import API from './api';
import Client from './client';
import HardwareAuthenticators from './hardware-authenticators';
import Server from './server';
import ECommerce from './ecommerce';
import Phishing from './phishing';
import Risk from './risk';
import Data from './data';
import CredentialStuffing from './credential-stuffing';
import Money from './money';
import Success from './success';
import UserFriction from './user-friction';
import Question from './question';
import Security from './security';
import OneTap from './one-tap';
import RoleBasedAccessControl from './role-based-access-control';
import Conversion from './conversion';
import MultiTenancy from './multi-tenancy';
import BotAttaks from './bot-attaks';
import GlobalReach from './global-reach';
import CustomerLove from './customer-love';
import FinTech from './fintech';
import Banking from './banking';
import Saas from './saas';
import AI from './ai';
import Applications from './applications';
import Localization from './localization';
import Support from './support';
import Migration from './migration';
import BlueskySocial from './bluesky';
import CheckSquareOutline from './check-square-outline';

/*
	Adding an icon in this registry should require you to also
	add it on Contentful following these steps:
	- Go to edit the 'Block' Content Type on Contentful
	- Select 'Edit' next to the 'Icon Name' field
	- Scroll down and add the new icon name in the 'Accept only specified values' field
	- Save the changes
*/
export const iconsRegistry = {
	AccountTakeover: {
		title: 'Account Takeover',
		component: AccountTakeover
	},
	AI: {
		title: 'AI',
		component: AI
	},
	AlertTriangle: {
		title: 'Alert Triangle',
		component: AlertTriangle
	},
	API: {
		title: 'API',
		component: API
	},
	Applications: {
		title: 'Applications',
		component: Applications
	},
	ArrowLeft: {
		title: 'Arrow Left',
		component: ArrowLeft
	},
	ArrowRight: {
		title: 'Arrow Right',
		component: ArrowRight
	},
	ArrowRightCircle: {
		title: 'Arrow Right Circle',
		component: ArrowRightCircle
	},
	ArrowTopRight: {
		title: 'Arrow Top Right',
		component: ArrowTopRight
	},
	Authorization: {
		title: 'Authorization',
		component: Authorization
	},
	AuthorizationEye: {
		title: 'Authorization Eye',
		component: AuthorizationEye
	},
	Banking: {
		title: 'Banking',
		component: Banking
	},
	Biometrics: {
		title: 'Biometrics',
		component: Biometrics
	},
	BotAttaks: {
		title: 'Bot Attaks',
		component: BotAttaks
	},
	BookOpen: {
		title: 'Book Open',
		component: BookOpen
	},
	BookOpenBookmark: {
		title: 'Book Open Bookmark',
		component: BookOpenBookmark
	},
	BuildInPublic: {
		title: 'Build In Public',
		component: BuildInPublic
	},
	CaretDown: {
		title: 'Caret Down',
		component: CaretDown
	},
	ChartIncrease: {
		title: 'StartupProductRocketBox',
		component: ChartIncrease
	},
	Check: {
		title: 'Check',
		component: Check
	},
	CheckTick: {
		title: 'CheckTick',
		component: CheckTick
	},
	ChevronDown: {
		title: 'Chevron Down',
		component: ChevronDown
	},
	ChevronUp: {
		title: 'Chevron Up',
		component: ChevronUp
	},
	ChevronRight: {
		title: 'Chevron Right',
		component: ChevronRight
	},
	CircleCheck: {
		title: 'Circle Check',
		component: CircleCheck
	},
	Client: {
		title: 'Client',
		component: Client
	},
	Close: {
		title: 'Close',
		component: Close
	},
	CodeApp: {
		title: 'Code App',
		component: CodeApp
	},
	Conversion: {
		title: 'Conversion',
		component: Conversion
	},
	CredentialStuffing: {
		title: 'Credential Stuffing',
		component: CredentialStuffing
	},
	Cross: {
		title: 'Cross',
		component: Cross
	},
	CustomerLove: {
		title: 'Customer Love',
		component: CustomerLove
	},
	Data: {
		title: 'Data',
		component: Data
	},
	Download: {
		title: 'Download',
		component: Download
	},
	ECommerce: {
		title: 'ECommerce',
		component: ECommerce
	},
	EveryMakerMatters: {
		title: 'Every Maker Matters',
		component: EveryMakerMatters
	},
	FileText: {
		title: 'File Text',
		component: FileText
	},
	FineGrainedAuthorization: {
		title: 'Fine Grained Authorization',
		component: FineGrainedAuthorization
	},
	FinTech: {
		title: 'FinTech',
		component: FinTech
	},
	Flexibility: {
		title: 'Flexibility',
		component: Flexibility
	},
	Flows: {
		title: 'Flows',
		component: Flows
	},
	Github: {
		title: 'Github',
		component: Github
	},
	GithubIcon: {
		title: 'Github Icon',
		component: GithubIcon
	},
	GlobalReach: {
		title: 'Global Reach',
		component: GlobalReach
	},
	Group: {
		title: 'Group',
		component: Group
	},
	Growth: {
		title: 'StartupProductRocketBox',
		component: Growth
	},
	GuardLock: {
		title: 'Guard Lock',
		component: GuardLock
	},
	HardwareAuthenticators: {
		title: 'Hardware Authenticators',
		component: HardwareAuthenticators
	},
	Hyperlink: {
		title: 'Hyperlink',
		component: Hyperlink
	},
	IdeaBulb: {
		title: 'Idea Bulb',
		component: IdeaBulb
	},
	InfoCircle: {
		title: 'InfoCircle',
		component: InfoCircle
	},
	Instagram: {
		title: 'Instagram',
		component: Instagram
	},
	Integrations: {
		title: 'Integrations',
		component: Integrations
	},
	InterfaceSettingToolBox: {
		title: 'InterfaceSettingToolBox',
		component: InterfaceSettingToolBox
	},
	Key: {
		title: 'Key',
		component: Key
	},
	LayoutDashboard: {
		title: 'Layout Dashboard',
		component: LayoutDashboard
	},
	LinkedIn: {
		title: 'LinkedIn',
		component: LinkedIn
	},
	Localization: {
		title: 'Localization',
		component: Localization
	},
	Login: {
		title: 'Login',
		component: Login
	},
	MFA: {
		title: 'MFA',
		component: MFA
	},
	MagicLinks: {
		title: 'Magic Links',
		component: MagicLinks
	},
	Menu: {
		title: 'Menu',
		component: Menu
	},
	MessageBubble: {
		title: 'Message Bubble',
		component: MessageBubble
	},
	Migration: {
		title: 'Migration',
		component: Migration
	},
	Money: {
		title: 'Money',
		component: Money
	},
	MultiTenancy: {
		title: 'Multi-tenancy',
		component: MultiTenancy
	},
	NoOtp2: {
		title: 'No Otp 2',
		component: NoOtp2
	},
	NotesBook: {
		title: 'Notes Book',
		component: NotesBook
	},
	NotificationBell: {
		title: 'Notification Bell',
		component: NotificationBell
	},
	OfficeBuildingDouble: {
		title: 'OfficeBuildingDouble',
		component: OfficeBuildingDouble
	},
	OneTap: {
		title: 'One Tap',
		component: OneTap
	},
	OneTimePassword: {
		title: 'One Time Password',
		component: OneTimePassword
	},
	OtpEmail: {
		title: 'Otp Email',
		component: OtpEmail
	},
	Passkeys: {
		title: 'Passkeys',
		component: Passkeys
	},
	Password: {
		title: 'Password',
		component: Password
	},
	Phishing: {
		title: 'Phishing',
		component: Phishing
	},
	RemoveCircle: {
		title: 'Remove Circle',
		component: RemoveCircle
	},
	Risk: {
		title: 'Risk',
		component: Risk
	},
	RoleBasedAccessControl: {
		title: 'Role-Based Access Control',
		component: RoleBasedAccessControl
	},
	SSO: {
		title: 'SSO',
		component: SSO
	},
	Saas: {
		title: 'Saas',
		component: Saas
	},
	SavingPiggyCoins: {
		title: 'SavingPiggyCoins',
		component: SavingPiggyCoins
	},
	Sdk: {
		title: 'Sdk',
		component: Sdk
	},
	Search: {
		title: 'Search',
		component: Search
	},
	Security: {
		title: 'Security',
		component: Security
	},
	SecurityShield: {
		title: 'Security Shield',
		component: SecurityShield
	},
	Server: {
		title: 'Server',
		component: Server
	},
	Slack: {
		title: 'Slack',
		component: Slack
	},
	SmallOfficeBriefcase: {
		title: 'Small Office Briefcase',
		component: SmallOfficeBriefcase
	},
	Speed: {
		title: 'Speed',
		component: Speed
	},
	StartupProductRocketBox: {
		title: 'StartupProductRocketBox',
		component: StartupProductRocketBox
	},
	StepUp: {
		title: 'StepUp',
		component: StepUp
	},
	Success: {
		title: 'Success',
		component: Success
	},
	Support: {
		title: 'Support',
		component: Support
	},
	Tenants: {
		title: 'Tenants',
		component: Tenants
	},
	Tick: {
		title: 'Tick',
		component: Tick
	},
	TimeBasedOTP: {
		title: 'Time Based OTP',
		component: TimeBasedOTP
	},
	User: {
		title: 'User',
		component: User
	},
	UserCircle: {
		title: 'User Circle',
		component: UserCircle
	},
	UserEdit: {
		title: 'User Edit',
		component: UserEdit
	},
	UserFriction: {
		title: 'User Friction',
		component: UserFriction
	},
	UserManagement: {
		title: 'User Management',
		component: UserManagement
	},
	Users: {
		title: 'Users',
		component: Users
	},
	UX: {
		title: 'UX',
		component: UX
	},
	Question: {
		title: 'Question',
		component: Question
	},
	VideoPlayerSlider: {
		title: 'Video Player Slider',
		component: VideoPlayerSlider
	},
	WhatsappIcon: {
		title: 'Whatsapp Icon',
		component: WhatsappIcon
	},
	Widgets: {
		title: 'Widgets',
		component: Widgets
	},
	Workflow: {
		title: 'Workflow',
		component: Workflow
	},
	WrenchDouble: {
		title: 'Wrench Double',
		component: WrenchDouble
	},
	X: {
		title: 'X',
		component: X
	},
	Bluesky: {
		title: 'Bluesky Social',
		component: BlueskySocial
	},
	CheckSquareOutline: {
		title: 'Check Square Outline',
		component: CheckSquareOutline
	}
};
