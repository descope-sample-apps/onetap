import { IconBase, type IconComponent } from '@/components/elements/icon';

const Menu: IconComponent = (props) => (
	<IconBase
		width="20"
		height="20"
		viewBox="0 0 20 20"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M19.2858 2.85742H0.714355" />
		<path d="M19.2858 10H0.714355" />
		<path d="M19.2858 17.1426H0.714355" />
	</IconBase>
);

export default Menu;
