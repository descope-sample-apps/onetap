import { IconBase, type IconComponent } from '@/components/elements/icon';

const Speed: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M.857 18.477a1.2 1.2 0 0 0 .635 1.063 1.217 1.217 0 0 0 1.251 0l8.709-5.657a1.2 1.2 0 0 0 0-2.023L2.743 6.168a1.217 1.217 0 0 0-1.251 0 1.2 1.2 0 0 0-.635 1.063v11.246Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M12 18.477a1.201 1.201 0 0 0 .635 1.063 1.217 1.217 0 0 0 1.251 0l8.709-5.657a1.2 1.2 0 0 0 0-2.023l-8.709-5.692a1.217 1.217 0 0 0-1.251 0A1.2 1.2 0 0 0 12 7.197v11.28Z"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Speed;
