import { IconBase, type IconComponent } from '@/components/elements/icon';

const User: IconComponent = (props) => (
	<IconBase
		width="24"
		height="25"
		viewBox="0 0 24 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M12.0001 12.6116C15.0772 12.6116 17.5716 10.1172 17.5716 7.04018C17.5716 3.96316 15.0772 1.46875 12.0001 1.46875C8.92312 1.46875 6.42871 3.96316 6.42871 7.04018C6.42871 10.1172 8.92312 12.6116 12.0001 12.6116Z" />
		<path d="M22.5948 23.7551C21.8751 21.5108 20.4613 19.5531 18.5573 18.1642C16.6533 16.7752 14.3573 16.0268 12.0005 16.0268C9.64373 16.0268 7.3478 16.7752 5.44376 18.1642C3.53972 19.5531 2.12595 21.5108 1.40625 23.7551H22.5948Z" />
	</IconBase>
);

export default User;
