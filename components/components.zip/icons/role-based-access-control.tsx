import { IconBase, type IconComponent } from '@/components/elements/icon';

const RoleBasedAccessControl: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M11.25 15.75h3v4.5l4.5-4.5h3a1.5 1.5 0 0 0 1.5-1.5v-12a1.5 1.5 0 0 0-1.5-1.5h-12a1.5 1.5 0 0 0-1.5 1.5M1.5 6.75a3 3 0 1 0 6 0 3 3 0 0 0-6 0Z" />
			<path d="m18.287 5.576-2.9 3.874a.75.75 0 0 1-1.13.08l-1.5-1.5M8.25 17.25V15a3.75 3.75 0 0 0-7.5 0v2.25h1.5l.75 6h3l.75-6h1.5Z" />
		</g>
	</IconBase>
);

export default RoleBasedAccessControl;
