import { IconBase, type IconComponent } from '@/components/elements/icon';

const NotesBook: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M3 0.5H13C13 0.5 14 0.5 14 1.5V14.5C14 14.5 14 15.5 13 15.5H3C3 15.5 2 15.5 2 14.5V1.5C2 1.5 2 0.5 3 0.5Z" />
		<path d="M5 0.5V15.5" />
		<path d="M12 4.5C12 4.76522 11.8946 5.01957 11.7071 5.20711C11.5196 5.39464 11.2652 5.5 11 5.5H8C7.73478 5.5 7.48043 5.39464 7.29289 5.20711C7.10536 5.01957 7 4.76522 7 4.5C7 4.23478 7.10536 3.98043 7.29289 3.79289C7.48043 3.60536 7.73478 3.5 8 3.5H11C11.2652 3.5 11.5196 3.60536 11.7071 3.79289C11.8946 3.98043 12 4.23478 12 4.5Z" />
	</IconBase>
);

export default NotesBook;
