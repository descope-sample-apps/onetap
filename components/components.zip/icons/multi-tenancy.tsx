import { IconBase, type IconComponent } from '@/components/elements/icon';

const MultiTenancy: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M12 6.858a2.571 2.571 0 1 0 0-5.143 2.571 2.571 0 0 0 0 5.143ZM3.429 22.287a2.571 2.571 0 1 0 0-5.143 2.571 2.571 0 0 0 0 5.143ZM12 22.287a2.571 2.571 0 1 0 0-5.143 2.571 2.571 0 0 0 0 5.143ZM20.571 22.287a2.571 2.571 0 1 0 0-5.143 2.571 2.571 0 0 0 0 5.143ZM3.429 17.144v-3.429a1.714 1.714 0 0 1 1.714-1.714h13.714a1.714 1.714 0 0 1 1.715 1.714v3.429M12 6.858v10.286" />
		</g>
	</IconBase>
);

export default MultiTenancy;
