import { IconBase, type IconComponent } from '@/components/elements/icon';

const MagicLinks: IconComponent = (props) => (
	<IconBase
		width="16"
		height="16"
		viewBox="0 0 16 16"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M12.8333 15.5H3.16667C1.7 15.5 0.5 14.3 0.5 12.8333V3.16667C0.5 1.7 1.7 0.5 3.16667 0.5H12.8333C14.3 0.5 15.5 1.7 15.5 3.16667V12.8333C15.5 14.3 14.3 15.5 12.8333 15.5Z" />
		<path d="M2.9 8.23333C2.63333 7.83333 2.5 7.43333 2.5 6.9C2.5 5.56667 3.56667 4.5 4.9 4.5H8.7C10.0333 4.5 11.1 5.56667 11.1 6.9C11.1 8.23333 10.0333 9.3 8.7 9.3H6.3" />
		<path d="M12.7 8.03298C12.9667 8.43298 13.1 8.89964 13.1 9.36631C13.1 10.6996 12.0333 11.7663 10.7 11.7663H6.9C5.56667 11.7663 4.5 10.6996 4.5 9.36631C4.5 8.03298 5.56667 6.96631 6.9 6.96631H9.3" />
	</IconBase>
);

export default MagicLinks;
