import { IconBase, type IconComponent } from '../elements/icon';

const Group: IconComponent = (props) => (
	<IconBase
		width="25"
		height="25"
		viewBox="0 0 25 25"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M12.807 11.828a2.023 2.023 0 0 1-1.611 0L1.424 7.302a.96.96 0 0 1 0-1.714l9.772-4.56a2.023 2.023 0 0 1 1.611 0l9.771 4.525a.96.96 0 0 1 0 1.715l-9.771 4.56ZM23.143 12.599l-10.457 4.817a1.714 1.714 0 0 1-1.423 0L.857 12.6M23.143 18.17l-10.457 4.818a1.715 1.715 0 0 1-1.423 0L.857 18.17" />
	</IconBase>
);

export default Group;
