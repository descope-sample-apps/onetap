import { IconBase, type IconComponent } from '@/components/elements/icon';

const Applications: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path
			d="M8.75 6.5V22M4 10.75h1.5M4 14.25h1.5M4 17.75h1.5M12.75 10h6.5s.75 0 .75.75v7s0 .75-.75.75h-6.5s-.75 0-.75-.75v-7s0-.75.75-.75ZM12 14h8M16 14v4.5"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
		<path
			d="M2.25 2h19.5s1.5 0 1.5 1.5v17s0 1.5-1.5 1.5H2.25s-1.5 0-1.5-1.5v-17S.75 2 2.25 2ZM.75 6.5h22.5"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
		/>
	</IconBase>
);

export default Applications;
