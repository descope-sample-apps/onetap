import { IconBase, type IconComponent } from '../elements/icon';

const X: IconComponent = (props) => (
	<IconBase width="20" height="20" viewBox="0 0 20 20" fill="none" {...props}>
		<path
			d="M0.0463715 0.49826L7.49108 10.4649L-0.000640869 18.5683H1.68545L8.24444 11.4737L13.544 18.5683H19.2818L11.4182 8.04098L18.3914 0.49826H16.7054L10.6648 7.03224L5.78419 0.49826H0.0463715ZM2.52589 1.74178H5.16185L16.8019 17.3246H14.1659L2.52589 1.74178Z"
			fill="currentColor"
		/>
	</IconBase>
);

export default X;
