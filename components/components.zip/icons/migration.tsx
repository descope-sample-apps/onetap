import { IconBase, type IconComponent } from '@/components/elements/icon';

const Migration: IconComponent = (props) => (
	<IconBase
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<g strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
			<path d="M8.25 23.25v-10.5M19.57 15.6a4.876 4.876 0 1 0-3.959-8.737 7.501 7.501 0 1 0-12.6 6.749" />
			<path d="m11.25 15.75-3-3-3 3M15.75 12.75v10.5M12.75 20.25l3 3 3-3" />
		</g>
	</IconBase>
);

export default Migration;
