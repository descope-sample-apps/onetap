import { IconBase, type IconComponent } from '@/components/elements/icon';

const InfoCircle: IconComponent = (props) => (
	<IconBase
		width="20"
		height="21"
		viewBox="0 0 20 21"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M10.0003 19.4353C15.1287 19.4353 19.286 15.278 19.286 10.1496C19.286 5.02125 15.1287 0.863892 10.0003 0.863892C4.87196 0.863892 0.7146 5.02125 0.7146 10.1496C0.7146 15.278 4.87196 19.4353 10.0003 19.4353Z" />
		<path d="M10.0002 10.1495V15.1495" />
		<path d="M10.0002 7.29246C10.3947 7.29246 10.7145 6.97267 10.7145 6.57818C10.7145 6.18369 10.3947 5.86389 10.0002 5.86389C9.60569 5.86389 9.28589 6.18369 9.28589 6.57818C9.28589 6.97267 9.60569 7.29246 10.0002 7.29246Z" />
	</IconBase>
);

export default InfoCircle;
