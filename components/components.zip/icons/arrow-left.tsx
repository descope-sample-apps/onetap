import { IconBase, type IconComponent } from '@/components/elements/icon';

const ArrowLeft: IconComponent = (props) => (
	<IconBase
		width="20"
		height="21"
		viewBox="0 0 20 21"
		fill="none"
		stroke="currentColor"
		{...props}
	>
		<path d="M19.2853 10.502H0.713867" />
		<path d="M5.71387 5.50195L0.713867 10.502L5.71387 15.502" />
	</IconBase>
);

export default ArrowLeft;
